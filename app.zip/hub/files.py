"""원천 파일 고르기와 DRM 잠금 확인.

암호가 풀린 Excel 파일은 Excel 프로그램으로 열면 (읽기 전용이어도) DRM이 다시 잠근다.
그래서 이 툴은 Excel을 띄우지 않고 Python 라이브러리로만 읽는다.
"""

import fnmatch
import re
from datetime import datetime
from pathlib import Path

OK = "ok"
LOCKED = "locked"
UNKNOWN = "unknown"

ZIP_MAGIC = b"PK"          # .xlsx / .xlsm / .xlsb는 zip 파일
DRM_MAGIC = b"SCDSA"       # 회사 DRM으로 잠긴 파일의 앞부분


def lock_state(path: Path) -> str:
    """파일 앞부분으로 잠금 여부를 본다."""
    try:
        with open(path, "rb") as f:
            head = f.read(8)
    except OSError:
        return UNKNOWN
    if head.startswith(DRM_MAGIC):
        return LOCKED
    if head.startswith(ZIP_MAGIC):
        return OK
    return UNKNOWN


def candidates(folder: Path, src: dict) -> list[tuple[datetime, Path]]:
    """패턴에 맞는 파일과 그 날짜, 최근 것부터. 날짜 = 파일 이름 속 날짜 (pick: name_date) 또는 수정 시각."""
    if not folder.is_dir():
        return []
    files = [p for p in folder.iterdir()
             if p.is_file() and not p.name.startswith("~$") and name_matches(p.name, src["pattern"])]
    regex = re.compile(src["date_regex"]) if src.get("pick") == "name_date" else None
    dated = []
    for p in files:
        d = _date_in_name(p.stem, regex, src["date_format"]) if regex else None
        dated.append((d or datetime.fromtimestamp(p.stat().st_mtime), p))
    return sorted(dated, key=lambda x: (x[0], x[1].stat().st_mtime), reverse=True)


def name_matches(name: str, pattern: str) -> bool:
    """파일 이름이 sources.yaml 패턴에 맞는지. 대소문자는 보지 않는다 (Windows처럼).
    웹 버전(브라우저 파일 시스템)은 glob이 대소문자를 가려서 직접 비교한다 (2026-11-18)."""
    return fnmatch.fnmatchcase(name.lower(), pattern.lower())


def pick_latest(folder: Path, src: dict) -> tuple[Path | None, datetime | None]:
    """폴더에서 패턴에 맞는 파일 중 가장 최근 것을 고른다. (파일, 파일 날짜)"""
    found = candidates(folder, src)
    if not found:
        return None, None
    d, p = found[0]
    return p, d


def _date_in_name(stem: str, regex: re.Pattern, fmt: str) -> datetime | None:
    for m in regex.finditer(stem):
        try:
            return datetime.strptime(m.group(1), fmt)
        except ValueError:
            continue
    return None


def fingerprint(path: Path) -> dict:
    """같은 파일을 두 번 읽지 않으려고 이름·크기·수정 시각을 남긴다."""
    st = path.stat()
    return {
        "file": path.name,
        "size": st.st_size,
        "mtime": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
    }
