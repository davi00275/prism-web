"""원천 파일 읽기. 함수 이름이 sources.yaml의 reader 값이다.

모든 함수는 {표 이름: DataFrame}, 추가 정보(dict)를 돌려준다.
Excel 프로그램은 쓰지 않는다 (files.py 참고).
"""

import re
from datetime import date, datetime
from pathlib import Path

import pandas as pd


class FormatError(Exception):
    """원천 파일의 모양(시트, 머리글 위치)이 예상과 다를 때."""


# ---- 공통 -----------------------------------------------------------------

def text(s: pd.Series) -> pd.Series:
    """앞뒤 공백을 지운 글자. 빈 값은 None."""
    def one(v):
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return None
        v = str(v).strip()
        return v or None
    return s.map(one).astype(object)


def excel_date(s: pd.Series) -> pd.Series:
    """'2026-10-22' 같은 글자, Excel 날짜 숫자(46315), 날짜 값(.xlsx)을 모두 날짜로."""
    s = s.astype(object)
    # 날짜 값은 숫자로 바꾸면 나노초가 되어 버리므로 따로 둔다
    is_date = s.map(lambda v: isinstance(v, (datetime, date)))
    as_date = pd.to_datetime(s.where(is_date), errors="coerce")
    num = pd.to_numeric(s.where(~is_date), errors="coerce")
    from_serial = pd.to_datetime(num, unit="D", origin="1899-12-30", errors="coerce")
    from_text = pd.to_datetime(s.where(num.isna() & ~is_date), errors="coerce", format="mixed")
    return as_date.fillna(from_serial).fillna(from_text)


def tidy(df: pd.DataFrame, dates=(), numbers=()) -> pd.DataFrame:
    """날짜·숫자 열은 형식을 맞추고 나머지는 글자로 (Parquet로 저장하려면 열마다 형식이 하나여야 한다)."""
    out = df.copy()
    for c in out.columns:
        if c in dates:
            out[c] = excel_date(out[c])
        elif c in numbers:
            out[c] = pd.to_numeric(out[c], errors="coerce")
        else:
            out[c] = text(out[c])
    return out


def _find_header(raw: pd.DataFrame, marker: str, max_scan: int = 15) -> int:
    """marker 글자가 있는 행 번호 (머리글 행)."""
    for i in range(min(max_scan, len(raw))):
        if any(str(v).strip() == marker for v in raw.iloc[i].tolist()):
            return i
    raise FormatError(f"머리글 '{marker}'를 앞 {max_scan}행에서 찾지 못했습니다")


def _with_header(raw: pd.DataFrame, marker: str, wanted: list[str], sheet: str) -> pd.DataFrame:
    """머리글 행을 찾아 원하는 열만 뽑는다. 같은 이름이 여러 번이면 첫 번째."""
    h = _find_header(raw, marker)
    names = [str(v).replace("\n", " ").strip() if pd.notna(v) else "" for v in raw.iloc[h].tolist()]
    cols = {}
    for w in wanted:
        if w not in names:
            raise FormatError(f"'{sheet}' 시트에 '{w}' 열이 없습니다")
        cols[w] = names.index(w)
    body = raw.iloc[h + 1:, list(cols.values())].copy()
    body.columns = list(cols.keys())
    return body


# ---- Product List ---------------------------------------------------------

PRODUCT_DATES = ["SRA", "EOL", "EOP", "EOP Start", "Init DTTM", "Up DTTM"]
PRODUCT_NUMBERS = ["EOP Qty", "SOP Result Qty", "REMAIN Qty", "FIXED Qty", "AVAILABLE Qty"]
PRODUCT_REQUIRED = ["Item", "Item Name", "PLC Status", "BOM Status", "SRA", "EOL", "EOP",
                    "Product Group", "Model Group", "Model Name"]


def product_list(path: Path):
    df = pd.read_excel(path, dtype=object)
    df.columns = [str(c).replace("\n", " ").strip() for c in df.columns]
    # 앞쪽 빈 열(Unnamed: 0, 0)은 버린다
    df = df[[c for c in df.columns if not (c.startswith("Unnamed") or c == "0") or df[c].notna().any()]]
    missing = [c for c in PRODUCT_REQUIRED if c not in df.columns]
    if missing:
        raise FormatError(f"Product List에 열이 없습니다: {', '.join(missing)}")
    df = tidy(df, dates=PRODUCT_DATES, numbers=PRODUCT_NUMBERS)
    df = df[df["Item"].notna()].drop_duplicates("Item")
    return {"items": df.reset_index(drop=True)}, {}


# ---- POS 매핑 파일 --------------------------------------------------------

def pos_mapping(path: Path):
    xl = pd.ExcelFile(path)
    for sheet in ("Local List", "BOM List", "DP Material 매핑"):
        if sheet not in xl.sheet_names:
            raise FormatError(f"POS 매핑 파일에 '{sheet}' 시트가 없습니다")

    # Local List: Local 제품 판정 기준 (사용자 확인 2026-10-22)
    raw = xl.parse("Local List", header=None, dtype=object)
    local = _with_header(raw, "Item", ["Item", "Base SKU"], "Local List")
    local = tidy(local)
    local = local[local["Item"].notna()].drop_duplicates("Item")

    # BOM List: BOM 헤더 → 구성품. '선택 Alt' = 1 이 실제로 쓰는 대체 BOM
    raw = xl.parse("BOM List", header=None, dtype=object)
    bom = _with_header(raw, "Material Code",
                       ["Material Code", "Alternative BOM", "BOM Status", "Component", "Qty",
                        "Local?", "선택 Alt", "DP 구성품 (DP List 포함)"], "BOM List")
    bom = bom.rename(columns={"Material Code": "header", "Alternative BOM": "alt", "BOM Status": "bom_status",
                              "Component": "component", "Qty": "qty", "Local?": "component_local",
                              "선택 Alt": "selected", "DP 구성품 (DP List 포함)": "dp_component"})
    bom = tidy(bom, numbers=["alt", "qty", "component_local", "selected", "dp_component"])
    bom = bom[bom["header"].notna() & bom["component"].notna()]

    # DP Material 매핑: POS SKU → 확정 PO SKU → DP 아이템
    raw = xl.parse("DP Material 매핑", header=None, dtype=object)
    pos = _with_header(raw, "POS SKU",
                       ["POS SKU", "확정 PO SKU", "DP 경로", "DP 아이템", "Qty (POS 1개당)", "확정 단계"],
                       "DP Material 매핑")
    pos = pos.rename(columns={"POS SKU": "pos_sku", "확정 PO SKU": "po_sku", "DP 경로": "dp_path",
                              "DP 아이템": "dp_item", "Qty (POS 1개당)": "qty", "확정 단계": "stage"})
    pos = tidy(pos, numbers=["qty"])
    pos = pos[pos["pos_sku"].notna()]

    tables = {"local_list": local.reset_index(drop=True),
              "bom_list": bom.reset_index(drop=True),
              "pos_map": pos.reset_index(drop=True)}
    return tables, {}


# ---- HVA 재고 (SAP current inventory) --------------------------------------
# 같은 형식이 두 곳에 있다: 공유 폴더 Current Inventory의 일별 파일, DP 파일의 '1. HVA Inv' 시트

INVENTORY_COLUMNS = {
    "Plant": "plant", "Key Date": "key_date", "Material Number": "item", "S.Loc": "s_loc",
    "Special Stock Ind.": "special_stock", "Sales Doc.": "sales_doc",
    "Unrestricted-Use Stock": "unrestricted", "Blocked Stock": "blocked", "Total Stock Quantity": "total",
    "Allocated Stock": "allocated", "Open PO Qty": "open_po", "S/O Qty": "so_qty", "D/O Qty": "do_qty",
    "Availabilty Qty": "available", "Price": "price", "Total Stock Amount": "amount",
    "MRP Controller": "mrp_controller", "Data extract date": "extract_date",
}
INVENTORY_NUMBERS = ["unrestricted", "blocked", "total", "allocated", "open_po", "so_qty", "do_qty",
                     "available", "price", "amount"]


def _inventory(df: pd.DataFrame, where: str) -> pd.DataFrame:
    df.columns = [str(c).replace("\n", " ").strip() for c in df.columns]
    missing = [c for c in INVENTORY_COLUMNS if c not in df.columns]
    if missing:
        raise FormatError(f"{where}에 재고 열이 없습니다: {', '.join(missing)}")
    out = df[list(INVENTORY_COLUMNS)].rename(columns=INVENTORY_COLUMNS)
    out = tidy(out, dates=["key_date", "extract_date"], numbers=INVENTORY_NUMBERS)
    out["sales_doc"] = out["sales_doc"].str.replace(r"\.0$", "", regex=True)
    return out[out["item"].notna()].reset_index(drop=True)


def hva_inventory(path: Path):
    df = pd.read_excel(path, dtype=object)
    stock = _inventory(df, path.name)
    key = stock["key_date"].dropna()
    return {"stock": stock}, {"key_date": key.max().strftime("%Y-%m-%d") if len(key) else None}


# ---- 주문 / 반품 (SAP daily sales) ----------------------------------------
# 같은 형식이 두 곳에 있다: 공유 폴더 Daily Sales / Daily Sales_Returns의 일별 파일, DP 파일 '4. Order' / '5. Return'
# 열 이름에 특수 공백(\xa0)이 있고 수량 열 이름이 모두 "Q'ty"라서 위치로 읽는다. 마지막 행은 합계(아이템 없음).

SALES_COLUMNS = ["group1", "group1_name", "item", "item_name", "currency", "unit",
                 "invoice_amt", "invoice_qty", "order_amt", "order_qty", "confirm_amt", "confirm_qty",
                 "not_confirm_amt", "not_confirm_qty", "block_amt", "block_qty", "not_gi_amt", "not_gi_qty",
                 "not_pod_amt", "not_pod_qty", "not_invoice_amt", "not_invoice_qty", "total_amt", "total_qty"]
SALES_HEADER_CHECK = {0: "Group 1", 2: "Group 2", 6: "Invoice Amount", 8: "Order Amount", 10: "Confirm Amount",
                      12: "Not Confirm Amount", 14: "Block Amount", 16: "Not GI Amount", 18: "Not POD Amount",
                      20: "Not Invoice Amount", 22: "Total Amount", 23: "Total Qty"}


def _clean_name(v) -> str:
    return str(v).replace("\xa0", " ").replace("\n", " ").strip()


def _sales_status(df: pd.DataFrame, where: str) -> pd.DataFrame:
    names = [_clean_name(c) for c in df.columns]
    for i, expected in SALES_HEADER_CHECK.items():
        if i >= len(names) or names[i] != expected:
            got = names[i] if i < len(names) else ""
            raise FormatError(f"{where} {i + 1}열 머리글 = '{got}' (예상 '{expected}')")
    out = df.iloc[:, :24].copy()
    out.columns = SALES_COLUMNS
    out = tidy(out, numbers=SALES_COLUMNS[6:])
    out[SALES_COLUMNS[6:]] = out[SALES_COLUMNS[6:]].fillna(0)
    return out[out["item"].notna()].reset_index(drop=True)  # 합계 행 제외


def daily_sales(path: Path):
    return {"orders": _sales_status(pd.read_excel(path, dtype=object), path.name)}, {}


def daily_returns(path: Path):
    return {"returns": _sales_status(pd.read_excel(path, dtype=object), path.name)}, {}


# ---- ADI 채널 재고 ---------------------------------------------------------
# 1행 = 제목(ITEM DETAIL (USD $)), 2행 = 머리글. 미국·캐나다·푸에르토리코가 한 파일에 있다.
# 키 = Supplier Part No (Hanwha 아이템, 대부분 POS SKU와 같은 모양)

ADI_COLUMNS = {
    "Category": "category", "RCAT": "rcat", "Country": "country", "Item": "adi_item", "Item Status": "status",
    "Supplier": "supplier", "Supplier Part No": "part", "Current Purchase Cost": "cost",
    "Total Inv Qty": "total_qty", "DOS": "dos", "Allocated Qty": "allocated_qty", "Backorder Qty": "backorder_qty",
    "Available Qty": "available_qty", "Total Open PO Qty": "total_open_po_qty", "Open PO Qty": "open_po_qty",
    "Past Due PO Qty": "past_due_po_qty", "Total Inv": "total_amt", "Available": "available_amt",
}
ADI_TEXT = ["category", "rcat", "country", "adi_item", "status", "supplier", "part"]


def _adi(raw: pd.DataFrame, where: str) -> pd.DataFrame:
    raw = raw.copy()
    raw.iloc[:15] = raw.iloc[:15].map(lambda v: _clean_name(v) if isinstance(v, str) else v)
    body = _with_header(raw, "Supplier Part No", list(ADI_COLUMNS), where).rename(columns=ADI_COLUMNS)
    body = tidy(body, numbers=[v for v in ADI_COLUMNS.values() if v not in ADI_TEXT])
    return body[body["part"].notna()].reset_index(drop=True)


def adi_inventory(path: Path):
    return {"adi": _adi(pd.read_excel(path, header=None, dtype=object), path.name)}, {}


# ---- DP 파일 (DP_W##.xlsb) -------------------------------------------------

# DP list 시트에서 쓰는 열: (열 번호, 저장할 이름). 열 번호는 A=0.
# 머리글: 1행(A1~), 2행(세부), 데이터는 5행부터. 위치가 바뀌면 HEADER_CHECK에서 멈춘다.
DP_LIST_COLUMNS = [
    (0, "to_site"), (1, "product_group"), (2, "series"), (3, "model_group"), (4, "item"),
    (5, "item_name"), (6, "asp"), (13, "from_site"), (14, "product_type"),
    (15, "sra"), (16, "eol"), (17, "eop"),
    (18, "sales_prev_year"), (19, "sales_recent6"), (20, "sales_recent3"), (21, "rr_current"),
    (57, "rr_rule"), (58, "rr_proposed"), (64, "rr_flag"), (68, "eoh_target"),
    (71, "pl_status"), (72, "pl_notes"), (75, "rr_risk_flag"), (76, "rr_risk_reason"), (77, "prev_model"),
]
DP_LIST_HEADER_CHECK = [  # (행, 열, 시작 글자)
    (0, 4, "Item"), (1, 21, "R/R"), (1, 57, "적용 규칙"), (1, 58, "최종 제안 RR"),
    (1, 68, "EOH Target"), (1, 71, "PL Status"),
]
DP_LIST_DATES = ["sra", "eol", "eop"]
DP_LIST_NUMBERS = ["asp", "sales_prev_year", "sales_recent6", "sales_recent3", "rr_current",
                   "rr_proposed", "eoh_target"]


# DP Table 시트: 3행이 머리글, 4행부터 SKU. 1행에 월 이름(Oct, Nov…)이 있다
DP_TABLE_COLUMNS = [
    (0, "item"), (2, "type"), (3, "bom"), (4, "pl_status"), (5, "gi"), (6, "hva_inv"), (7, "open_so"),
    (8, "open_do"), (9, "available"), (10, "adi_inv"), (11, "rr"), (12, "adi_adjust"), (13, "eoh"),
    (14, "inbound_m1"), (15, "inbound_m2"), (16, "inbound_m3"), (17, "inbound_m4"), (18, "inbound_m5"),
    (19, "demand_m1"), (20, "demand_m2"), (21, "demand_m3"), (22, "demand_m4"), (23, "resource_check"),
    (24, "carry_m1"), (25, "carry_m2"), (26, "carry_m3"), (27, "carry_m4"), (28, "rr_review"), (29, "review_reason"),
]
DP_TABLE_HEADER_CHECK = [(2, 0, "SKU"), (2, 5, "GI"), (2, 11, "R/R"), (2, 23, "자원점검"), (2, 28, "RR Review")]
# v07부터 있는 열 (2026-10-23). 머리글이 맞을 때만 읽는다
DP_TABLE_MANUAL = [(32, "manual_m1"), (33, "manual_m2"), (34, "manual_m3"), (35, "manual_m4")]
DP_TABLE_TEXT = ["item", "type", "bom", "pl_status", "rr_review", "review_reason"]

# K-V 전환 시트 (v07~): 한국(K)↔베트남(V) 생산 전환 모델. K+V 판매를 합쳐 RR을 계산한다
KV_MODEL_COLUMNS = {"기준모델": "model", "K SKU": "k_sku", "V SKU": "v_sku", "패턴(처음→최근)": "pattern",
                    "겹침 개월": "overlap_months", "최근3M 우세": "recent_lead", "합산 RR": "rr_combined",
                    "K 개별RR": "rr_k_alone", "V 개별RR": "rr_v_alone", "현행 R/R (K)": "rr_current_k",
                    "현행 R/R (V)": "rr_current_v"}
# K-V_Replacement 시트: SKU별 배분비율 = 그 SKU 최근 3개월 Sell-in ÷ 모델 전체
KV_RATIO_COLUMNS = {"SKU": "item", "최근3M Sell-in": "si_recent3", "그룹 최근3M": "group_si_recent3",
                    "배분비율": "share"}


def _header_ok(raw: pd.DataFrame, checks) -> tuple[bool, str]:
    for r, c, expected in checks:
        got = str(raw.iat[r, c]).replace("\n", " ").strip() if r < raw.shape[0] and c < raw.shape[1] else ""
        if not got.startswith(expected):
            return False, f"{r + 1}행 {c + 1}열 = '{got}' (예상 '{expected}')"
    return True, ""


def _dp_table(xl: pd.ExcelFile) -> tuple[pd.DataFrame, dict]:
    raw = xl.parse("DP Table", header=None)
    ok, why = _header_ok(raw, DP_TABLE_HEADER_CHECK)
    if not ok:
        raise FormatError(f"DP Table 머리글이 예상과 다릅니다: {why}")
    cols = list(DP_TABLE_COLUMNS)
    if all(_header_ok(raw, [(2, c, f"M{i + 1} 수동입력")])[0] for i, (c, _) in enumerate(DP_TABLE_MANUAL)):
        cols += DP_TABLE_MANUAL
    body = raw.iloc[3:, [c for c, _ in cols]].copy()
    body.columns = [n for _, n in cols]
    body = tidy(body, numbers=[n for _, n in cols if n not in DP_TABLE_TEXT])
    body = body[body["item"].notna()].drop_duplicates("item")
    # 월 이름: 1행 O~S = 입고 월, T~W = 수요 월 ('—'는 그 달이 DP 기간 밖)
    months = {
        "inbound_months": [str(raw.iat[0, c]).replace(" Inbound", "") for c in range(14, 19)],
        "demand_months": [str(raw.iat[0, c]) for c in range(19, 23)],
        "resource_check_label": str(raw.iat[0, 23]),
    }
    # AF1 = 남은 근무일 비율. 파일을 마지막으로 계산한 날(TODAY()) 기준이라 파일 값과 대조할 때만 쓴다
    if _header_ok(raw, [(0, 30, "남은 Working day")])[0]:
        ratio = pd.to_numeric(raw.iat[0, 31], errors="coerce")
        months["workday_ratio"] = None if pd.isna(ratio) else float(ratio)
    return body.reset_index(drop=True), months


def _optional_sheet(xl: pd.ExcelFile, sheet: str, marker: str, columns: dict) -> pd.DataFrame | None:
    """버전에 따라 없을 수 있는 시트. 없으면 None."""
    if sheet not in xl.sheet_names:
        return None
    raw = xl.parse(sheet, header=None)
    body = _with_header(raw, marker, list(columns), sheet).rename(columns=columns)
    numbers = [v for v in columns.values() if v not in ("model", "k_sku", "v_sku", "pattern", "recent_lead", "item")]
    body = tidy(body, numbers=numbers)
    key = "item" if "item" in body.columns else "model"
    return body[body[key].notna()].reset_index(drop=True)


def _excel_engine(path: Path) -> str | None:
    """.xlsb는 pyxlsb, .xlsx는 openpyxl (pandas 기본). 둘 다 계산된 값만 읽는다."""
    return "pyxlsb" if path.suffix.lower() == ".xlsb" else None


def dp_file(path: Path):
    xl = pd.ExcelFile(path, engine=_excel_engine(path))
    raw = xl.parse("DP list", header=None)
    for r, c, expected in DP_LIST_HEADER_CHECK:
        got = str(raw.iat[r, c]).replace("\n", " ").strip() if c < raw.shape[1] else ""
        if not got.startswith(expected):
            raise FormatError(f"DP list 머리글이 예상과 다릅니다: {r + 1}행 {c + 1}열 = '{got}' (예상 '{expected}')")
    body = raw.iloc[4:, [c for c, _ in DP_LIST_COLUMNS]].copy()
    body.columns = [n for _, n in DP_LIST_COLUMNS]
    body = tidy(body, dates=DP_LIST_DATES, numbers=DP_LIST_NUMBERS)
    body = body[body["item"].notna()].drop_duplicates("item")

    setting = xl.parse("Setting", header=None)
    extra = _dp_settings(setting)
    tables = {"dp_list": body.reset_index(drop=True), "rr_items": _rr_items(setting)}

    tables["dp_table"], months = _dp_table(xl)
    extra.update(months)
    kv_models = _optional_sheet(xl, "K-V 전환", "기준모델", KV_MODEL_COLUMNS)
    kv_ratio = _optional_sheet(xl, "K-V_Replacement", "SKU", KV_RATIO_COLUMNS)
    if kv_models is not None:
        tables["kv_models"] = kv_models
    if kv_ratio is not None:
        tables["kv_ratio"] = kv_ratio
    # '1. HVA Inv' = 그 주에 붙여 넣은 SAP 재고 파일. 일별 재고 파일이 잠겨 있을 때 이 값을 쓴다
    tables["hva_inv"] = _inventory(xl.parse("1. HVA Inv"), "DP 파일 '1. HVA Inv'")
    # 주문·반품·ADI·POS 매핑: 일별 파일이 없을 때 쓰고, DP Table 값 검증에도 쓴다
    tables["orders"] = _sales_status(xl.parse("4. Order"), "DP 파일 '4. Order'")
    tables["returns"] = _sales_status(xl.parse("5. Return"), "DP 파일 '5. Return'")
    tables["adi"] = _adi(xl.parse("2. ADI Inv", header=None), "DP 파일 '2. ADI Inv'")
    pm = xl.parse("POS Master")
    pm.columns = [_clean_name(c) for c in pm.columns]
    pm = pm.rename(columns={"POS SKU": "pos_sku", "확정 PO SKU": "po_sku", "구분": "kind",
                            "DP Material": "dp_material", "Qty (POS 1개당)": "qty"})
    pm = tidy(pm[["pos_sku", "po_sku", "kind", "dp_material", "qty"]], numbers=["qty"])
    tables["pos_master"] = pm[pm["pos_sku"].notna() & pm["dp_material"].notna()].reset_index(drop=True)
    tables["pl_limited"], tables["pl_eol"], pl_date = _pricelist(xl)
    extra["pricelist_date"] = pl_date
    # 계산 엔진 입력 (2026-10-28, docs/dp-engine.md)
    tables["dp_material"] = _dp_material(xl)
    tables["inbound"] = _inbound(xl)
    return tables, extra


# ---- DP 파일: 계산 엔진 입력 (docs/dp-engine.md) ----------------------------
# Setting 시트 (A=0). 위치가 바뀌면 SETTING_CHECK에서 멈춘다
SETTING_CHECK = [
    (0, 0, "▶ DP 주차"), (1, 0, "DP 개월 수"), (3, 0, "기준월"), (8, 0, "기준일"), (2, 4, "US Federal Holiday"),
    (29, 0, "CFC5 Storage Loc"), (30, 0, "SCA3 Storage Loc"), (26, 7, "DP 제외 SKU 접두어"),
    (42, 7, "ADI 채널재고 보정"), (43, 7, "보정 적용"), (44, 7, "적정 유통재고 일수"), (45, 7, "보정 상한"),
    (46, 7, "초과·부족분 분산 개월"), (48, 7, "보정 방향"), (2, 18, "Item"),
]
HOLIDAY_ROWS = range(3, 25)        # F4:G25 (DP Table AF1 수식의 범위)
PREFIX_ROWS = range(27, 41)        # H28:H41 (8. DP Material A열 수식의 범위)


def _dp_settings(setting: pd.DataFrame) -> dict:
    ok, why = _header_ok(setting, SETTING_CHECK)
    if not ok:
        raise FormatError(f"Setting 시트 모양이 예상과 다릅니다: {why}")
    cell = lambda r, c: setting.iat[r, c] if r < setting.shape[0] and c < setting.shape[1] else None
    num = lambda r, c: pd.to_numeric(cell(r, c), errors="coerce")
    day = lambda r, c: excel_date(pd.Series([cell(r, c)])).iat[0]
    week, months, base_month, base_date = num(0, 1), num(1, 1), day(3, 1), day(8, 1)
    holidays = []
    for r in HOLIDAY_ROWS:
        d = day(r, 5)
        if not pd.isna(d):
            holidays.append([d.strftime("%Y-%m-%d"), str(cell(r, 6) or "").strip().upper() == "Y"])
    return {
        "dp_week": None if pd.isna(week) else int(week),
        "rr_base_month": None if pd.isna(base_month) else base_month.strftime("%Y-%m"),
        "dp_settings": {
            "dp_months": None if pd.isna(months) else int(months),        # B2 (파일 계산 시점)
            "base_date": None if pd.isna(base_date) else base_date.strftime("%Y-%m-%d"),  # B9
            "holidays": holidays,                                          # [날짜, 근무일에서 뺌]
            "hva_inv_locations": [str(cell(r, 1)).strip() for r in (29, 30) if not _blank(cell(r, 1))],
            "exclude_prefixes": [str(cell(r, 7)).strip() for r in PREFIX_ROWS if not _blank(cell(r, 7))],
            "adi_adjust": {
                "on": str(cell(43, 8) or "").strip().upper() == "Y",       # I44
                "target_days": float(num(44, 8)),                          # I45
                "cap": float(num(45, 8)),                                  # I46
                "spread_months": float(num(46, 8)),                        # I47
                "direction": str(cell(48, 8) or "").strip(),               # I49 '차감만' / '양방향'
            },
        },
    }


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and pd.isna(v)) or str(v).strip() == ""


def _rr_items(setting: pd.DataFrame) -> pd.DataFrame:
    """Setting S4:S1999: DP Table에서 R/R을 넣는 아이템 목록 (여기 없으면 R/R 0). 'Updated' 날짜는 T1"""
    items = text(setting.iloc[3:1999, 18])
    return pd.DataFrame({"item": items[items.notna()].drop_duplicates().tolist()})


# 8. DP Material: 4행 머리글, 5행부터. A~N = 아이템별 BOM 전개 결과 (O~U는 BOM 구성표 → POS Master에서 다시 만든다)
DP_MATERIAL_COLUMNS = [(0, "item"), (4, "kind"), (5, "own_rr"), (6, "bom_rr"), (7, "total_rr"), (8, "own_eoh"),
                       (9, "bom_eoh"), (10, "total_eoh"), (11, "n_headers"), (12, "headers"), (13, "rr_basis")]
DP_MATERIAL_CHECK = [(3, 0, "DP Material"), (3, 5, "단품 RR"), (3, 6, "BOM RR"), (3, 7, "총 RR"),
                     (3, 8, "단품 EOH"), (3, 10, "총 EOH"), (3, 13, "RR 근거")]


def _dp_material(xl: pd.ExcelFile) -> pd.DataFrame:
    raw = xl.parse("8. DP Material", header=None)
    ok, why = _header_ok(raw, DP_MATERIAL_CHECK)
    if not ok:
        raise FormatError(f"8. DP Material 머리글이 예상과 다릅니다: {why}")
    body = raw.iloc[4:, [c for c, _ in DP_MATERIAL_COLUMNS]].copy()
    body.columns = [n for _, n in DP_MATERIAL_COLUMNS]
    body = tidy(body, numbers=["own_rr", "bom_rr", "total_rr", "own_eoh", "bom_eoh", "total_eoh", "n_headers"])
    return body[body["item"].notna()].drop_duplicates("item").reset_index(drop=True)


def _inbound(xl: pd.ExcelFile) -> pd.DataFrame:
    """3. Inbound (주간 WB_Inbound를 월로 모은 표): 4행 = 월(날짜), 5행 = V/A/P/T, 6행부터 아이템.
    한 달에 4칸 (V·A·P·T). DP Table은 T(합계) 칸을 쓴다. 결과는 (아이템, 월, V, A, P, T) 한 줄씩."""
    raw = xl.parse("3. Inbound", header=None)
    ok, why = _header_ok(raw, [(3, 0, "Item Code")])
    if not ok:
        raise FormatError(f"3. Inbound 머리글이 예상과 다릅니다: {why}")
    starts = [c for c in range(2, raw.shape[1]) if not pd.isna(excel_date(pd.Series([raw.iat[3, c]])).iat[0])]
    body = raw.iloc[5:].copy()
    body["item"] = text(body[0])
    body = body[body["item"].notna()].drop_duplicates("item")  # DP Table은 XMATCH로 첫 번째 행만 본다
    parts = []
    for c in starts:
        subs = [str(raw.iat[4, c + k]).strip() if c + k < raw.shape[1] else "" for k in range(4)]
        if subs != ["V", "A", "P", "T"]:
            raise FormatError(f"3. Inbound {c + 1}열 월 칸이 V/A/P/T가 아닙니다: {subs}")
        month = excel_date(pd.Series([raw.iat[3, c]])).iat[0]
        block = body[[c, c + 1, c + 2, c + 3]].apply(pd.to_numeric, errors="coerce")
        block.columns = ["vessel", "air", "p", "total"]
        block.insert(0, "month", month.strftime("%Y-%m"))
        block.insert(0, "item", body["item"])
        parts.append(block)
    if not parts:
        return pd.DataFrame(columns=["item", "month", "vessel", "air", "p", "total"])
    return pd.concat(parts, ignore_index=True)


# PriceList 시트 (PM이 매월 주는 미국 PriceList). DP하지 않는 아이템 목록 두 개 (사용자 확인 2026-10-26):
#   K~Q열 Limited Stock Products (2행 머리글)   S~AA열 EOL Product (No Stock) (5행 머리글)
PL_LIMITED_HEADER = [(1, 10, "Category"), (1, 11, "Item #"), (1, 13, "Notes")]
PL_EOL_HEADER = [(4, 18, "Category"), (4, 19, "Item #"), (4, 23, "EOL Date"), (4, 24, "Replacement")]


def _pricelist(xl: pd.ExcelFile) -> tuple[pd.DataFrame, pd.DataFrame, str | None]:
    """(Limited Stock, EOL Product, PriceList 날짜 'YYYY-MM-DD'). 날짜는 B1 'USA Pricelist October 1, 2026'에서."""
    raw = xl.parse("PriceList", header=None)
    title = str(raw.iat[0, 1]) if raw.shape[1] > 1 else ""
    found = re.search(r"([A-Z][a-z]+ \d{1,2}, \d{4})", title)
    pl_date = pd.to_datetime(found.group(1), format="%B %d, %Y", errors="coerce") if found else pd.NaT
    for checks, what in ((PL_LIMITED_HEADER, "Limited Stock (K~Q)"), (PL_EOL_HEADER, "EOL Product (S~AA)")):
        ok, why = _header_ok(raw, checks)
        if not ok:
            raise FormatError(f"PriceList {what} 머리글이 예상과 다릅니다: {why}")
    lim = raw.iloc[2:, [10, 11, 13]].copy()
    lim.columns = ["category", "item_no", "notes"]
    lim = tidy(lim)
    eol = raw.iloc[5:, [18, 19, 23, 24]].copy()
    eol.columns = ["category", "item_no", "eol_date", "replacement"]
    eol = tidy(eol, dates=["eol_date"])
    return (lim[lim["item_no"].notna()].drop_duplicates("item_no").reset_index(drop=True),
            eol[eol["item_no"].notna()].drop_duplicates("item_no").reset_index(drop=True),
            None if pd.isna(pl_date) else pl_date.strftime("%Y-%m-%d"))


# ---- Base Item (2026-11-06) ------------------------------------------------

def base_item(path: Path):
    """DP의 기준 아이템 목록. 시트 'Base Item', 1행 머리글 Item · Item Name (사용자)."""
    try:
        raw = pd.read_excel(path, sheet_name="Base Item", dtype=object)
    except ValueError as e:
        raise FormatError(f"{path.name}: 'Base Item' 시트가 없습니다") from e
    if list(raw.columns[:2]) != ["Item", "Item Name"]:
        raise FormatError(f"{path.name}: Base Item 시트 머리글이 다릅니다: {list(raw.columns[:2])}")
    df = pd.DataFrame({"item": text(raw["Item"]), "item_name": text(raw["Item Name"])}).dropna(subset=["item"])
    dup = df.loc[df["item"].duplicated(), "item"]
    if len(dup):
        raise FormatError(f"{path.name}: 같은 아이템이 두 번 있습니다: {sorted(dup)[:5]}")
    return {"items": df.reset_index(drop=True)}, {}


# ---- 프로젝트 PO (2026-11-10, docs/project-info.md) ------------------------------------------
# SAP S/O 라인 리포트로 보인다 (추정). 한 줄 = S/O 한 줄. Customer PO(G열)로 사람이 넣은 프로젝트와 맞춘다.
PROJECT_PO = {"Customer PO": "po", "S/O No": "so_no", "S/O Item": "so_item", "Sold-to party Name": "sold_to",
              "Ship-to party Name": "ship_to", "Material": "item", "Order Qty": "qty", "S/O Net price": "price",
              "S/O Net Value(Loc.Cur)": "amount"}
PROJECT_PO_MORE = {"S/O Material Description": "item_name", "S/O Local create on date": "so_date",
                   "S/O Rejected Qty": "rejected_qty", "Reason for rejection": "reject_reason", "Billed Qty": "billed_qty",
                   "Bill.NetValue(Loc.Cur)": "billed_amount", "S/O Doc.Curr": "currency", "Sales employee name": "sales_rep"}
PROJECT_PO_NUMBERS = {"qty", "price", "amount", "rejected_qty", "billed_qty", "billed_amount"}


def project_po(path: Path):
    """PO(S/O 라인) 데이터. 꼭 있어야 하는 열이 없으면 멈추고, 나머지 열은 없으면 빈칸으로 읽는다."""
    raw = pd.read_excel(path, sheet_name=0, dtype=object)
    _need(raw, list(PROJECT_PO), path.name)
    df = pd.DataFrame(index=raw.index)
    for old, new in {**PROJECT_PO, **PROJECT_PO_MORE}.items():
        if new in PROJECT_PO_NUMBERS:
            df[new] = pd.to_numeric(raw[old], errors="coerce").fillna(0) if old in raw else 0.0
        elif new == "so_date":
            df[new] = excel_date(raw[old]) if old in raw else pd.NaT
        else:
            df[new] = text(raw[old]) if old in raw else None
    df = df.dropna(subset=["po"]).reset_index(drop=True)
    return {"lines": df}, {"po_count": int(df["po"].nunique())}


# ---- Inbound (2026-11-06, docs/inbound.md). 폴더에서 찾지 않고 'Inbound' 화면에서 고른 파일을 읽는다 ------

TO_SITE_NAME = "HVA-NORTH"     # 우리가 보는 도착지 (사용자)
ARRIVAL = "ARRIVAL-FIXED"
MONTH_NO = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], start=1)}
TRANSPORT = ["AIR", "PRIORITY", "VESSEL", "VESTRK"]


def _need(df: pd.DataFrame, columns: list[str], where: str) -> None:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise FormatError(f"{where}: 없는 열 {missing}")


def plan_columns(columns: list) -> dict[str, str]:
    """Sync Plan 주차 열 → 달 ('2026-11'). 주차 열이 이어지다 달 이름 열(Nov)이 나오면 앞 주차들이 그 달이다.
    달 경계에 걸친 주차는 202649A·202649B로 나뉘어 있다. 마지막 달 이름 뒤의 주차는 그다음 달."""
    out, waiting, last = {}, [], None
    for c in (str(c) for c in columns):
        if re.fullmatch(r"\d{6}[AB]?", c):
            waiting.append(c)
        elif c in MONTH_NO and waiting:
            last = (int(waiting[-1][:4]), MONTH_NO[c])
            out.update({w: f"{last[0]}-{last[1]:02d}" for w in waiting})
            waiting = []
    if waiting and last:
        y, m = (last[0] + 1, 1) if last[1] == 12 else (last[0], last[1] + 1)
        out.update({w: f"{y}-{m:02d}" for w in waiting})
    return out


def sync_plan(path: Path):
    """MP_PSI: 아이템마다 ARRIVAL-FIXED(합계)와 운송수단별 줄, 주차 열. → (아이템, 운송수단, 주차, 달, 수량) 긴 표."""
    raw = pd.read_excel(path, dtype=object)
    _need(raw, ["To Site Name", "Item", "Item Name", "Week", "Category"], path.name)
    raw = raw[text(raw["To Site Name"]) == TO_SITE_NAME].copy()
    raw["Item"] = text(raw["Item"])
    months = plan_columns(list(raw.columns))
    if not months:
        raise FormatError(f"{path.name}: 주차 열을 찾지 못했습니다")
    cols = list(months)
    raw[cols] = raw[cols].apply(pd.to_numeric, errors="coerce").fillna(0)

    category = text(raw["Category"])
    mode = category.str.extract(r"^" + ARRIVAL + r" \((.+)\)$")[0]
    other = category[(category != ARRIVAL) & mode.isna()]
    unknown = sorted(set(mode.dropna()) - set(TRANSPORT)) + sorted(set(other))
    if unknown:
        raise FormatError(f"{path.name}: 모르는 Category {unknown}")
    parts = raw[mode.notna()].assign(mode=mode)
    total = raw[category == ARRIVAL].set_index("Item")[cols]
    summed = parts.groupby("Item")[cols].sum().reindex(total.index).fillna(0)
    if float((total - summed).abs().sum().sum()) > 0.5:
        raise FormatError(f"{path.name}: 운송수단별 합이 ARRIVAL-FIXED와 다릅니다")

    long = parts.melt(id_vars=["Item", "Item Name", "mode"], value_vars=cols, var_name="col", value_name="qty")
    long = long[long["qty"] != 0].rename(columns={"Item": "item", "Item Name": "item_name"})
    long["week"] = long["col"].str[:6]
    long["month"] = long["col"].map(months)
    long["col_order"] = long["col"].map({c: i for i, c in enumerate(cols)})
    version = text(raw["Week"]).dropna()
    plan_version = version.iloc[0] if len(version) else None
    return ({"plan": long.reset_index(drop=True)},
            {"plan_version": plan_version, "plan_week": plan_version[:6] if plan_version else None})


def in_transit(path: Path):
    """DYN_In-transit: 지금 오는 중인 줄. HVA-NORTH만, 맨 아래 합계 줄은 To Site Name이 비어 빠진다."""
    raw = pd.read_excel(path, dtype=object)
    wanted = {"Item": "item", "TP Mode": "mode", "I/T Qty": "qty", "Status": "status", "PO No": "po_no",
              "PO Item": "po_item", "SN No": "sn_no", "BL No": "bl_no", "Container No.": "container"}
    dates = {"Ship Date": "ship_date", "SCM ETA": "scm_eta", "CHG ETA": "chg_eta", "SN ETA": "sn_eta"}
    _need(raw, ["To Site Name"] + list(wanted) + list(dates), path.name)
    raw = raw[text(raw["To Site Name"]) == TO_SITE_NAME]
    df = pd.DataFrame({new: text(raw[old]) for old, new in wanted.items() if old != "I/T Qty"})
    df["qty"] = pd.to_numeric(raw["I/T Qty"], errors="coerce").fillna(0)
    for old, new in dates.items():
        df[new] = excel_date(raw[old])
    unknown = sorted(set(df["mode"].dropna()) - set(TRANSPORT))
    if unknown:
        raise FormatError(f"{path.name}: 모르는 TP Mode {unknown}")
    return {"transit": df.reset_index(drop=True)}, {}


def gr(path: Path):
    """GR: SAP 입고 내역 (Sheet1). Sheet2는 요약이라 안 쓴다."""
    try:
        raw = pd.read_excel(path, sheet_name="Sheet1", dtype=object)
    except ValueError as e:
        raise FormatError(f"{path.name}: Sheet1이 없습니다") from e
    # 'Item' 머리글이 네 번 나온다 (pandas가 Item.1~.3으로 부름). Item.3 = GR Document의 줄 번호
    _need(raw, ["Material", "SN Qty", "GR Date", "GR Status", "SN No", "GR Document", "Item.3", "Container No", "House BL No",
                "PO Number"], path.name)
    df = pd.DataFrame({"item": text(raw["Material"]), "sn_no": text(raw["SN No"]), "gr_doc": text(raw["GR Document"]),
                       "gr_item": text(raw["Item.3"]), "gr_status": text(raw["GR Status"]),
                       "container": text(raw["Container No"]), "bl_no": text(raw["House BL No"]), "po_no": text(raw["PO Number"])})
    df["qty"] = pd.to_numeric(raw["SN Qty"], errors="coerce").fillna(0)
    df["gr_date"] = excel_date(raw["GR Date"])
    return {"gr": df.dropna(subset=["item"]).reset_index(drop=True)}, {}


# ---- RR 파일 (2026-11-10, docs/run-rate.md) ------------------------------------------------------
# RR 담당자의 'RR_화면만들기.xlsx'. 원재료(Sell-in·Sell-out)와 참조(pricelist·K-V·POS master)는 꼭 있어야 하고,
# '이전 RR 현행 RR'(아이템 마스터 + 엑셀 계산 결과)과 'RR Formula'(기준값)는 있으면 읽는다.

RR_NEEDED = ["Sell-in", "Sell-out", "pricelist", "K-V Replacement", "POS master"]
RR_DP_LIST = "이전 RR 현행 RR"
RR_FORMULA = "RR Formula"
RR_MASTER_COLS = {"A": "to_site", "B": "product_group", "C": "series", "D": "model_group", "E": "item", "F": "item_name",
                  "G": "asp", "N": "from_site", "O": "product_type", "P": "sra", "Q": "eol", "R": "eop",
                  "S": "avg_prev_year", "T": "avg_6m", "U": "avg_3m", "V": "rr_current", "BS": "eoh_current",
                  "BZ": "old_model", "CA": "manual_rr", "CN": "proj_qty", "CO": "proj_first_so", "EA": "proj_rr",
                  "EB": "proj_delta", "EC": "proj_flag"}
RR_MASTER_TEXT = {"to_site", "product_group", "series", "model_group", "item", "item_name", "from_site", "product_type",
                  "old_model", "proj_flag"}
RR_MASTER_DATES = {"sra", "eol", "eop", "proj_first_so"}
# 'RR Formula' 탭 기준값 칸 → config/rr.yaml 키 (다르면 화면에 알린다)
RR_FORMULA_CELLS = {
    "B32": "blend_so_weight", "B34": "cap_blend", "B35": "cap_si_only", "B36": "trend_alpha", "B37": "trend_cap",
    "B39": "eop_months", "B40": "eop_factor", "B41": "zero_max", "B45": "blend_min_so6", "B46": "manual_sra_years",
    "B48": "drop_ratio", "B49": "drop_min_si6", "B51": "so_only.si_outlier", "B52": "so_only.si_cv_min",
    "B53": "so_only.so_cv_max", "B54": "so_only.cv_ratio_min", "B55": "so_only.min_valid_months",
    "B56": "so_only.ratio_low", "B57": "so_only.ratio_high", "B59": "limited_factor", "B60": "eoh.limited_multiple",
    "B61": "eol_factor", "B62": "eoh.eol_multiple", "B65": "eoh.base", "B66": "eoh.high_cv", "B67": "eoh.cv_min",
    "B69": "eoh.eop_multiple", "B78": "delta_review.pct", "B79": "delta_review.min_units", "AB68": "risk.yellow_share",
    "AB69": "risk.red_share", "AB70": "risk.min_total", "AB71": "risk.new_sra_years", "AB73": "risk.early_sra_years",
    "AB74": "risk.early_so_months", "AB75": "risk.early_single_month",
}


def _col(letter: str) -> int:
    n = 0
    for ch in letter:
        n = n * 26 + ord(ch) - 64
    return n - 1


def _cell(raw: pd.DataFrame, ref: str):
    m = re.fullmatch(r"([A-Z]+)(\d+)", ref)
    r, c = int(m.group(2)) - 1, _col(m.group(1))
    return raw.iat[r, c] if r < len(raw) and c < raw.shape[1] else None


def _month_columns(year_row: list, month_row: list, start: int) -> dict[int, str]:
    """연도 줄(값이 있는 칸부터 오른쪽으로 이어짐) + 달 이름 줄 → {열 번호: 'YYYY-MM'}. 달 이름이 끊기면 멈춘다."""
    out, year = {}, None
    for j in range(start, len(month_row)):
        y = year_row[j] if j < len(year_row) else None
        if isinstance(y, (int, float)) and not pd.isna(y) and 2000 < y < 2100:
            year = int(y)
        elif isinstance(y, str) and y.strip().isdigit():
            year = int(y.strip())
        m = month_row[j]
        if isinstance(m, str) and m.strip()[:3] in MONTH_NO and year:
            out[j] = f"{year}-{MONTH_NO[m.strip()[:3]]:02d}"
        elif out:
            break
    return out


def _long(raw: pd.DataFrame, first_row: int, key_col: int, months: dict[int, str]) -> pd.DataFrame:
    body = raw.iloc[first_row:]
    items = text(body.iloc[:, key_col])
    frames = []
    for j, ym in months.items():
        frames.append(pd.DataFrame({"item": items.values, "month": ym,
                                    "qty": pd.to_numeric(body.iloc[:, j], errors="coerce").fillna(0).values}))
    t = pd.concat(frames, ignore_index=True)
    return t.dropna(subset=["item"]).reset_index(drop=True)


def _json_value(v):
    if isinstance(v, (datetime, pd.Timestamp)):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and pd.isna(v):
        return None
    if hasattr(v, "item"):
        return v.item()
    return v


def run_rate(path: Path):
    """RR 파일 → 원재료·참조 표 + (있으면) 아이템 마스터·엑셀 결과. 모양이 다르면 FormatError."""
    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    missing = [s for s in RR_NEEDED if s not in sheets]
    if missing:
        raise FormatError(f"{path.name}: 없는 시트 {missing}")
    out, extra = {}, {}

    # Sell-in: 'Material' 줄이 머리글, 바로 위 줄이 연도, C열부터 달
    raw = sheets["Sell-in"]
    h = next((i for i in range(10) if str(raw.iat[i, 0]).strip() == "Material"), None)
    if h is None:
        raise FormatError(f"{path.name}: Sell-in 시트에서 'Material' 머리글을 찾지 못했습니다")
    months = _month_columns(raw.iloc[h - 1].tolist(), raw.iloc[h].tolist(), 2)
    if len(months) < 15:
        raise FormatError(f"{path.name}: Sell-in 달 열이 {len(months)}개뿐입니다")
    si = _long(raw, h + 1, 0, months)
    desc = text(raw.iloc[h + 1:, 1])
    si["desc"] = si["item"].map(dict(zip(text(raw.iloc[h + 1:, 0]), desc)))
    out["sell_in"] = si

    # Sell-out: 'DP Model' 줄이 머리글(B열), 바로 위 줄이 연도. 이미 DP Model(= Sell-in 아이템) 단위로 합쳐져 있다
    raw = sheets["Sell-out"]
    h = next((i for i in range(10) if str(raw.iat[i, 1]).strip() == "DP Model"), None)
    if h is None:
        raise FormatError(f"{path.name}: Sell-out 시트에서 'DP Model' 머리글을 찾지 못했습니다")
    head = [re.sub(r"\s+", " ", str(v)).strip() for v in raw.iloc[h].tolist()]
    start = next(j for j, v in enumerate(head) if v[:3] in MONTH_NO)
    months = _month_columns(raw.iloc[h - 1].tolist(), raw.iloc[h].tolist(), start)
    out["sell_out"] = _long(raw, h + 1, 1, months)
    body = raw.iloc[h + 1:]
    info_cols = {"POS Model": "pos_model", "DP Model": "item", "BOM": "bom", "POS Model 수": "pos_count",
                 "PLC Status": "plc_status", "BOM Status": "bom_status", "SRA": "sra", "EOL": "eol", "EOP": "eop",
                 "Product Group": "product_group", "Series": "series", "Soc Chip": "soc", "Attb05": "resolution",
                 "Attb14": "moq_lt", "Attb01": "category", "Attb02": "sub_category"}
    info = pd.DataFrame({new: body.iloc[:, head.index(old)].values for old, new in info_cols.items() if old in head})
    out["sell_out_info"] = tidy(info, dates=("sra", "eol", "eop"), numbers=("pos_count",)).dropna(subset=["item"]).reset_index(drop=True)

    # pricelist: 전체 목록(B:I, 3행 머리글), EOL 목록(S:AA, 5행 머리글), TAA 목록(AC:AO, 2행 머리글)
    raw = sheets["pricelist"]
    if str(_cell(raw, "C3")).strip() != "Item #" or str(_cell(raw, "T5")).strip() != "Item #":
        raise FormatError(f"{path.name}: pricelist 머리글 위치가 다릅니다 (C3·T5 'Item #')")
    pl = raw.iloc[3:, [_col("B"), _col("C"), _col("D"), _col("E"), _col("F"), _col("G")]]
    pl.columns = ["category", "item_no", "item_type", "notes", "description", "msrp"]
    pl = pl.assign(notes=pl["notes"].map(lambda v: None if v is None or (isinstance(v, float) and pd.isna(v)) else str(v)))
    pl = tidy(pl, numbers=("msrp",))
    pl["notes"] = pl["notes"].fillna("")
    out["pricelist"] = pl.dropna(subset=["item_no"]).assign(item_no=lambda d: d["item_no"].str.upper()).reset_index(drop=True)
    eol = raw.iloc[5:, [_col("S"), _col("T"), _col("U"), _col("W"), _col("X"), _col("Y")]]
    eol.columns = ["category", "item_no", "item_type", "msrp", "eol_date", "replacement"]
    eol = tidy(eol, dates=("eol_date",), numbers=("msrp",)).dropna(subset=["item_no"])
    out["pl_eol"] = eol[eol["item_no"].str.upper() != "ITEM #"].assign(item_no=lambda d: d["item_no"].str.upper()).reset_index(drop=True)
    if str(_cell(raw, "AD2")).strip().startswith("TAA"):
        taa = raw.iloc[2:, [_col("AD"), _col("AF"), _col("AJ")]]
        taa.columns = ["item_no", "notes", "origin"]
        out["taa"] = tidy(taa).dropna(subset=["item_no"]).assign(item_no=lambda d: d["item_no"].str.upper()).reset_index(drop=True)

    # K-V Replacement: E:I (SKU, 기준모델, 최근3M, 그룹 최근3M, 배분비율), 3행부터
    raw = sheets["K-V Replacement"]
    if str(_cell(raw, "E2")).strip() != "SKU" or str(_cell(raw, "F2")).strip() != "기준모델":
        raise FormatError(f"{path.name}: K-V Replacement E2·F2 머리글이 다릅니다")
    kv = raw.iloc[2:, [_col("E"), _col("F"), _col("G"), _col("H"), _col("I")]]
    kv.columns = ["item", "base_model", "recent3", "group_recent3", "ratio_excel"]
    out["kv"] = tidy(kv, numbers=("recent3", "group_recent3", "ratio_excel")).dropna(subset=["item", "base_model"]).reset_index(drop=True)

    # POS master: 1행 머리글. 줄 순서가 의미 있다 (PriceList 판정은 POS SKU의 첫 줄)
    raw = sheets["POS master"]
    if str(raw.iat[0, 0]).strip() != "POS SKU (Sell-Out)":
        raise FormatError(f"{path.name}: POS master A1 머리글이 다릅니다")
    pm = raw.iloc[1:, :5]
    pm.columns = ["pos_sku", "po_sku", "kind", "dp_material", "qty"]
    out["pos_master"] = tidy(pm, numbers=("qty",)).dropna(subset=["pos_sku"]).reset_index(drop=True)

    # 이전 RR 현행 RR (있으면): 아이템 마스터 + 엑셀 계산 결과 (검증 정답지)
    if RR_DP_LIST in sheets:
        raw = sheets[RR_DP_LIST]
        checks = {"E1": "Item", "V2": "R/R"}
        bad = {k: _cell(raw, k) for k, v in checks.items() if str(_cell(raw, k)).strip() != v}
        if bad or "최종 제안 RR" not in str(_cell(raw, "BG2")):
            raise FormatError(f"{path.name}: '{RR_DP_LIST}' 머리글이 다릅니다 {bad}")
        body = raw.iloc[4:]
        body = body[text(body.iloc[:, _col("E")]).notna().values]
        master = pd.DataFrame({new: body.iloc[:, _col(c)].values if _col(c) < raw.shape[1] else None
                               for c, new in RR_MASTER_COLS.items()})
        master = tidy(master, dates=RR_MASTER_DATES,
                      numbers=set(RR_MASTER_COLS.values()) - RR_MASTER_TEXT - RR_MASTER_DATES)
        out["master"] = master.reset_index(drop=True)
        from .rr_engine import EXCEL, EXCEL_TEXT
        ex = pd.DataFrame({"item": text(body.iloc[:, _col("E")]).values})
        for c, name in EXCEL.items():
            v = body.iloc[:, _col(c)] if _col(c) < raw.shape[1] else pd.Series([None] * len(body))
            ex[name] = text(v).fillna("").values if name in EXCEL_TEXT else pd.to_numeric(v, errors="coerce").values
        out["excel"] = ex
        # 12개월 값 (W:AH Sell-in, AI:AT Sell-out)과 프로젝트 차감 후 (CP:DA, DB:DM)
        def labels(a, b):
            res = {}
            for j in range(_col(a), _col(b) + 1):
                s = str(raw.iat[2, j]).strip()
                m = re.fullmatch(r"(\d{4})-([A-Za-z]{3})", s)
                if m and m.group(2) in MONTH_NO:
                    res[j] = f"{m.group(1)}-{MONTH_NO[m.group(2)]:02d}"
            return res
        si_l, so_l = labels("W", "AH"), labels("AI", "AT")
        frames = []
        for kind, lab in (("si", si_l), ("so", so_l)):
            for j, ym in lab.items():
                frames.append(pd.DataFrame({"item": ex["item"].values, "kind": kind, "month": ym,
                                            "qty": pd.to_numeric(body.iloc[:, j], errors="coerce").values}))
        out["excel_months"] = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["item", "kind", "month", "qty"])
        adj = []
        for kind, lab, start in (("si", si_l, "CP"), ("so", so_l, "DB")):
            for k, (j, ym) in enumerate(lab.items()):
                jj = _col(start) + k
                if jj < raw.shape[1]:
                    q = pd.to_numeric(body.iloc[:, jj], errors="coerce")
                    adj.append(pd.DataFrame({"item": ex["item"].values, "kind": kind, "month": ym, "qty": q.values}).dropna(subset=["qty"]))
        out["project_adj"] = pd.concat(adj, ignore_index=True) if adj else pd.DataFrame(columns=["item", "kind", "month", "qty"])

    # RR Formula (있으면): 기준값·RR 기준일·버전·프로젝트 보정 현황
    if RR_FORMULA in sheets:
        raw = sheets[RR_FORMULA]
        f = {key: _json_value(_cell(raw, ref)) for ref, key in RR_FORMULA_CELLS.items()}
        ages = []
        for r in range(17, 22):
            lo, fac = _cell(raw, f"T{r}"), _cell(raw, f"U{r}")
            if isinstance(lo, (int, float)) and isinstance(fac, (int, float)):
                ages.append([_json_value(lo), _json_value(fac)])
        if ages:
            f["age_factors"] = ages
        for r, g in ((59, "CAMERA"), (60, "PERIPHERAL")):
            ms = [v for v in (_cell(raw, f"U{r}"), _cell(raw, f"V{r}")) if isinstance(v, (datetime, date))]
            if ms:
                f[f"hoarding_months.{g}"] = [v.strftime("%Y-%m") for v in ms]
        extra = {"formula": {k: v for k, v in f.items() if v is not None},
                 "excel_base_date": _json_value(_cell(raw, "B6")), "excel_version": _json_value(_cell(raw, "B18")),
                 "project_status": _json_value(_cell(raw, "C94"))}
    extra["items"] = int(len(out.get("master", out["sell_in"].drop_duplicates("item"))))
    return out, extra


READERS = {"product_list": product_list, "pos_mapping": pos_mapping, "dp_file": dp_file,
           "hva_inventory": hva_inventory, "daily_sales": daily_sales, "daily_returns": daily_returns,
           "adi_inventory": adi_inventory, "base_item": base_item, "project_po": project_po, "run_rate": run_rate}

# 읽는 방식을 바꾸면 올린다. 스냅샷의 버전과 다르면 같은 파일이어도 다시 읽는다
# dp_file 2: DP Table·K-V 전환, 3: 1. HVA Inv, 4: 4. Order·5. Return·2. ADI Inv·POS Master (2026-10-23),
#         5: PriceList Limited Stock·EOL 목록, 6: PriceList 날짜 (2026-10-26),
#         7: .xlsx도 읽음, 계산 엔진 입력 (Setting 값, R/R 목록, 8. DP Material, 3. Inbound, AF1) (2026-10-28)
VERSIONS = {"product_list": 1, "pos_mapping": 1, "dp_file": 7, "hva_inventory": 1,
            "daily_sales": 1, "daily_returns": 1, "adi_inventory": 1, "base_item": 1, "project_po": 1, "run_rate": 1}
