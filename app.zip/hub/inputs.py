"""사람 입력: 대시보드에서 고친 값 (docs/inputs.md).

저장 위치: 팀 공유 폴더의 'HVA SCM 입력' 폴더 (settings.yaml inputs.folder). 사람마다 파일 하나: <이름>.jsonl
  - 각자 자기 파일에만 쓴다 → 한 파일을 둘이 고치지 않아서 OneDrive 충돌이 없다.
    다른 사람 PC에 늦게 올라가도, 내가 저장한 것은 내 PC의 공유 폴더에 바로 있다 (사용자 아이디어, 2026-10-28)
  - 다른 사람 파일은 읽기만 한다
  - 한 줄 = 고친 값 하나 (아이템·항목·기간·DP 주차·값·원래 값·사유·메모·누가·언제). 덮어쓰지 않고 쌓는다 → 이력
  - 같은 칸(아이템·항목·기간, 주차별 항목은 주차까지)에 여러 줄이 있으면 가장 최근 줄이 이긴다 (누가 고쳤든)
  - 값이 빈 줄 = 원래 값으로 되돌림
  - 텍스트 파일(JSON Lines). Excel 파일은 Excel로 열면 DRM이 잠그고, SharePoint가 올릴 때 내용을 덧붙인다

항목 (field):
  rr         R/R           기간 = RR 기준월 (DP 파일 Setting B4, 예 2026-10). 기준월이 바뀌면 적용 안 됨
  eoh        EOH           기간 = RR 기준월
  manual     월 DP 값       기간 = 그 달 (예 2026-11). DP Table M1~M4 수동입력 열처럼 그 달 DP 값을 이 값으로 바꾼다
  rc_adjust  자원점검 조정   기간 없음. 계산된 자원점검에 더하거나 뺀다 (+ 추가 오더, − 줄임)
  air        AIR 수량       기간 없음. 업로드 때 자원점검 중 AIR로 보낼 수량 (나머지는 VSL / TRK)
  remarks    Remarks        기간 없음. 업로드 파일 Remarks 칸 (글자는 text에, value는 비움)
  base_item  Base Item      기간 없음. 툴에서 넣은 아이템 (value 1 = 넣음, 값 없음 = 뺌, text = 이름, info = Group). hub/base_items.py
  월 DP 값·자원점검 조정·AIR·Remarks는 고친 그 DP 주차에만 적용한다 (WEEK_FIELDS). 다음 주 DP는 새로 본다 (Claude 결정 2026-10-28)
"""

import json
import os
import re
import socket
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import config, files, paths

FIELDS = {"rr": "R/R", "eoh": "EOH", "manual": "월 DP 값", "rc_adjust": "자원점검 조정", "air": "AIR",
          "remarks": "Remarks", "base_item": "Base Item"}
WEEK_FIELDS = {"manual", "rc_adjust", "air", "remarks"}   # 고친 DP 주차에만 적용
TEXT_FIELDS = {"remarks"}                                  # 값 대신 글자(text)를 저장
COLUMNS = ["at", "by", "item", "field", "period", "week", "value", "text", "original", "reason", "memo", "pc", "info"]
DEFAULT_FOLDER = "HVA SCM 입력"
# 주차를 적기 전(2026-10-28 첫 시험)에 저장한 줄은 모두 W43 DP 파일로 고친 것
LEGACY_WEEK = "2026-W43"

README = """HVA SCM Hub 사람 입력 폴더

대시보드(HVA SCM Hub)에서 고친 R/R, EOH, 월 DP 값, 자원점검 조정, AIR, Remarks가 여기에 저장됩니다.
'DP 확정' 폴더에는 주차마다 각자 확정한 최종 DP가 있습니다 (주차 폴더 안에 사람마다 파일 하나).
- 사람마다 파일 하나: <이름>.jsonl. 각자 자기 파일에만 씁니다.
- 한 줄 = 고친 값 하나. 지우거나 덮어쓰지 않고 계속 쌓입니다 (이력).
- 같은 아이템·항목은 가장 최근에 저장한 값을 씁니다.

손으로 고치지 마세요. 특히 Excel로 열지 마세요 (DRM으로 잠기면 그 사람의 입력을 읽지 못합니다).
내용을 보려면 대시보드의 'DP 계산' 화면이나 메모장을 쓰세요.
"""


# ---- 위치 -----------------------------------------------------------------

def folder() -> tuple[Path, str]:
    """(입력 폴더, 어디인지 설명). 공유 폴더를 못 찾으면 이 PC의 툴 데이터 폴더."""
    override = os.environ.get("HVA_HUB_INPUTS_DIR")  # 시험·개발용: 공유 폴더에 쓰지 않을 때
    if override:
        return Path(override), "시험용 폴더 (HVA_HUB_INPUTS_DIR)"
    value = (config.settings().get("inputs") or {}).get("folder") or DEFAULT_FOLDER
    p = Path(value)
    if p.is_absolute():
        return p, "설정한 폴더 (settings.yaml inputs.folder)"
    root = paths.resolve_root("shared")
    if root is not None:
        return root / p, "팀 공유 폴더"
    return config.data_dir() / "inputs", "이 PC에만 (팀 공유 폴더를 찾지 못함 — 다른 사람에게 안 보입니다)"


def writer() -> str:
    """이 PC에서 저장하는 사람 이름: 담당자 목록에 Windows 사용자 이름이 있으면 그 이름, 없으면 Windows 사용자 이름."""
    names = {os.environ.get("USERNAME", ""), Path(os.environ.get("USERPROFILE", "")).name}
    for o in sorted(set((config.settings().get("owners") or {}).values())):
        if any(n and n.lower() == o.lower() for n in names):
            return o
    return os.environ.get("USERNAME") or "unknown"


def _file_name(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).strip() + ".jsonl"


# ---- 쓰기 -----------------------------------------------------------------

def record(item: str, field: str, period: str | None, value, original=None, memo: str = "", reason: str = "",
           week: str | None = None, text: str | None = None, info: dict | None = None) -> dict:
    """저장할 줄 하나. week = 고친 DP 주차 (예 '2026-W45', dp_engine.current_week).
    글자 항목(remarks)은 value에 글자를 주면 text에 넣는다 (빈 글자 = 지움)."""
    if field not in FIELDS:
        raise ValueError(f"모르는 항목: {field}")
    if field in WEEK_FIELDS and not week:
        raise ValueError(f"{FIELDS[field]}는 DP 주차가 있어야 합니다")
    if field in TEXT_FIELDS:
        text, value = ("" if value is None else str(value)).strip(), None
    return {"at": datetime.now().isoformat(timespec="seconds"), "by": writer(), "item": item, "field": field,
            "period": period or "", "week": week, "value": _num(value), "text": text, "original": _num(original),
            "reason": reason or "", "memo": memo or "", "pc": socket.gethostname(), "info": info}


def append(records: list[dict]) -> Path:
    """내 파일 끝에 줄을 덧붙인다. 폴더가 없으면 만든다 (설명 파일 README.txt도)."""
    d, _ = folder()
    d.mkdir(parents=True, exist_ok=True)
    readme = d / "README.txt"
    if not readme.exists():
        readme.write_text(README, encoding="utf-8")
    path = d / _file_name(writer())
    lines = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records)
    for attempt in range(6):
        try:
            with open(path, "a", encoding="utf-8", newline="\n") as f:
                f.write(lines)
                f.flush()
                os.fsync(f.fileno())
            _memo.clear()
            return path
        except PermissionError:  # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    raise PermissionError(f"입력 파일에 쓰지 못했습니다: {path} (다른 프로그램이 사용 중)")


def _num(v):
    if v is None or v == "":
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if f != f else f  # NaN → None


# ---- 읽기 -----------------------------------------------------------------

_memo: dict = {}


def signature() -> tuple:
    """입력 파일들의 (이름, 크기, 수정 시각). 바뀌면 다시 읽고 계산한다."""
    d, _ = folder()
    if not d.is_dir():
        return ()
    out = []
    for p in sorted(d.glob("*.jsonl")):
        try:
            st = p.stat()
        except OSError:
            continue
        out.append((p.name, st.st_size, st.st_mtime))
    return tuple(out)


def load() -> tuple[pd.DataFrame, list[dict]]:
    """모든 사람의 입력 줄 (오래된 것부터)과 파일별 상태. 깨진 줄(동기화 중 등)은 건너뛰고 센다."""
    sig = signature()
    hit = _memo.get("load")
    if hit and hit[0] == sig:
        return hit[1], hit[2]
    d, _ = folder()
    rows, status = [], []
    for name, size, mtime in sig:
        p = d / name
        st = {"file": name, "person": name[:-len(".jsonl")], "size": size,
              "modified": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
              "rows": 0, "bad_lines": 0, "locked": False, "last_at": None}
        if files.lock_state(p) == files.LOCKED:
            st["locked"] = True
            status.append(st)
            continue
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        r = json.loads(line)
                        if not isinstance(r, dict) or r.get("field") not in FIELDS or not r.get("item"):
                            raise ValueError
                    except ValueError:
                        st["bad_lines"] += 1
                        continue
                    row = {c: r.get(c) for c in COLUMNS}
                    if row["field"] in WEEK_FIELDS and not row["week"]:
                        row["week"] = LEGACY_WEEK
                    rows.append(row)
                    st["rows"] += 1
                    st["last_at"] = max(st["last_at"] or "", r.get("at") or "") or None
        except OSError:
            st["bad_lines"] = -1
        status.append(st)
    df = pd.DataFrame(rows, columns=COLUMNS)
    if len(df):
        df = df.sort_values("at", kind="stable").reset_index(drop=True)
    _memo["load"] = (sig, df, status)
    return df, status


def _scope(df: pd.DataFrame) -> pd.Series:
    """같은 칸인지 가르는 열: R/R·EOH는 기간(RR 기준월), 주차별 항목은 주차 + 기간."""
    period = df["period"].fillna("").astype(str)
    week = df["week"].fillna("").astype(str)
    return period.where(~df["field"].isin(WEEK_FIELDS), week + "|" + period)


def active(pending: list[dict] | None = None) -> pd.DataFrame:
    """지금 적용할 값: 칸(아이템·항목·기간·주차)마다 가장 최근 줄. 값이 빈 줄(되돌림)이면 빠진다.
    pending = 아직 저장하지 않은 수정 (미리보기용, 저장된 것보다 나중으로 본다)."""
    df, _ = load()
    if pending:
        df = pd.concat([df, pd.DataFrame(pending, columns=COLUMNS)], ignore_index=True)
    if df.empty:
        return df
    last = df.assign(scope=_scope(df)).drop_duplicates(["item", "field", "scope"], keep="last")
    has_text = last["field"].isin(TEXT_FIELDS) & last["text"].fillna("").astype(str).ne("")
    return last[last["value"].notna() | has_text].drop(columns="scope").reset_index(drop=True)


def history(item: str | None = None) -> pd.DataFrame:
    """고친 기록 (최근 것부터). before = 이 줄 전에 쓰던 값: 같은 칸의 앞 줄 값, 없거나 되돌렸으면 원래 값
    (자원점검 조정·AIR은 0). 글자 항목은 before_text. item을 안 주면 모든 아이템 (팀 수정 기록)."""
    df, _ = load()
    if item is not None:
        df = df[df["item"] == item]
    if df.empty:
        return df.assign(before=pd.Series(dtype=float), before_text=pd.Series(dtype=str))
    df = df.assign(scope=_scope(df))
    g = df.groupby(["item", "field", "scope"])
    prev = pd.to_numeric(g["value"].shift(1), errors="coerce")
    start = pd.to_numeric(df["original"], errors="coerce").where(~df["field"].isin(["rc_adjust", "air"]), 0.0)
    df["before"] = prev.fillna(start)
    df["before_text"] = g["text"].shift(1).fillna("")
    return df.drop(columns="scope").iloc[::-1].reset_index(drop=True)
