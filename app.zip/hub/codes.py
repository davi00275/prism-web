"""아이템 코드 규칙 (docs/item-master.md).

  PNM-9085RQZ1/VUS
  └ base ──────┘└ suffix: V = 생산지(HVV), US = 향지
  버전 = 숫자 묶음의 마지막 자리 (PNM-908[5]RQZ1). 클수록 최신인 경우가 83% → 유사 아이템 "후보"로만 쓴다
"""

import re

FAMILY = re.compile(r"^([A-Z]{2,5})-([A-Z]{0,2})(\d{3,5})(.*)$")


def split(item: str) -> tuple[str, str | None]:
    """'PNM-9085RQZ1/VUS' → ('PNM-9085RQZ1', 'VUS')"""
    base, _, suffix = str(item).partition("/")
    return base.strip(), (suffix.strip() or None)


def parse_suffix(suffix: str | None, site_letters: dict) -> tuple[str | None, str | None]:
    """suffix → (생산지, 향지). 3글자이고 첫 글자가 생산지 표에 있으면 나눈다. 아니면 전체를 향지로."""
    if not suffix:
        return None, None
    if len(suffix) == 3 and suffix[0] in site_letters:
        return site_letters[suffix[0]], suffix[1:]
    return None, suffix


def family(base: str) -> tuple[str | None, int | None]:
    """버전 숫자만 다른 아이템을 묶는 키와 버전. 'PRN-6410DB4' → ('PRN-641?DB4', 0)"""
    m = FAMILY.match(base or "")
    if not m:
        return None, None
    prefix, letters, digits, rest = m.groups()
    return f"{prefix}-{letters}{digits[:-1]}?{rest}", int(digits[-1])


def norm(value) -> str:
    """검색용: 대문자, 영문·숫자만. 'pnm-9085 rqz1/vus' → 'PNM9085RQZ1VUS'"""
    return re.sub(r"[^0-9A-Z]", "", str(value or "").upper())
