"""주문·출고·ADI: 이번 달 GI, Open SO, ADI 채널 재고를 아이템별로 만든다 (docs/sales-adi.md).

정의는 DP 파일 DP Table 수식과 같다 (2026-10-23, W42 v07의 1,362개 아이템 전부 같은 값으로 확인):
  이번 달 GI = 주문(Invoice 수량 + Not Invoice 수량) + 반품(Invoice 수량 + Not Invoice 수량)   DP Table F
  Open SO   = 주문 Order 수량                                                            DP Table H
  Open DO   = 재고 파일 D/O Qty (CFC5)  → hub/inventory.py                                 DP Table I
  ADI 재고   = ADI Available Qty. POS 매핑이 있으면 Σ(POS SKU의 Available × Qty),
              없으면 아이템과 같은 Supplier Part No. 나라(미국·캐나다·푸에르토리코)를 모두 더한다  DP Table K
원천은 가장 최근 일별 파일, 없으면 DP 파일의 같은 시트.

'이번 달' GI라서 파일 날짜가 이번 달인 것만 GI에 쓴다 (2026-11-03: 11월에 10/26 반품 파일이 섞였다).
  주문 파일이 지난 달 것 → GI = 0 (Open SO는 열린 주문이라 그대로 쓴다)
  반품 파일이 지난 달 것 → 반품을 빼지 않는다
날짜가 바뀌면 다시 만든다 (stale).
"""

from datetime import date, datetime

import pandas as pd

from . import config, store

VERSION = 2  # 2: 지난 달 파일은 GI에 안 씀 (2026-11-03)
NAME = "주문·출고·ADI"
CACHE = "item_flow"

ADI_QTY = ["available_qty", "total_qty", "allocated_qty", "backorder_qty", "open_po_qty", "past_due_po_qty",
           "available_amt", "total_amt"]


def gi_so(orders: pd.DataFrame, returns: pd.DataFrame | None) -> pd.DataFrame:
    """아이템별 GI, Open SO. 반품은 GI에서 빠진다 (반품 파일 값이 음수)."""
    o = orders.groupby("item").agg(
        gi_qty_order=("invoice_qty", "sum"), not_invoice_qty=("not_invoice_qty", "sum"),
        gi_amt_order=("invoice_amt", "sum"), not_invoice_amt=("not_invoice_amt", "sum"),
        open_so_qty=("order_qty", "sum"), open_so_amt=("order_amt", "sum"),
        so_confirm_qty=("confirm_qty", "sum"), so_not_confirm_qty=("not_confirm_qty", "sum"),
        so_block_qty=("block_qty", "sum"), not_gi_qty=("not_gi_qty", "sum"))
    o["gi_qty"] = o["gi_qty_order"] + o["not_invoice_qty"]
    o["gi_amt"] = o["gi_amt_order"] + o["not_invoice_amt"]
    out = o[["gi_qty", "gi_amt", "open_so_qty", "open_so_amt", "so_confirm_qty", "so_not_confirm_qty",
             "so_block_qty", "not_gi_qty"]]
    if returns is not None and len(returns):
        r = returns.groupby("item").agg(inv=("invoice_qty", "sum"), ninv=("not_invoice_qty", "sum"),
                                        inv_amt=("invoice_amt", "sum"), ninv_amt=("not_invoice_amt", "sum"),
                                        return_open_qty=("order_qty", "sum"))
        r["return_gi_qty"] = r["inv"] + r["ninv"]
        r["return_gi_amt"] = r["inv_amt"] + r["ninv_amt"]
        out = out.join(r[["return_gi_qty", "return_gi_amt", "return_open_qty"]], how="outer").fillna(0)
        out["gi_qty"] = out["gi_qty"] + out["return_gi_qty"]
        out["gi_amt"] = out["gi_amt"] + out["return_gi_amt"]
    return out.fillna(0)


def adi_mapping(mapping: pd.DataFrame, adi: pd.DataFrame) -> pd.DataFrame:
    """(item, part, qty): POS 매핑 행 + 매핑이 없는 아이템은 같은 이름의 Supplier Part No (DP Table K열 규칙)."""
    m = mapping.rename(columns={"dp_material": "item", "pos_sku": "part"})[["item", "part", "qty"]].copy()
    m["qty"] = m["qty"].fillna(1)
    direct = pd.Series(adi["part"].unique())
    direct = direct[~direct.isin(m["item"])]
    return pd.concat([m, pd.DataFrame({"item": direct, "part": direct, "qty": 1})], ignore_index=True)


def adi_by_item(adi: pd.DataFrame, mapping: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """아이템별 ADI 합계, 그리고 화면용 상세 (아이템 × POS SKU × 나라)."""
    detail = adi_mapping(mapping, adi).merge(adi, on="part")
    for c in ADI_QTY:
        detail[c] = detail[c].fillna(0) * detail["qty"]
    totals = detail.groupby("item")[ADI_QTY].sum().add_prefix("adi_")
    detail = detail[["item", "part", "qty", "country", "status", "dos"] + ADI_QTY]
    return totals, detail


def _pick(choices: list[tuple[str, str, str]]):
    """[(원천, 표, 이름)] 중 스냅샷이 있는 첫 번째. (표, 출처 정보)"""
    for sid, table, label in choices:
        e = store.latest_entry(sid)
        df = store.load_table(sid, table, e) if e else None
        if df is not None:
            return df, {"source": label, "file": e["file"], "file_date": (e.get("file_date") or "")[:10]}
    return None, None


def this_month_gi(orders: pd.DataFrame, o_src: dict, returns: pd.DataFrame | None, r_src: dict | None,
                  today: date) -> tuple[pd.DataFrame, list[str]]:
    """gi_so()에 이번 달 확인을 더한 것. 파일 날짜(o_src·r_src의 file_date)의 달이 오늘 달이 아니면
    반품은 빼지 않고, 주문은 GI를 0으로 (Open SO는 그대로). 고른 내용은 o_src·r_src에 표시한다. (표, 알림)"""
    this_month = today.strftime("%Y-%m")
    warnings = []
    if returns is not None and (r_src.get("file_date") or "")[:7] != this_month:
        warnings.append(f"반품 파일({r_src['file']})이 {(r_src.get('file_date') or '')[:7]} 것이라 당월 GI 차감 제외. "
                        "당월 반품 파일 Decrypt 시 반영.")
        r_src["skipped"] = True
        returns = None
    g = gi_so(orders, returns)
    if (o_src.get("file_date") or "")[:7] != this_month:
        warnings.append(f"주문 파일({o_src['file']})이 {(o_src.get('file_date') or '')[:7]} 것이라 당월 GI 0 처리 "
                        "(Open SO는 해당 파일 값). 당월 주문 파일 Decrypt 시 반영.")
        o_src["gi_skipped"] = True
        for c in ("gi_qty", "gi_amt", "return_gi_qty", "return_gi_amt"):
            if c in g:
                g[c] = 0.0
    return g, warnings


def rebuild() -> str:
    orders, o_src = _pick([("daily_sales", "orders", "일별 주문 파일"), ("dp_file", "orders", "DP 파일 '4. Order'")])
    returns, r_src = _pick([("daily_returns", "returns", "일별 반품 파일"), ("dp_file", "returns", "DP 파일 '5. Return'")])
    adi, a_src = _pick([("adi_inventory", "adi", "ADI 파일"), ("dp_file", "adi", "DP 파일 '2. ADI Inv'")])
    mapping, m_src = _pick([("dp_file", "pos_master", "DP 파일 'POS Master'")])
    if mapping is None:
        pos, m_src = _pick([("pos_mapping", "pos_map", "POS 매핑 파일")])
        mapping = None if pos is None else pos.rename(columns={"dp_item": "dp_material"})

    warnings = []
    parts = []
    if orders is not None:
        g, warnings = this_month_gi(orders, o_src, returns, r_src, date.today())
        parts.append(g)
    if adi is not None and mapping is not None:
        totals, detail = adi_by_item(adi, mapping)
        parts.append(totals)
        store.write_cache("adi_detail", detail)
    if not parts:
        return "주문·ADI 데이터가 아직 없습니다"
    flow = pd.concat(parts, axis=1).fillna(0).reset_index().rename(columns={"index": "item"})
    store.write_cache(CACHE, flow)
    meta = {"version": VERSION, "settings_mtime": config.config_mtime(),
            "built_at": datetime.now().isoformat(timespec="seconds"), "built_on": date.today().isoformat(),
            "orders": o_src, "returns": r_src, "adi": a_src, "mapping": m_src, "warnings": warnings}
    store.write_cache_meta(meta, "flow_meta")
    gi = flow["gi_qty"].sum() if "gi_qty" in flow else 0
    so = flow["open_so_qty"].sum() if "open_so_qty" in flow else 0
    ad = flow["adi_available_qty"].sum() if "adi_available_qty" in flow else 0
    return f"GI {gi:,.0f} · Open SO {so:,.0f} · ADI Available {ad:,.0f} (전체 아이템 합계)"


def stale(meta: dict) -> bool:
    """날짜가 바뀌면 다시 만든다 (달이 바뀌면 지난 달 파일을 GI에서 빼야 하므로)."""
    return meta.get("built_on") != date.today().isoformat()
