"""화면과 Claude 연결(MCP)이 같이 쓰는 기능. 원천은 읽기만 한다 (원천 읽기는 ingest).
사람이 고친 값(inputs)과 주차별 확정(dp_history)만 여기서 공유 폴더에 쓴다."""

import os
import re
from datetime import date, datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import (base_items, codes, config, dp_engine, dp_history, files, inbound as inbound_mod, inbound_store,
               ingest, inputs, item_master, metrics as metrics_mod, paths, projects as projects_mod, readers, rr_engine,
               rr_review, store,
               upload, web)

ACTIVE = ["ACTIVE", "PLANNED"]

# Item 360에서 아직 원천이 연결되지 않은 영역 (PRD 7장). source = sources.yaml id
DP_TABLE_NOTE = "지금은 DP 파일 기준 값 ('DP 계산' 탭)"
PLANNED_SECTIONS = [
    {"name": "Sell-in (월별)", "source": "dp_file", "note": "DP 파일 Sell-in 시트"},
    {"name": "Sell-out (월별)", "source": "dp_file", "note": "DP 파일 Sell-out(Raw) 시트"},
    {"name": "PO (월별)", "source": None, "note": "출처 확인 필요"},
    {"name": "DP 이력 vs 실적", "source": "dp_file", "note": "주간 DP 스냅샷이 쌓이면"},
    {"name": "담당자 메모", "source": None, "note": "Outlook Archive 폴더 (후순위)"},
]

# 같은 캐시 파일을 매번 읽지 않도록, 파일 수정 시각이 바뀔 때만 다시 읽는다
_memo: dict[str, tuple[float, pd.DataFrame]] = {}


def _cached(name: str) -> pd.DataFrame | None:
    path = store.cache_path(name)
    if not path.exists():
        return None
    mtime = path.stat().st_mtime
    hit = _memo.get(name)
    if hit and hit[0] == mtime:
        return hit[1]
    df = pd.read_parquet(path)
    _memo[name] = (mtime, df)
    return df


def master() -> pd.DataFrame | None:
    return _cached("item_master")


def aliases() -> pd.DataFrame:
    df = _cached("item_aliases")
    return df if df is not None else pd.DataFrame(columns=["alias", "alias_norm", "item"])


def bom() -> pd.DataFrame:
    df = _cached("bom")
    return df if df is not None else pd.DataFrame(columns=["header", "component", "qty"])


def meta() -> dict:
    return store.read_cache_meta()


def inventory_meta() -> dict:
    return store.read_cache_meta("inventory_meta")


# ---- 아이템 지표 · 목록 ----------------------------------------------------

def metrics() -> pd.DataFrame | None:
    return _cached("item_metrics")


def owners() -> list[str]:
    return sorted(set(config.settings().get("owners", {}).values()))


def current_owner() -> str | None:
    """이 PC 사용자가 담당자 목록에 있으면 그 이름 (Windows 사용자 이름으로 찾는다)."""
    names = {os.environ.get("USERNAME", ""), Path(os.environ.get("USERPROFILE", "")).name}
    for o in owners():
        if any(n and n.lower() == o.lower() for n in names):
            return o
    return None


def worklist(owner: str | None = None, dp_status: str | None = metrics_mod.DP_TARGET, text: str = "",
             alerts: list[str] | None = None, product_group: str | None = None) -> pd.DataFrame:
    """'내 아이템' 목록. 기본은 DP 판정이 'DP 대상'인 아이템. dp_status=None이면 전부.
    alerts를 주면 그중 하나라도 걸린 아이템만."""
    d = metrics()
    if d is None:
        return pd.DataFrame()
    if owner:
        d = d[d["owner"] == owner]
    if product_group:
        d = d[d["product_group"] == product_group]
    if dp_status:
        d = d[d["dp_status"] == dp_status]
    q = codes.norm(text)
    if q:
        d = d[d["search_key"].str.contains(q, regex=False, na=False)]
    if alerts:
        cols = [f"alert_{a}" for a in alerts if a in metrics_mod.ALERT_BY_KEY]
        if cols:
            d = d[d[cols].any(axis=1)]
    return d.sort_values(["alert_count", "item"], ascending=[False, True])


def item_metrics(item: str) -> dict | None:
    d = metrics()
    if d is None:
        return None
    rows = d[d["item"] == item]
    if rows.empty:
        return None
    rec = rows.iloc[0]
    return {**{m.key: _plain(rec.get(m.key)) for m in metrics_mod.METRICS}, "alerts": list(rec["alerts"])}


# ---- 검색 -----------------------------------------------------------------

def search(query: str, limit: int = 30, active_only: bool = False) -> pd.DataFrame:
    """아이템·모델명·품명·POS SKU로 찾는다. 특수문자·대소문자 무시. 정확히 맞는 아이템이 먼저."""
    m = master()
    q = codes.norm(query)
    if m is None or not q:
        return pd.DataFrame()
    item_norm = m["item"].map(codes.norm)
    base_norm = m["base"].map(codes.norm)
    hit = m["search_key"].str.contains(q, regex=False, na=False)
    a = aliases()
    alias_items = set(a.loc[a["alias_norm"].str.contains(q, regex=False, na=False), "item"])
    hit = hit | m["item"].isin(alias_items)
    r = m[hit].copy()
    if active_only:
        r = r[r["plc_status"].isin(ACTIVE)]
    inorm, bnorm = item_norm[r.index], base_norm[r.index]
    r["_rank"] = 5
    r.loc[r["item"].isin(alias_items), "_rank"] = 4
    r.loc[inorm.str.contains(q, regex=False), "_rank"] = 3
    r.loc[inorm.str.startswith(q), "_rank"] = 2
    r.loc[bnorm == q, "_rank"] = 1
    r.loc[inorm == q, "_rank"] = 0
    r["_inactive"] = ~r["plc_status"].isin(ACTIVE)
    r["_not_dp"] = ~r["in_dp_list"].astype(bool)
    r = r.sort_values(["_rank", "_inactive", "_not_dp", "item"]).head(limit)
    r["match"] = r["_rank"].map(MATCH_LABEL)
    return r.drop(columns=["_rank", "_inactive", "_not_dp"])


# 검색 결과가 왜 나왔는지
MATCH_LABEL = {0: "아이템 일치", 1: "모델 일치", 2: "아이템 앞부분", 3: "아이템 일부", 4: "POS SKU", 5: "모델명·품명"}


# ---- 아이템 상세 ----------------------------------------------------------

def item_detail(item: str) -> dict | None:
    """Item 360 / Claude에게 줄 아이템 정보. 날짜는 'YYYY-MM-DD', 빈 값은 None."""
    m = master()
    if m is None:
        return None
    rows = m[m["item"] == item]
    if rows.empty:
        # 대소문자·특수문자가 달라도 찾는다
        rows = m[m["item"].map(codes.norm) == codes.norm(item)]
        if rows.empty:
            return None
    rec = rows.iloc[0]
    out = {k: _plain(v) for k, v in rec.items() if k != "search_key"}
    out["months_to_eop"] = _months_until(rec.get("eop"))
    out["months_since_sra"] = _months_since(rec.get("sra"))
    out["similar"] = similar_items(rec, m)
    out["bom_components"] = records(bom()[bom()["header"] == rec["item"]])
    out["used_in_boms"] = records(bom()[bom()["component"] == rec["item"]])
    a = aliases()
    out["pos_skus"] = records(a[a["item"] == rec["item"]].drop(columns=["alias_norm"], errors="ignore"))
    out["dp_calc"] = dp_calc(rec["item"])
    out["inbound"] = item_inbound(rec["item"])
    out["kv_switch"] = kv_switch(rec["item"])
    out["inventory"] = inventory(rec["item"], out["dp_calc"], out.get("dp_eoh_target"))
    out["flow"] = item_flow(rec["item"])
    out["metrics"] = item_metrics(rec["item"])
    out["not_connected_yet"] = [s["name"] for s in PLANNED_SECTIONS]
    return out


def dp_calc(item: str) -> dict | None:
    """이 아이템의 DP 계산 (계산 엔진, 이번 주차, 최신 파일, 사람이 고친 값 반영)과 DP 파일 DP Table 값, 고친 기록,
    주차별 확정 기록 (dp_history)."""
    plan = dp_plan()
    if plan is None:
        return None
    rows = plan[plan["item"] == item]
    if rows.empty:
        return None
    out = {k: _plain(v) for k, v in rows.iloc[0].items()}
    t = _cached("dp_table")
    if t is not None:
        f = t[t["item"] == item]
        out["dp_file"] = {k: _plain(v) for k, v in f.iloc[0].items()} if len(f) else None
    m = dp_plan_meta()
    cal = plan.attrs["calendar"]
    out["source"] = {"file": m.get("dp_file"), "dp_file_week": m.get("dp_week"),
                     "dp_file_data_date": m.get("dp_file_data_date"),
                     "dp_week": cal["dp_week"], "week": cal["week"], "rr_base_month": m.get("rr_base_month"),
                     "months": cal["months"], "month_keys": cal["month_keys"],
                     "month_labels": [dp_engine.month_label(k) for k in cal["month_keys"]],
                     "workday_ratio": cal["workday_ratio"], "data": dp_engine.MODE_LABEL[dp_engine.LATEST],
                     "inputs": m.get("sources")}
    # 고친 기록 (최근 것부터): before → value. value가 없으면 되돌림
    out["edit_history"] = records(change_log(item).drop(columns=["pc"], errors="ignore"))
    out["dp_history"] = records(item_dp_history(item))
    return out


# ---- DP 계산 (계산 엔진 + 사람 입력) ------------------------------------------

_plan_memo: dict = {}


def dp_plan(mode: str = dp_engine.LATEST, pending: list[dict] | None = None) -> pd.DataFrame | None:
    """아이템별 DP 계산 결과 (hub/dp_engine.py). pending = 아직 저장 안 한 수정 (미리보기).
    입력 표·사람 입력 파일·날짜가 같으면 다시 계산하지 않는다."""
    path = store.cache_path(dp_engine.CACHE)
    if not path.exists():
        return None
    key = (mode, path.stat().st_mtime, inputs.signature(), config.today())
    if not pending and _plan_memo.get(mode, (None,))[0] == key:
        return _plan_memo[mode][1]
    plan, _ = dp_engine.current_plan(mode, pending)
    if not pending:
        _plan_memo[mode] = (key, plan)
    return plan


def dp_plan_meta() -> dict:
    return store.read_cache_meta(dp_engine.META)


def dp_calendar(mode: str = dp_engine.LATEST) -> dict:
    """이번 DP 주차·기간·남은 근무일 비율 (dp_engine.calendar). 기본은 오늘 날짜 기준."""
    return dp_engine.calendar(dp_plan_meta(), mode)


def _dp_keys(cal: dict | None = None) -> list[str]:
    cal = cal or dp_calendar()
    return cal["month_keys"][:cal["months"]]


def edit_records(changes: list[dict], memo: str = "", reason: str = "", week: str | None = None) -> list[dict]:
    """화면의 수정 [{item, field, period, value, original}] → 저장할 줄. 미리보기에도 쓴다.
    week = 어느 DP 주차의 수정인지 (기본 이번 주. 월요일 자원점검은 지난 금요일 DP 주차)."""
    week = week or dp_engine.current_week()
    return [inputs.record(c["item"], c["field"], c.get("period"), c.get("value"), c.get("original"),
                          c.get("memo", memo), c.get("reason", reason), week)
            for c in changes]


def save_edits(changes: list[dict], memo: str = "", reason: str = "", week: str | None = None) -> Path:
    """고친 값을 내 입력 파일에 저장하고 아이템 지표('내 아이템' 목록, Claude)를 다시 만든다."""
    path = inputs.append(edit_records(changes, memo, reason, week))
    metrics_mod.rebuild()
    return path


def edit_reasons() -> list[str]:
    """고친 이유 버튼 (settings.yaml inputs.reasons)."""
    return list((config.settings().get("inputs") or {}).get("reasons") or ["기타"])


def edit_label(field: str, period: str | None, keys: list[str] | None = None) -> str:
    """'R/R', 'M2 Nov DP', '자원점검 조정' 같은 화면 이름. keys = 이번 DP 달 목록 (M 번호용)."""
    if field == "manual" and period:
        keys = _dp_keys() if keys is None else keys
        m = f"M{keys.index(period) + 1} " if period in keys else ""
        return f"{m}{dp_engine.month_label(period)} DP"
    return inputs.FIELDS.get(field, field)


def change_log(item: str | None = None) -> pd.DataFrame:
    """고친 기록 (최근 것부터, 모든 사람). 열: at, by, item, field, label, period, week, this_week, before, value,
    text, before_text, reason, memo. value가 비어 있으면 되돌림 (글자 항목은 text)."""
    h = inputs.history(item)
    keys = _dp_keys()
    week = dp_engine.current_week()
    h["label"] = [edit_label(f, p, keys) for f, p in zip(h["field"], h["period"])]
    h["this_week"] = h["week"].eq(week) | ~h["field"].isin(inputs.WEEK_FIELDS)
    return h


def active_edits(item: str) -> list[dict]:
    """이 아이템에 지금 적용 중인 수정 (R/R·EOH는 RR 기준월, 월 DP 값은 이번 DP 주차)."""
    m = dp_plan_meta()
    week, keys = dp_engine.current_week(), _dp_keys()
    a = inputs.active()
    if a.empty:
        return []
    a = a[a["item"] == item]
    ok = ((a["field"].isin(dp_engine.EDIT_FIELDS) & (a["period"] == m.get("rr_base_month")))
          | ((a["week"] == week) & (a["field"] == "manual") & a["period"].isin(keys)))
    out = records(a[ok].drop(columns=["pc"], errors="ignore"))
    for r in out:
        r["label"] = edit_label(r["field"], r["period"], keys)
    order = {"rr": 0, "eoh": 1, "manual": 2, "rc_adjust": 3, "air": 4, "remarks": 5}
    return sorted(out, key=lambda r: (order.get(r["field"], 9), r["period"] or ""))


def previous_week_edits(item: str) -> list[dict]:
    """지난 DP 주차에 고친 월 DP 값 중 이번 주에 아직 없는 것 (가장 최근 주차 하나).
    그 달이 이번 DP 기간 안에 있을 때만. '이번 주에도 적용' 버튼용."""
    week, keys = dp_engine.current_week(), _dp_keys()
    h = inputs.history(item)
    h = h[h["field"] == "manual"]
    old = h[h["week"] < week]
    if old.empty:
        return []
    last_week = old["week"].max()
    old = old[old["week"] == last_week].drop_duplicates(["field", "period"])  # 최근 것부터라 첫 줄이 마지막 값
    now = set(zip(h.loc[h["week"] == week, "field"], h.loc[h["week"] == week, "period"]))
    out = []
    for r in old.itertuples(index=False):
        value = r.text if r.field in inputs.TEXT_FIELDS else r.value
        if _blank(value) or (r.field, r.period) in now or (r.field == "manual" and r.period not in keys):
            continue
        out.append({"item": item, "field": r.field, "period": r.period, "value": value, "week": last_week,
                    "label": edit_label(r.field, r.period, keys), "by": r.by, "reason": r.reason, "memo": r.memo})
    return out


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and pd.isna(v)) or v == ""


# ---- 금요일 DP 확정 · 기록 ----------------------------------------------------

def dp_scope(plan: pd.DataFrame, owner: str | None) -> pd.DataFrame:
    """그 담당의 아이템 (계산 표는 Base Item 전부). owner=None이면 모든 담당. M1~M3이 모두 0인 아이템도 들어간다."""
    m = metrics()
    cols = ["item", "owner"]
    info = m[cols] if m is not None else pd.DataFrame(columns=cols)
    d = plan.merge(info, on="item", how="left")
    return (d[d["owner"] == owner] if owner else d).reset_index(drop=True)


def data_dates() -> dict:
    """확정 기록에 남길 데이터 기준일 (어떤 파일로 계산했는지)."""
    m = dp_plan_meta()
    src = m.get("sources", {})
    out = {"dp_file": m.get("dp_file"), "dp_file_week": m.get("dp_week"), "dp_file_data_date": m.get("dp_file_data_date"),
           "rr_base_month": m.get("rr_base_month")}
    if src.get("inventory"):
        out["inventory"] = src["inventory"].get("key_date")
    fm = flow_meta()
    for k in ("orders", "returns", "adi"):
        if fm.get(k):
            skipped = fm[k].get("skipped") or fm[k].get("gi_skipped")
            out[k] = (fm[k].get("file_date") or "") + (" (GI에 안 씀)" if skipped else "")
    im = inbound_meta()
    if im.get("plan_version"):
        out["sync_plan"] = im["plan_version"]
        out["in_transit"] = im.get("transit_date")
        out["gr_total"] = im.get("gr_total")
    return out


def confirm_week(owner: str, memo: str = "") -> Path:
    """금요일 DP를 확정한다: 그 담당 아이템의 M1~M3(과 계산 근거)을 공유 폴더 'DP 확정'에 남긴다."""
    plan = dp_plan()
    path = dp_history.write(owner, dp_scope(plan, owner), plan.attrs["calendar"], data_dates(), memo)
    return path


def week_progress(owner: str | None = None) -> list[dict]:
    """담당별 이번 주 DP 진행: 아이템 수, M1~M3 합계, 고친 아이템, 확정 시각, 확정 뒤 바뀐 아이템."""
    plan = dp_plan()
    if plan is None:
        return []
    cal = plan.attrs["calendar"]
    week = plan.attrs["week"]
    confirmed = {w["owner"]: w for w in dp_history.week_files(week)}
    out = []
    for o in ([owner] if owner else owners()):
        rows = dp_scope(plan, o)
        snap = dp_history.load_owner(week, o) if o in confirmed else None
        out.append({"owner": o, "week": week, "items": len(rows),
                    "dp": [float(rows[f"demand_m{i}"].sum()) for i in range(1, cal["months"] + 1)],
                    "resource_check": float(rows["resource_check"].sum()), "edited": int(rows["edited"].sum()),
                    "confirmed_at": snap["confirmed_at"].iloc[0] if snap is not None and len(snap) else None,
                    "confirmed_by": snap["confirmed_by"].iloc[0] if snap is not None and len(snap) else None,
                    "changed_since": dp_history.changed_items(snap, rows) if snap is not None else []})
    return out


def confirmed_weeks() -> list[dict]:
    """확정 기록이 있는 주차 (최근부터): [{week, owners: [이름]}]. 폴더 이름만 본다."""
    return dp_history.weeks()


def with_monday(snap: pd.DataFrame) -> pd.DataFrame:
    """확정 기록 + 월요일 입력(그 주차로 저장한 자원점검 ±·AIR·Remarks) → resource_check, air, vsl, remarks, upload.
    본사 자원점검 내역 파일을 받으면 rc_formula 대신 그 수량을 쓴다 (샘플 대기, docs/dp-history.md)."""
    if snap.empty:
        return snap
    t = snap.copy()
    a = inputs.active()
    for field, col, name in (("rc_adjust", "value", "rc_adjust"), ("air", "value", "air_input"), ("remarks", "text", "remarks")):
        e = a[a["field"] == field][["item", "week", col]].rename(columns={col: name}) if len(a) else \
            pd.DataFrame(columns=["item", "week", name])
        t = t.drop(columns=name, errors="ignore").merge(e, on=["item", "week"], how="left")
    number = lambda c: dp_engine.excel_round(pd.to_numeric(t[c], errors="coerce").fillna(0))
    t["rc_formula"], t["rc_adjust"], t["air_input"] = number("rc_formula"), number("rc_adjust"), number("air_input")
    t["resource_check"] = (t["rc_formula"] + t["rc_adjust"]).clip(lower=0)
    t["air"] = t[["air_input", "resource_check"]].min(axis=1)
    t["vsl"] = t["resource_check"] - t["air"]
    t["remarks"] = t["remarks"].fillna("").astype(str)
    t["upload"] = (t["resource_check"] > 0) | (t["remarks"] != "")
    return t


def week_snapshot(week: str, owner: str | None = None) -> pd.DataFrame:
    """그 주차에 확정한 표 + 월요일 입력 (owner를 주면 그 사람 것만)."""
    return with_monday(dp_history.load_week(week, owner))


def item_dp_history(item: str) -> pd.DataFrame:
    """아이템의 주차별 확정값 + 월요일 입력 (최근 주차부터)."""
    return with_monday(dp_history.item_history(item))


def dp_export(owner: str, week: str | None = None) -> tuple[bytes, str] | None:
    """금요일 DP 표 엑셀 (M1~M3, 임시 양식. DP UI 업로드 양식 샘플을 받으면 바꾼다)."""
    week = week or dp_engine.current_week()
    snap = dp_history.load_owner(week, owner)
    if snap is None or snap.empty:
        return None
    site = (config.settings().get("upload") or {}).get("to_site", "")
    return upload.dp_workbook(snap, site), f"DP {week.split('-')[-1]} {owner}.xlsx"


# ---- 월요일 자원점검 업로드 ----------------------------------------------------

def resource_table(owner: str, week: str) -> pd.DataFrame | None:
    """그 DP 주차의 자원점검 표 (월요일 '자원점검 업로드' 화면). 확정 기록이 없으면 None."""
    t = week_snapshot(week, owner)
    return None if t.empty else t


def upload_file(owner: str, week: str) -> tuple[bytes, str] | None:
    """자원점검 업로드 엑셀 (DP Upload.xlsx 양식) (bytes, 파일 이름). 그 주차 확정 기록이 없으면 None."""
    t = resource_table(owner, week)
    if t is None:
        return None
    site = (config.settings().get("upload") or {}).get("to_site", "")
    return upload.workbook(t[t["upload"]], site), f"DP Upload {week.split('-')[-1]} {owner}.xlsx"


# ---- Base Item -----------------------------------------------------------------

def base_item_list() -> pd.DataFrame:
    """지금 쓰는 아이템 + Group·담당 (Item Master)."""
    a = base_items.active().drop(columns=["group"])
    m = master()
    if m is None:
        return a.assign(product_group=None, owner=None, plc_status=None)
    return a.merge(m[["item", "product_group", "owner", "plc_status"]], on="item", how="left")


def item_groups() -> dict[str, str]:
    """Group → 담당 (settings.yaml owners)."""
    return dict(config.settings().get("owners") or {})


def _rebuild_items() -> None:
    item_master.rebuild()
    dp_engine.rebuild()
    metrics_mod.rebuild()


def add_base_item(item: str, name: str, group: str | None, rr: float | None = None, eoh: float | None = None,
                  memo: str = "") -> None:
    """새 아이템을 넣는다. R/R·EOH를 주면 RR 기준월 값으로 같이 저장한다."""
    item = item.strip()
    if not item:
        raise ValueError("Item 코드를 입력하십시오")
    if item in set(base_items.active()["item"]):
        raise ValueError(f"{item}: 이미 Base Item에 등록되어 있습니다")
    records = [inputs.record(item, "base_item", "", 1, memo=memo, text=(name or "").strip() or item,
                             info={"group": group})]
    month = dp_plan_meta().get("rr_base_month")
    for field, value in (("rr", rr), ("eoh", eoh)):
        if value:
            records.append(inputs.record(item, field, month, value, memo="새 아이템"))
    inputs.append(records)
    _rebuild_items()


def set_item_group(item: str, group: str) -> None:
    """Group(담당)을 정한다. 담당이 비어 있는 Base Item에 쓴다."""
    inputs.append([inputs.record(item, "base_item", "", 1, memo="Group 지정", info={"group": group})])
    _rebuild_items()


def remove_base_item(item: str) -> None:
    """툴에서 넣은 아이템을 뺀다 (기록은 남는다)."""
    inputs.append([inputs.record(item, "base_item", "", None, memo="뺌")])
    _rebuild_items()


# ---- Inbound -------------------------------------------------------------------

class InboundFileError(Exception):
    """고른 파일을 쓸 수 없을 때 (잠김, 다른 파일). 메시지를 화면에 그대로 보여준다."""


INBOUND_READERS = {inbound_store.SYNC: readers.sync_plan, inbound_store.TRANSIT: readers.in_transit,
                   inbound_store.GR: readers.gr}
INBOUND_NAMES = {inbound_store.SYNC: "Sync Plan (MP_PSI)", inbound_store.TRANSIT: "In-transit (DYN_In-transit)",
                 inbound_store.GR: "GR"}
INBOUND_FRESH = {inbound_store.SYNC: 6, inbound_store.TRANSIT: 3}   # 영업일. 지나면 '오늘' 화면에 오래됨 (Claude 제안)


def _read_upload(kind: str, name: str, data: bytes) -> tuple[pd.DataFrame, dict]:
    """화면에서 고른 파일을 읽는다. 잠겼거나 다른 파일이면 InboundFileError."""
    if data.startswith(files.DRM_MAGIC):
        raise InboundFileError(f"{name} 파일이 DRM으로 잠겨 있습니다. Decrypt 후 다시 선택하십시오.")
    if not data.startswith(files.ZIP_MAGIC):
        raise InboundFileError(f"{name}: 엑셀 파일이 아닙니다.")
    tmp = config.data_dir() / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    path = tmp / Path(name).name
    path.write_bytes(data)
    try:
        tables, extra = INBOUND_READERS[kind](path)
    except Exception as e:  # noqa: BLE001 - 다른 파일을 고른 경우가 대부분이라 그대로 보여준다
        raise InboundFileError(f"{name}: {INBOUND_NAMES[kind]} 파일 형식이 아닙니다. ({e})") from e
    finally:
        path.unlink(missing_ok=True)
    return next(iter(tables.values())), extra


def _name_date(name: str) -> str | None:
    """파일 이름 속 시각 → 'YYYY-MM-DD' (MP_PSI_20261106135954.xlsx)."""
    m = re.search(r"(20\d{6})\d{6}", name)
    return f"{m[1][:4]}-{m[1][4:6]}-{m[1][6:8]}" if m else None


def _after_inbound() -> None:
    inbound_mod.rebuild()
    dp_engine.rebuild()
    metrics_mod.rebuild()


def update_sync_plan(name: str, data: bytes) -> str:
    """새 Sync Plan을 베이스로 올린다. 지금보다 오래된 주차면 받지 않는다. 결과 문장을 돌려준다."""
    plan, extra = _read_upload(inbound_store.SYNC, name, data)
    now, _ = inbound_store.latest(inbound_store.SYNC)
    if now and extra["plan_version"] < now["plan_version"]:
        raise InboundFileError(f"{extra['plan_version']}은 현재 기준 {now['plan_version']}보다 이전 Sync Plan입니다.")
    if now and now.get("plan_version") == extra["plan_version"] and now.get("total") == float(plan["qty"].sum()):
        raise InboundFileError(f"현재 사용 중인 Sync Plan입니다 ({extra['plan_version']}, 합계 동일).")
    inbound_store.save(inbound_store.SYNC, plan, {**extra, "file": name, "file_date": _name_date(name),
                                                  "total": float(plan["qty"].sum())})
    _after_inbound()
    im = inbound_meta()
    return (f"Sync Plan 반영 완료: {extra['plan_version']} ({im['plan_total']:,.0f}대). "
            f"{im['gr_since']} 이후 GR {im['gr_total']:,.0f}대 차감 반영.")


def add_old_sync_plan(name: str, data: bytes) -> str:
    """지난 Sync Plan을 비교용으로 넣는다. 기준은 바뀌지 않는다 (가장 높은 버전이 기준)."""
    plan, extra = _read_upload(inbound_store.SYNC, name, data)
    now, _ = inbound_store.latest(inbound_store.SYNC)
    if not now or extra["plan_version"] >= now["plan_version"]:
        raise InboundFileError(f"비교용은 현재 기준 {now.get('plan_version')}보다 이전 Sync Plan만 등록 가능합니다.")
    inbound_store.save(inbound_store.SYNC, plan, {**extra, "file": name, "file_date": _name_date(name),
                                                  "total": float(plan["qty"].sum())})
    inbound_mod.rebuild()
    return f"비교 기준 등록: {extra['plan_version']}"


def update_in_transit(name: str, data: bytes) -> str:
    """새 In-transit을 올린다. 파일 이름의 날짜가 지난 ETA를 옮길 '이번 주'가 된다."""
    t, _ = _read_upload(inbound_store.TRANSIT, name, data)
    now, _ = inbound_store.latest(inbound_store.TRANSIT)
    date_ = _name_date(name) or date.today().isoformat()
    if now and date_ < (now.get("file_date") or ""):
        raise InboundFileError(f"{name}: 현재 사용 파일({now['file_date']})보다 이전 날짜입니다.")
    inbound_store.save(inbound_store.TRANSIT, t, {"file": name, "file_date": date_, "total": float(t["qty"].sum())})
    _after_inbound()
    return f"In-transit 반영 완료 ({date_}, {t['qty'].sum():,.0f}대)."


def preview_gr(uploads: list[tuple[str, bytes]]) -> dict:
    """고른 GR 파일에서 뺄 줄을 정리한다 (빼기 전 확인 창). lines = 새로 뺄 줄.
    GR Status C만, 이미 뺀 줄(GR Document + 줄 번호)은 건너뛴다. Sync Plan 주차 월요일 전 입고도 건너뛴다."""
    frames = []
    for name, data in uploads:
        df, _ = _read_upload(inbound_store.GR, name, data)
        frames.append(df.assign(file=name))
    g = pd.concat(frames, ignore_index=True)
    not_done = g[g["gr_status"] != "C"]
    g = g[g["gr_status"] == "C"].drop_duplicates(["gr_doc", "gr_item"])
    since = inbound_meta().get("gr_since")
    if not since:
        raise InboundFileError("Sync Plan을 먼저 업로드하십시오. GR은 Sync Plan에서 차감합니다.")
    done = {(d, i) for _, b in inbound_store.gr_batches(since) if len(b) for d, i in zip(b["gr_doc"], b["gr_item"])}
    dup = pd.Series([(d, i) in done for d, i in zip(g["gr_doc"], g["gr_item"])], index=g.index, dtype=bool)
    old = g["gr_date"] < pd.Timestamp(since)
    tm, transit = inbound_store.latest(inbound_store.TRANSIT)
    now = inbound_mod.transit_weeks(transit, inbound_mod.week_of(config.today()))
    lines = inbound_mod.gr_targets(g[~dup & ~old], now)     # 그 컨테이너가 도착하기로 한 주차 (In-transit에서 BL·PO·수량으로 찾음)
    left = _cached(inbound_mod.CACHE)
    left = left.groupby("item")["total"].sum() if left is not None else pd.Series(dtype=float)
    by_item = lines.groupby("item", as_index=False)["qty"].sum()
    by_item["plan_left"] = by_item["item"].map(left).fillna(0)
    by_item["over"] = (by_item["qty"] - by_item["plan_left"]).clip(lower=0)
    week_text = lambda w: " · ".join(sorted({f"W{x[-2:]}" for x in w}))
    by_sn = (lines.groupby("sn_no", as_index=False, dropna=False)
             .agg(gr_date=("gr_date", "min"), bl_no=("bl_no", "first"), container=("container", "first"),
                  items=("item", "nunique"), qty=("qty", "sum"), weeks=("plan_week", week_text),
                  found=("found", lambda f: " · ".join(sorted(set(f))))))
    return {"lines": lines, "by_sn": by_sn, "by_item": by_item, "files": [n for n, _ in uploads],
            "already": g[dup], "before_plan": g[~dup & old], "not_done": not_done, "since": since}


def apply_gr(preview: dict, memo: str = "") -> str:
    """확인한 입고를 뺀다."""
    lines = preview["lines"].drop(columns=["file", "line"], errors="ignore")    # line = 지금 In-transit 줄 번호라 저장하지 않는다
    dates = sorted({d.strftime("%Y-%m-%d") for d in lines["gr_date"]})
    weeks = sorted(set(lines["plan_week"].dropna()))
    inbound_store.save(inbound_store.GR, lines, {"files": preview["files"], "sn": sorted(set(lines["sn_no"].dropna())),
                                                 "qty": float(lines["qty"].sum()), "gr_dates": dates, "weeks": weeks,
                                                 "memo": memo})
    _after_inbound()
    return f"GR 차감 완료: {lines['qty'].sum():,.0f}대 (SN {lines['sn_no'].nunique()}건)."


def cancel_gr(path_name: str) -> None:
    """뺀 입고 묶음을 취소한다."""
    inbound_store.cancel_gr(path_name)
    _after_inbound()


def inbound_meta() -> dict:
    return store.read_cache_meta(inbound_mod.META)


# ---- 프로젝트 정보 (2026-11-10, docs/project-info.md) ------------------------------------------

_po_memo: dict = {}


def project_po_lines() -> pd.DataFrame | None:
    """PO(S/O 라인) 데이터. 가장 최근 스냅샷 (스냅샷이 같으면 다시 읽지 않는다)."""
    e = store.latest_entry("project_po")
    if not e:
        return None
    if _po_memo.get("snapshot") != e["snapshot"]:
        _po_memo.update(snapshot=e["snapshot"], lines=store.load_table("project_po", "lines", e))
    return _po_memo["lines"]


def project_po_info() -> dict:
    """PO 데이터 파일 이름·날짜 (화면 안내용)."""
    e = store.latest_entry("project_po") or {}
    return {"file": e.get("file"), "file_date": (e.get("file_date") or "")[:10] or None, "po_count": e.get("po_count")}


def projects() -> pd.DataFrame:
    """사람이 넣은 프로젝트 + PO 데이터 매칭 (오더 금액·오더율·상태)."""
    return projects_mod.match(projects_mod.active(), project_po_lines())


def project_detail(po: str) -> pd.DataFrame:
    """그 PO#의 S/O 줄."""
    return projects_mod.detail(po, project_po_lines())


def save_projects(before: list[dict], after: list[dict]) -> str:
    """화면 표에서 바뀐 줄만 저장한다. 결과 문장을 돌려준다."""
    r = projects_mod.save(before, after)
    parts = [f"{label} {r[k]}줄" for k, label in (("added", "추가"), ("changed", "수정"), ("removed", "삭제")) if r[k]]
    return ("저장 완료: " + ", ".join(parts)) if parts else "변경된 행이 없습니다."


# ---- RR 리뷰 (2026-11-10, docs/run-rate.md) ------------------------------------------------
# 계산은 소수 그대로 (엑셀처럼 RR 소수 1자리), 화면에서만 정수로 보인다 (사용자 2026-11-10).
# 이 화면은 DP 계산을 바꾸지 않는다. 제안 RR을 DP에 넣을지는 DP 계산 쪽 작업 때 정한다.

def rr_meta() -> dict:
    return store.read_cache_meta(rr_engine.META)


def rr_params() -> dict:
    return rr_engine.params()


def rr_basis() -> str | None:
    """RR 기준월 (예 '2026-11'). 리뷰 입력은 이 단위로 묶인다."""
    return (rr_meta().get("periods") or {}).get("basis")


def rr_table() -> pd.DataFrame | None:
    """아이템마다 엔진 결과 + 사람이 넣은 보정 RR·사유·상태 + 최종 RR (보정 RR이 있으면 그것, 없으면 제안 RR)."""
    df = _cached(rr_engine.CACHE)
    if df is None or df.empty:
        return None
    df = pd.concat([df, _rr_missing_rows(df)], ignore_index=True)
    rev = rr_review.current(rr_basis() or "")
    df = df.merge(rev.rename(columns={"by": "review_by", "at": "review_at"}), on="item", how="left")
    # 지난 리뷰 (지난 기준월의 마지막 결정, 사용자 2026-11-11). 열 이름 앞에 prev_
    prev = rr_review.previous(rr_basis() or "")
    df = df.merge(prev.rename(columns={c: f"prev_{c}" for c in prev.columns if c != "item"}), on="item", how="left")
    # 화면에는 Base Item만 (사용자 2026-11-11). 계산·검증은 RR 파일 전체 SKU로 (K/V 그룹 배분 등)
    df["in_base"] = df["item"].isin(set(base_items.active()["item"]))
    df["no_rr"] = df["no_rr"].fillna(False).astype(bool) if "no_rr" in df else False
    df["status"] = df["status"].fillna(rr_review.NOT_YET)
    df["final_rr"] = df["adj_rr"].where(df["adj_rr"].notna(), df["proposed_rr"])
    # 허브 데이터에서: 담당·PLC (Item Master), OH (가장 최근 재고 파일 CFC5 + SCA3). RR 파일에는 없다
    m = metrics()
    hub_cols = {"owner": "owner", "plc_status": "plc_hub", "inv_unrestricted": "inv"}
    if m is not None and set(hub_cols) <= set(m.columns):
        df = df.merge(m[["item", *hub_cols]].rename(columns=hub_cols), on="item", how="left")
    else:
        df = df.assign(owner=None, plc_hub=None, inv=np.nan)
    df["plc"] = df["plc_hub"].where(df["plc_hub"].notna(), df["plc_status"])
    df["inv"] = pd.to_numeric(df["inv"], errors="coerce")
    final = pd.to_numeric(df["final_rr"], errors="coerce")
    df["inv_months"] = (df["inv"] / final.where(final > 0)).round(1)
    # 검토 필요인데 아직 정하지 않음 (미검토·보류) → 목록의 '최종' 칸을 비운다
    df["open"] = df["review"] & df["status"].isin([rr_review.NOT_YET, rr_review.HOLD])
    return df


def _rr_missing_rows(df: pd.DataFrame) -> pd.DataFrame:
    """RR 파일에 없는 Base Item 줄 (사용자 2026-11-11: RR 리뷰에는 Base Item 전부, 없는 것은 수동 입력).
    판매·계산 근거가 없어 제안 RR은 비우고 '📝 RR 파일 없음' 플래그(검토 필요)를 붙인다. 최종 RR은 사람이 넣은 값.
    현행 R/R은 허브의 DP list V열 (RR 파일 현행과 같은 열). 이름·구분·시리즈는 Item Master."""
    miss = sorted(set(base_items.active()["item"]) - set(df["item"]))
    if not miss:
        return pd.DataFrame(columns=df.columns)
    m = metrics()
    info = (m.set_index("item").reindex(miss) if m is not None else pd.DataFrame(index=pd.Index(miss, name="item")))
    get = lambda c: info[c].tolist() if c in info else [None] * len(miss)
    n_ = len(miss)
    return pd.DataFrame({
        "item": miss, "item_name": get("item_name"), "product_group": get("product_group"), "series": get("series"),
        "model_group": get("model_group"), "rr_current": pd.to_numeric(pd.Series(get("rr_current")), errors="coerce").tolist(),
        "proposed_rr": [np.nan] * n_, "delta": [np.nan] * n_, "delta_pct": [np.nan] * n_, "rule": [None] * n_,
        "flags": [["norr"]] * n_, "flag_reasons": [["RR 파일에 없음 (Sell-in·Sell-out 없음)"]] * n_,
        "flag_icons": [rr_engine.FLAG["norr"][0]] * n_, "review": [True] * n_, "priority": [rr_engine.PRIORITY["norr"]] * n_,
        "severity": [len(rr_engine.FLAGS)] * n_, "si12": [[]] * n_, "so12": [[]] * n_,
        "has_so": [False] * n_, "kv": [False] * n_, "taa": [False] * n_, "no_rr": [True] * n_})


def rr_base_missing() -> list[str]:
    """Base Item 중 RR 파일에 없는 아이템 (제안 RR 없음 → RR 리뷰 목록에서 '📝 RR 파일 없음', 직접 입력)."""
    df = _cached(rr_engine.CACHE)
    have = set(df["item"]) if df is not None else set()
    return sorted(set(base_items.active()["item"]) - have)


def rr_months(item: str) -> pd.DataFrame:
    """그 아이템의 달별 Sell-in·Sell-out (계산에 쓴 값, K/V는 배분 후)."""
    df = _cached(rr_engine.MONTHS)
    if df is None:
        return pd.DataFrame(columns=["item", "kind", "month", "qty", "after_project"])
    return df[df["item"] == item]


def rr_check() -> pd.DataFrame:
    df = _cached(rr_engine.CHECK)
    return df if df is not None else pd.DataFrame(columns=["item", "stage", "column", "excel", "engine", "columns"])


def rr_review_history(item: str) -> pd.DataFrame:
    return rr_review.history(item)


_rr_snap: dict = {}


def rr_pos_master(item: str) -> pd.DataFrame:
    """RR 파일 POS master에서 그 아이템으로 이어지는 POS SKU (PO SKU 또는 DP Material이 그 아이템)."""
    e = store.latest_entry(rr_engine.SOURCE)
    if not e:
        return pd.DataFrame(columns=["pos_sku", "po_sku", "kind", "dp_material", "qty"])
    if _rr_snap.get("snapshot") != e["snapshot"]:
        _rr_snap.update(snapshot=e["snapshot"], pos=store.load_table(rr_engine.SOURCE, "pos_master", e))
    pm = _rr_snap["pos"]
    if pm is None:
        return pd.DataFrame(columns=["pos_sku", "po_sku", "kind", "dp_material", "qty"])
    return pm[(pm["po_sku"] == item) | (pm["dp_material"] == item)].drop_duplicates()


def save_rr_reviews(before: list[dict], after: list[dict]) -> str:
    """보정 RR·사유·상태 중 바뀐 아이템만 저장. 결과 문장."""
    n = rr_review.save(rr_basis() or "", before, after)
    return f"저장 완료: {n}개 Item" if n else "변경된 값이 없습니다."


def today() -> date:
    return config.today()


def inbound_status() -> list[dict]:
    """Inbound 파일 세 가지의 지금 상태 [kind, name, value, note, by, at, old]. 화면 위 한 줄과 '파일 올리기'에 쓴다."""
    im = inbound_meta()
    now = config.today()
    old = lambda at, kind: bool(at) and int(np.busday_count(date.fromisoformat(at[:10]), now)) > INBOUND_FRESH[kind]
    day = lambda d: f"{d[5:7]}/{d[8:10]}" if d else None
    return [
        {"kind": inbound_store.SYNC, "name": "Sync Plan", "value": im.get("plan_version") or "없음",
         "note": "", "by": im.get("plan_by"), "at": im.get("plan_at"),
         "old": old(im.get("plan_at"), inbound_store.SYNC)},
        {"kind": inbound_store.TRANSIT, "name": "In-transit", "value": day(im.get("transit_date")) or "없음", "note": "",
         "by": im.get("transit_by"), "at": im.get("transit_at"), "old": old(im.get("transit_at"), inbound_store.TRANSIT)},
        {"kind": inbound_store.GR, "name": "GR", "value": f"{im.get('gr_total', 0):,.0f}대 차감",
         "note": f"(GR Date ~{day(im['gr_last'])})" if im.get("gr_last") else "없음",
         "by": (im.get("gr_batches") or [{}])[0].get("by"), "at": (im.get("gr_batches") or [{}])[0].get("at"), "old": False},
    ]


def inbound_stale() -> bool:
    """다른 사람이 올린 파일이 동기화됐으면 True."""
    return inbound_mod.stale(inbound_meta())


def inbound_monthly() -> pd.DataFrame | None:
    """아이템 × 달 세 칸 (qty = DP 계산 입고) + 담당."""
    w = _cached(inbound_mod.MONTHLY)
    m = metrics()
    if w is None or m is None:
        return w
    first = dp_calendar()["month_keys"][0]     # 지난 달 몫은 M1 (dp_engine.plan과 같은 규칙)
    w = w.assign(month=w["month"].where(w["month"] >= first, first))
    w = w.groupby(["item", "month"], as_index=False)[inbound_mod.BUCKETS + inbound_mod.SPLIT + ["qty"]].sum()
    return w.merge(m[["item", "owner"]], on="item", how="left")


def inbound_moved() -> pd.DataFrame | None:
    """ETA·운송수단이 Sync와 달라진 In-transit + 담당."""
    w = _cached(inbound_mod.MOVED)
    m = metrics()
    if w is None or w.empty or m is None:
        return w
    return w.merge(m[["item", "owner"]], on="item", how="left")


def inbound_overdue() -> pd.DataFrame:
    """ETA가 지났는데 아직 In-transit에 남은 줄."""
    t = _cached(inbound_mod.TRANSIT)
    if t is None or "overdue" not in t or t.empty:
        return pd.DataFrame(columns=["item", "qty", "eta", "mode", "bl_no", "container", "status"])
    return t[t["overdue"].astype(bool)].sort_values(["eta", "item"])


def inbound_by_month(items: list[str] | None = None) -> pd.DataFrame | None:
    """달별 세 칸 + 같은 달 DP 입고 (M1~M3). items를 주면 그 아이템만. 화면 합계와 DP가 같은지 보는 표."""
    t = inbound_monthly()
    if t is None:
        return None
    plan = dp_plan()
    cal = dp_calendar()
    if items is not None:
        t, plan = t[t["item"].isin(items)], plan[plan["item"].isin(items)]
    out = t.groupby("month", as_index=False)[inbound_mod.BUCKETS + inbound_mod.SPLIT + ["qty"]].sum()
    dp = {k: float(plan[f"inbound_m{i}"].sum()) for i, k in enumerate(cal["month_keys"][:cal["months"]], start=1)}
    out["dp"] = out["month"].map(dp)
    out["m"] = out["month"].map({k: i for i, k in enumerate(dp, start=1)})
    return out


def inbound_not_in_base() -> pd.DataFrame:
    """Sync Plan에 있는데 Base Item에 없어서 DP에 안 들어가는 아이템."""
    t = _cached(inbound_mod.MONTHLY)
    if t is None:
        return pd.DataFrame(columns=["item", "qty"])
    t = t[~t["item"].isin(set(base_items.active()["item"]))]
    return t.groupby("item", as_index=False)["qty"].sum().sort_values("qty", ascending=False)


def inbound_since_confirm(owner: str, week: str) -> pd.DataFrame:
    """그 주차 확정 뒤 입고가 바뀐 아이템 [item, before, now, diff, gr]. 확정 기록은 그때 값으로 남아 있다.
    확정 뒤 올린 GR로 줄어든 수량은 재고로 옮겨 간 것이라 그것만 바뀐 아이템은 뺀다."""
    snap = dp_history.load_owner(week, owner)
    monthly = _cached(inbound_mod.MONTHLY)
    cols = ["item", "before", "now", "diff", "gr"]
    if snap is None or snap.empty or monthly is None:
        return pd.DataFrame(columns=cols)
    first = snap.iloc[0]
    keys = {f"inbound_m{i}": first[f"month_m{i}"] for i in range(1, int(first["months"]) + 1)}
    before = snap.set_index("item")[list(keys)].apply(pd.to_numeric, errors="coerce").fillna(0).rename(columns=keys)
    now = (monthly.pivot_table(index="item", columns="month", values="qty", aggfunc="sum")
           .reindex(index=before.index, columns=before.columns).fillna(0))
    frames = [b for m, b in inbound_store.gr_batches(first["confirmed_at"][:10]) if len(b) and m["at"] >= first["confirmed_at"]]
    gr = pd.concat(frames).groupby("item")["qty"].sum() if frames else pd.Series(dtype=float)
    gr = gr.reindex(before.index).fillna(0)
    rest = now - before
    rest.iloc[:, 0] += gr                    # 입고는 가장 이른 주차부터 빠진다
    changed = (rest.abs() >= 0.5).any(axis=1)
    out = pd.DataFrame({"before": before.sum(axis=1), "now": now.sum(axis=1), "gr": gr})[changed]
    out["diff"] = out["now"] - out["before"]
    return out.reset_index()[cols]


def sync_compare() -> dict | None:
    """지금 Sync Plan과 그 바로 전 버전 비교. 올린 것이 하나뿐이면 None."""
    plans = inbound_store.sync_plans(2)
    if len(plans) < 2:
        return None
    (new_meta, new), (old_meta, old) = plans
    since, until = (pd.Timestamp(inbound_mod.week_monday(m["plan_week"])) for m in (old_meta, new_meta))
    frames = [b for _, b in inbound_store.gr_batches(since.date().isoformat()) if len(b)]
    gr = (pd.concat(frames).drop_duplicates(["gr_doc", "gr_item"]) if frames
          else pd.DataFrame(columns=["item", "qty", "gr_date", "container"]))
    if len(gr):
        gr = gr[(gr["gr_date"] >= since) & (gr["gr_date"] < until)]
    out = inbound_mod.compare(old, new, new_meta["plan_week"], gr, old_meta.get("plan_week"))
    m = metrics()
    if m is not None:
        out["items"] = out["items"].merge(m[["item", "owner"]], on="item", how="left")
        out["months"] = out["months"].merge(m[["item", "owner"]], on="item", how="left")
    return {**out, "new_version": new_meta["plan_version"], "old_version": old_meta["plan_version"],
            "gr": float(pd.to_numeric(gr["qty"]).sum()) if len(gr) else 0.0}


def inbound_weekly() -> pd.DataFrame | None:
    """아이템 × 주차 세 칸 (In-transit·Air·Vessel) + 담당."""
    w = _cached(inbound_mod.CACHE)
    m = metrics()
    if w is None or w.empty or m is None:
        return w
    return w.merge(m[["item", "owner", "product_group"]], on="item", how="left")


def item_inbound(item: str) -> dict | None:
    """이 아이템의 주차별 세 칸과 오는 중인 줄 (ETA, BL, 컨테이너, PO)."""
    w = _cached(inbound_mod.CACHE)
    if w is None:
        return None
    t = _cached(inbound_mod.TRANSIT)
    lines = t[t["item"] == item].sort_values("eta") if t is not None and len(t) else pd.DataFrame()
    keep = ["week", "eta", "overdue", "mode", "qty", "ship_date", "status", "po_no", "po_item", "bl_no", "container"]
    return {"weeks": records(w[w["item"] == item].sort_values("week")),
            "transit": records(lines[keep]) if len(lines) else []}


def input_status() -> dict:
    """사람 입력 폴더와 사람별 파일 상태 (마지막 저장 시각, 줄 수, 깨진 줄, DRM 잠김)."""
    folder, where = inputs.folder()
    _, files_ = inputs.load()
    return {"folder": str(folder), "where": where, "writer": inputs.writer(), "files": files_}


INVENTORY_QTY = ["unrestricted", "blocked", "allocated", "so_qty", "do_qty", "available", "open_po", "amount"]


def inventory(item: str, calc: dict | None = None, eoh_target=None) -> dict | None:
    """가장 최근 재고 (CFC5 + SCA3 = OH). 재고가 없는 아이템은 0으로 돌려준다 (재고 데이터 자체가 없으면 None)."""
    inv = _cached("inventory_latest")
    m = store.read_cache_meta("inventory_meta")
    if inv is None or not m.get("key_date"):
        return None
    rows = inv[inv["item"] == item]
    totals = {k: _plain(rows[k].sum()) if len(rows) else 0 for k in INVENTORY_QTY}
    out = {"as_of": m["key_date"], "source": m["source"], "file": m["file"], "locations": m["locations"],
           **totals}
    # 수주 재고 (Special Stock Ind. E): 특정 S/O에 묶인 재고. 합계에 들어 있다
    so_stock = rows[rows["special_stock"] == "E"]
    out["sales_order_stock"] = records(so_stock[["sales_doc", "unrestricted"]]) if len(so_stock) else []
    out["price"] = _plain(rows["price"].max()) if len(rows) else None
    rr = (calc or {}).get("rr")
    out["months_of_cover"] = round(out["unrestricted"] / rr, 1) if rr else None
    out["vs_eoh_target"] = (out["unrestricted"] - eoh_target) if eoh_target is not None else None
    return out


FLOW_COLUMNS = ["gi_qty", "gi_amt", "return_gi_qty", "open_so_qty", "open_so_amt", "so_confirm_qty",
                "so_not_confirm_qty", "so_block_qty", "not_gi_qty", "return_open_qty",
                "adi_available_qty", "adi_total_qty", "adi_allocated_qty", "adi_backorder_qty", "adi_open_po_qty",
                "adi_past_due_po_qty", "adi_available_amt", "adi_total_amt"]


def item_flow(item: str) -> dict | None:
    """이번 달 GI, Open SO, ADI 채널 재고 (정의: hub/flow.py). 값이 없으면 0."""
    f = _cached("item_flow")
    m = store.read_cache_meta("flow_meta")
    if f is None or not m:
        return None
    rows = f[f["item"] == item]
    out = {c: (_plain(rows.iloc[0][c]) if len(rows) and c in rows.columns else 0) for c in FLOW_COLUMNS}
    out["sources"] = {k: m.get(k) for k in ("orders", "returns", "adi", "mapping")}
    d = _cached("adi_detail")
    if d is not None:
        rows = d[d["item"] == item]
        out["adi_by_country"] = records(rows.groupby("country", as_index=False)[
            ["available_qty", "total_qty", "allocated_qty", "backorder_qty", "open_po_qty"]].sum())
        out["adi_parts"] = sorted(rows["part"].unique().tolist())
    return out


def flow_meta() -> dict:
    return store.read_cache_meta("flow_meta")


def kv_switch(item: str) -> dict | None:
    """K(한국)↔V(베트남) 생산 전환 모델이면 합산 RR 정보와 이 아이템의 배분비율."""
    kv = _cached("kv_models")
    if kv is None:
        return None
    rows = kv[(kv["k_sku"] == item) | (kv["v_sku"] == item)]
    if rows.empty:
        return None
    out = {k: _plain(v) for k, v in rows.iloc[0].items()}
    ratio = _cached("kv_ratio")
    if ratio is not None:
        r = ratio[ratio["item"] == item]
        out["share_of_this_sku"] = _plain(r.iloc[0]["share"]) if not r.empty else None
    return out


def similar_items(rec: pd.Series, m: pd.DataFrame) -> dict:
    """같은 모델의 다른 향지·생산지 / 버전만 다른 아이템(자동 후보) / 같은 Model Group."""
    cols = ["item", "site", "dest", "plc_status", "sra", "eol", "eop", "in_dp_list", "version"]
    same_model = m[(m["base"] == rec["base"]) & (m["item"] != rec["item"])]
    versions = pd.DataFrame(columns=cols)
    if isinstance(rec.get("family_key"), str):
        versions = m[(m["family_key"] == rec["family_key"]) & (m["base"] != rec["base"])].sort_values(["version", "item"])
    ignore = set(config.settings().get("ignore_model_groups", []))
    group = pd.DataFrame(columns=cols)
    mg = rec.get("model_group")
    if isinstance(mg, str) and mg and mg not in ignore:
        group = m[(m["model_group"] == mg) & (m["base"] != rec["base"]) & ~m["item"].isin(versions["item"])]
    return {
        "same_model_other_suffix": records(same_model[cols]),
        "other_versions_candidates": records(versions[cols]),
        "same_model_group": records(group[cols]),
    }


# ---- 데이터 현황 ----------------------------------------------------------

def data_status() -> list[dict]:
    """원천마다 마지막으로 불러온 파일과 지금 폴더 상태. 파일을 읽지는 않는다 (빠름)."""
    out = []
    for src in config.sources():
        row = {"id": src["id"], "name": src["name"], "description": src.get("description", ""),
               "enabled": src.get("enabled", True), "pattern": src.get("pattern"),
               "root": src.get("root"), "folder": src.get("folder")}
        last = store.latest_entry(src["id"])
        if last:
            row.update(last_file=last["file"], last_file_date=last.get("file_date"),
                       loaded_at=last["loaded_at"], rows=last.get("rows"), snapshots=len(store.entries(src["id"])),
                       dp_week=last.get("dp_week"))
        if row["enabled"]:
            root = paths.resolve_root(src["root"])
            row["folder_path"] = str(root / src.get("folder", ".")) if root else None
            row["fresh_days"] = src.get("fresh_days")
            path, _ = files.pick_latest(root / src.get("folder", "."), src) if root else (None, None)
            row["current_file"] = path.name if path else None
            row["current_locked"] = bool(path) and files.lock_state(path) == files.LOCKED
            row["new_file_waiting"] = bool(path) and (not last or files.fingerprint(path)["file"] != last["file"]
                                                      or files.fingerprint(path)["mtime"] != last.get("mtime"))
        out.append(row)
    return out


# '오늘' 화면 데이터 상태
OK, OLD, NEW, DECRYPT, MISSING = "ok", "old", "new", "decrypt", "missing"


def data_today(today: date | None = None) -> list[dict]:
    """'오늘' 화면의 데이터 준비: 원천마다 지금 쓰는 파일, 영업일로 며칠 전인지, 상태.
    상태: decrypt = 더 새 파일이 있는데 잠김(Decrypt 필요), new = 더 새 파일이 풀려 있음(읽으면 됨),
          old = 쓰는 파일이 sources.yaml fresh_days보다 오래됨, missing = 파일 없음, ok."""
    today = today or date.today()
    out = []
    for s in data_status():
        if not s["enabled"]:
            continue
        used = (s.get("last_file_date") or "")[:10]
        age = int(np.busday_count(date.fromisoformat(used), today)) if used else None
        if s.get("current_locked") and s.get("new_file_waiting"):
            state = DECRYPT
        elif s.get("new_file_waiting") and not s.get("current_locked"):
            state = NEW
        elif not s.get("last_file"):
            state = DECRYPT if s.get("current_locked") else MISSING
        elif s.get("fresh_days") is not None and age is not None and age > s["fresh_days"]:
            state = OLD
        else:
            state = OK
        out.append({"id": s["id"], "name": s["name"], "description": s["description"], "state": state,
                    "file": s.get("last_file"), "file_date": used or None, "business_days_old": age,
                    "waiting_file": s.get("current_file") if s.get("new_file_waiting") else None,
                    "folder": s.get("folder_path"), "fresh_days": s.get("fresh_days"),
                    # 웹 버전은 폴더를 열 수 없다 → '원천 파일' 화면에서 올린다
                    **({"page": web.PAGE} if web.is_web() else {})})
    # Sync Plan·In-transit은 폴더가 아니라 'Inbound' 화면에서 올린다
    for kind, name in ((inbound_store.SYNC, "Sync Plan"), (inbound_store.TRANSIT, "In-transit")):
        m, _ = inbound_store.latest(kind)
        used = (m.get("at") or "")[:10]
        age = int(np.busday_count(date.fromisoformat(used), today)) if used else None
        state = MISSING if not m else OLD if age > INBOUND_FRESH[kind] else OK
        out.append({"id": kind, "name": name, "description": "", "state": state, "file": m.get("file"),
                    "file_date": used or None, "business_days_old": age, "waiting_file": None, "folder": None,
                    "page": "views/inbound.py", "fresh_days": INBOUND_FRESH[kind]})
    return out


def open_folder(source_id: str) -> bool:
    """원천 폴더를 탐색기로 연다 (앱은 이 PC에서만 돈다: .streamlit/config.toml address = localhost)."""
    if web.is_web():    # 브라우저에는 탐색기가 없다
        return False
    src = config.source(source_id)
    root = paths.resolve_root(src["root"])
    if root is None:
        return False
    folder = root / src.get("folder", ".")
    if not folder.is_dir():
        return False
    os.startfile(str(folder))  # noqa: S606 — Windows 탐색기
    return True


def refresh(force: bool = False) -> list[dict]:
    return ingest.run_all(force=force)


def shared_root() -> str | None:
    p = paths.find_shared_root()
    return str(p) if p else None


# ---- 변환 도우미 ----------------------------------------------------------

def _plain(v):
    if v is None:
        return None
    if isinstance(v, (pd.Timestamp, datetime, date)):
        return None if pd.isna(v) else v.strftime("%Y-%m-%d")
    if isinstance(v, float) and pd.isna(v):
        return None
    if v is pd.NA or v is pd.NaT:
        return None
    if hasattr(v, "item"):  # numpy 숫자 → 파이썬 숫자
        try:
            return v.item()
        except (ValueError, AttributeError):
            pass
    return v


def records(df: pd.DataFrame) -> list[dict]:
    return [{k: _plain(v) for k, v in row.items()} for row in df.to_dict("records")]


def _months_until(d) -> float | None:
    if d is None or pd.isna(d):
        return None
    return round((pd.Timestamp(d) - pd.Timestamp(date.today())).days / 30.4, 1)


def _months_since(d) -> float | None:
    if d is None or pd.isna(d):
        return None
    return round((pd.Timestamp(date.today()) - pd.Timestamp(d)).days / 30.4, 1)
