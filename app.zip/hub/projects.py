"""프로젝트 정보: 사람이 넣는 프로젝트 목록 + PO(S/O) 데이터와 맞추기 (사용자 2026-11-10, docs/project-info.md).

저장: <사람 입력 폴더>/Project Info/<이름>.jsonl. 한 줄 = 프로젝트 한 줄의 그때 값.
  고치면 같은 id로 새 줄, 지우면 deleted 줄. 같은 id의 가장 최근 줄이 지금 값이고 지난 값은 남는다.
  사람마다 자기 파일에만 쓴다 (OneDrive 충돌 없음). 팀원 화면에도 같이 보인다.
  저장할 때는 화면에서 실제로 바꾼 줄만 쓴다: 다른 사람이 그 사이에 넣거나 고친 줄을 덮어쓰거나 지우지 않게.
매칭: PO#(공백 빼고 대문자) = PO 데이터의 Customer PO. 오더 금액 = S/O Net Value 합.
"""

import json
import os
import re
import time
import uuid
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import inputs

FOLDER = "Project Info"
FIELDS = ["project", "po", "date", "distributor", "amount", "rsm"]
LABELS = {"project": "프로젝트", "po": "PO#", "date": "날짜", "distributor": "Distributor", "amount": "Amount ($)",
          "rsm": "RSM/DSM"}
NO_PO, NO_ORDER, PARTIAL, FULL, OVER = "PO# 없음", "오더 없음", "일부 오더", "다 들어옴", "넣은 금액보다 많음"
TOLERANCE = 1.0      # 달러. 이 안쪽 차이는 같다고 본다 (Claude 제안)


def root() -> Path:
    return inputs.folder()[0] / FOLDER


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and v != v) or (isinstance(v, str) and not v.strip()) or v is pd.NaT


def norm_po(v) -> str:
    """PO#를 맞추는 모양: 공백을 빼고 대문자. 숫자로 붙여 넣어 생긴 '.0'도 뺀다."""
    if _blank(v):
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = re.sub(r"\s+", "", str(v)).upper()
    return s[:-2] if re.fullmatch(r"\d+\.0", s) else s


def clean(row: dict) -> dict:
    """화면의 한 줄을 저장 모양으로 (빈칸 = None, 날짜 = 'YYYY-MM-DD', 금액 = 숫자)."""
    out = {}
    for f in FIELDS:
        v = row.get(f)
        if _blank(v):
            out[f] = None
        elif f == "amount":
            try:
                out[f] = round(float(str(v).replace("$", "").replace(",", "")), 2)
            except ValueError:
                out[f] = None
        elif f == "date":
            d = pd.to_datetime(v, errors="coerce")
            out[f] = None if pd.isna(d) else d.date().isoformat()
        elif f == "po":
            s = str(int(v)) if isinstance(v, float) and v.is_integer() else str(v).strip()
            out[f] = s[:-2] if re.fullmatch(r"\d+\.0", s) else s
        else:
            out[f] = str(v).strip()
    return out


# ---- 읽기 ------------------------------------------------------------------

def load() -> pd.DataFrame:
    """모든 사람 파일의 모든 줄 (저장한 시각 순서)."""
    cols = ["at", "by", "id"] + FIELDS + ["deleted"]
    d = root()
    rows = []
    for p in sorted(d.glob("*.jsonl")) if d.is_dir() else []:
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue    # 동기화 중 반쯤 받은 줄
                if isinstance(r, dict) and r.get("id"):
                    rows.append(r)
    return pd.DataFrame(rows, columns=cols).sort_values("at", kind="stable", ignore_index=True)


def active() -> pd.DataFrame:
    """지금 프로젝트 목록 (처음 넣은 순서). 열: id, FIELDS, by(마지막으로 고친 사람), at, created."""
    a = load()
    cols = ["id"] + FIELDS + ["by", "at", "created"]
    if a.empty:
        return pd.DataFrame(columns=cols)
    first = pd.Series(range(len(a)), index=a.index).groupby(a["id"]).min()     # 처음 넣은 순서 (같은 초에 넣은 줄도 넣은 순서대로)
    created = a.groupby("id")["at"].min()
    last = a.groupby("id").tail(1)
    last = last[~last["deleted"].fillna(False).astype(bool)]
    last = last.assign(created=last["id"].map(created), _order=last["id"].map(first)).sort_values("_order", ignore_index=True)
    last = last[cols].astype(object)
    return last.where(last.notna(), None)


# ---- 쓰기 ------------------------------------------------------------------

def _append(lines: list[dict]) -> Path:
    d = root()
    d.mkdir(parents=True, exist_ok=True)
    path = d / inputs._file_name(inputs.writer())
    data = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in lines)
    for attempt in range(6):
        try:
            with open(path, "a", encoding="utf-8", newline="\n") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            return path
        except PermissionError:      # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    raise PermissionError(f"프로젝트 파일에 쓰지 못했습니다: {path}")


def diff(before: list[dict], after: list[dict]) -> tuple[list[dict], dict]:
    """화면에 보였던 줄(before)과 고친 뒤 줄(after)을 비교한다. (쓸 줄, {added, changed, removed}).
    after에서 id가 없는 줄 = 새 줄, before에 있었는데 after에 없는 id = 지운 줄. 빈 줄은 건너뛴다.
    다른 사람이 그 사이에 넣거나 고친 줄은 before에 없으므로 건드리지 않는다."""
    now = datetime.now().isoformat(timespec="seconds")
    by = inputs.writer()
    old = {r["id"]: clean(r) for r in before if isinstance(r.get("id"), str) and r.get("id")}
    lines, added, changed, kept = [], 0, 0, set()
    for r in after:
        v = clean(r)
        rid = r.get("id") if isinstance(r.get("id"), str) and r.get("id") in old else None
        if rid:
            kept.add(rid)
        if all(v[f] is None for f in FIELDS):
            continue
        if rid and old[rid] == v:
            continue
        if rid:
            changed += 1
        else:
            rid, added = uuid.uuid4().hex[:12], added + 1
        lines.append({"at": now, "by": by, "id": rid, **v, "deleted": False})
    removed = [i for i in old if i not in kept]
    lines += [{"at": now, "by": by, "id": i, **old[i], "deleted": True} for i in removed]
    return lines, {"added": added, "changed": changed, "removed": len(removed)}


def save(before: list[dict], after: list[dict]) -> dict:
    """바뀐 줄만 내 파일에 쓴다. {added, changed, removed}."""
    lines, counts = diff(before, after)
    if lines:
        _append(lines)
    return counts


# ---- PO 데이터와 맞추기 --------------------------------------------------------

def match(projects: pd.DataFrame, lines: pd.DataFrame | None) -> pd.DataFrame:
    """프로젝트마다 PO 데이터 합계를 붙인다.
    더하는 열: so_amount(오더 금액), pct(오더율, 넣은 금액 기준), left(남은 금액), status, so_count(S/O 수),
    so_items(아이템 수), sold_to, billed_amount, rejected_qty."""
    p = projects.copy()
    p["key"] = p["po"].map(norm_po)
    if lines is not None and len(lines):
        g = (lines.assign(key=lines["po"].map(norm_po)).groupby("key")
             .agg(so_amount=("amount", "sum"), so_count=("so_no", "nunique"), so_items=("item", "nunique"),
                  sold_to=("sold_to", lambda s: ", ".join(sorted(set(s.dropna())))),
                  billed_amount=("billed_amount", "sum"), rejected_qty=("rejected_qty", "sum")))
        p = p.merge(g, left_on="key", right_index=True, how="left")
    for c in ("so_amount", "so_count", "so_items", "billed_amount", "rejected_qty", "sold_to"):
        if c not in p:
            p[c] = None
    found = p["so_count"].notna()
    for c in ("so_amount", "so_count", "so_items", "billed_amount", "rejected_qty"):
        p[c] = pd.to_numeric(p[c], errors="coerce").fillna(0)
    amount = pd.to_numeric(p["amount"], errors="coerce")
    p["pct"] = (p["so_amount"] / amount).where(amount > 0)
    p["left"] = amount - p["so_amount"]
    p["status"] = PARTIAL
    p.loc[p["left"].abs() <= TOLERANCE, "status"] = FULL
    p.loc[p["left"] < -TOLERANCE, "status"] = OVER
    p.loc[~found, "status"] = NO_ORDER
    p.loc[p["key"] == "", "status"] = NO_PO
    return p


def detail(po: str, lines: pd.DataFrame | None) -> pd.DataFrame:
    """그 Customer PO의 S/O 줄 (S/O 번호·줄 순서)."""
    if lines is None or not len(lines) or not norm_po(po):
        return pd.DataFrame(columns=list(lines.columns) if lines is not None else [])
    d = lines[lines["po"].map(norm_po) == norm_po(po)]
    return d.sort_values(["so_no", "so_item"], key=lambda s: s.map(lambda v: (len(str(v)), str(v))), ignore_index=True)
