"""PC ↔ 웹 데이터 묶음 (사용자 2026-11-18, docs/web.md 'PC ↔ 웹 데이터').

PC → 웹  export_pc(): 지금 PC의 최신 숫자·아이템을 zip 하나로
    cache/       계산 결과 (Item Master, 지표, DP 계산 입력, 재고, Inbound, RR 등)
    snapshots/   원천마다 마지막으로 읽어 둔 표 1개 (원천 엑셀이 아니라 읽은 결과. 웹에서 다시 계산할 때 쓴다)
    inputs/      사람 입력 폴더 전체 (고친 값, DP 확정, Inbound, RR 리뷰, 프로젝트)
  웹 '웹 데이터' 화면에서 올리면 import_bundle(): 계산 결과·읽어 둔 표는 통째로 바꾸고(갈아끼우기), 입력은 합친다.
웹 → PC  export_inputs(): 웹에서 내가 쓴 입력만. PC '웹 데이터' 화면에서 올리면 merge_inputs(): 공유 폴더 입력에 합친다.

합치는 규칙 (기록을 잃지 않게):
  - 줄이 쌓이는 파일 (<이름>.jsonl, RR Review·Project Info): 두 파일의 줄을 합치고 시각 순으로 (같은 줄은 하나)
  - DP 확정/<주차>/<담당>.jsonl: 확정할 때마다 통째로 쓰는 파일 → 확정 시각이 더 최근인 쪽
  - Inbound/…: 올린 시각이 파일 이름이라 없는 파일만 더한다
  - PC 공유 폴더에는 내가 쓴 파일만 합친다 (다른 사람 파일은 읽기만 한다, hub/inputs.py)
회사 데이터가 담기므로 GitHub에 올리지 않는다. 팀 안에서 OneDrive로 주고받는다.
"""

import io
import json
import os
import shutil
import socket
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

from . import config, dp_history, inputs, store, web

KIND_PC, KIND_INPUTS = "hva-scm-hub/pc-data", "hva-scm-hub/inputs"
META = "bundle.json"


# ---- 묶기 -------------------------------------------------------------------

def _input_files() -> list[tuple[str, Path]]:
    d, _ = inputs.folder()
    if not d.is_dir():
        return []
    return [(p.relative_to(d).as_posix(), p) for p in sorted(d.rglob("*.jsonl")) if p.is_file()]


def _meta(kind: str, **kw) -> dict:
    return {"kind": kind, "made_at": datetime.now().isoformat(timespec="seconds"), "by": inputs.writer(),
            "pc": socket.gethostname(), "web": web.is_web(), **kw}


def export_pc() -> tuple[bytes, dict]:
    """PC → 웹 묶음 (zip, 요약)."""
    base = config.data_dir()
    sources, n_cache, n_inputs = {}, 0, 0
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted((base / "cache").glob("*")):
            if p.is_file() and ".tmp." not in p.name:
                z.write(p, f"cache/{p.name}")
                n_cache += 1
        for src in config.sources():
            e = store.latest_entry(src["id"])
            folder = base / "snapshots" / src["id"] / e["snapshot"] if e else None
            if not e or not folder.is_dir():
                continue
            for p in sorted(folder.glob("*.parquet")):
                z.write(p, f"snapshots/{src['id']}/{e['snapshot']}/{p.name}")
            z.writestr(f"snapshots/{src['id']}/manifest.jsonl", json.dumps(e, ensure_ascii=False) + "\n")
            sources[src["id"]] = {"name": src["name"], "file": e.get("file"), "file_date": e.get("file_date")}
        for rel, p in _input_files():
            z.write(p, f"inputs/{rel}")
            n_inputs += 1
        meta = _meta(KIND_PC, today=config.today().isoformat(), sources=sources, cache=n_cache, inputs=n_inputs,
                     config_crc=config.config_crc())
        z.writestr(META, json.dumps(meta, ensure_ascii=False, indent=1))
    return buf.getvalue(), meta


def export_inputs() -> tuple[bytes, dict]:
    """웹 → PC 묶음: 내가 쓴 입력 파일만 (zip, 요약)."""
    me = inputs.writer()
    buf = io.BytesIO()
    names = []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in _input_files():
            data = p.read_bytes()
            if _owner(rel, data) == me:
                z.writestr(f"inputs/{rel}", data)
                names.append(rel)
        meta = _meta(KIND_INPUTS, files=names)
        z.writestr(META, json.dumps(meta, ensure_ascii=False, indent=1))
    return buf.getvalue(), meta


def file_name(meta: dict) -> str:
    when = meta["made_at"][:16].replace("-", "").replace("T", "-").replace(":", "")
    what = "PC 데이터" if meta["kind"] == KIND_PC else "웹 입력"
    return f"HVA SCM {what} {meta['by']} {when}.zip"


# ---- 풀기 -------------------------------------------------------------------

def _open(data: bytes, kind: str) -> tuple[zipfile.ZipFile, dict]:
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        meta = json.loads(z.read(META))
    except (zipfile.BadZipFile, KeyError, ValueError):
        raise ValueError("HVA SCM Hub 데이터 묶음(zip)이 아닙니다") from None
    if meta.get("kind") != kind:
        want = "PC 데이터" if kind == KIND_PC else "웹 입력"
        raise ValueError(f"{want} 묶음이 아닙니다 ({meta.get('kind')})")
    for n in z.namelist():       # 묶음 밖으로 쓰는 경로(../ 등)는 받지 않는다
        if n.startswith(("/", "\\")) or ".." in Path(n).parts or ":" in n:
            raise ValueError(f"잘못된 경로: {n}")
    return z, meta


def import_bundle(data: bytes) -> dict:
    """PC 묶음을 웹에 넣는다. 계산 결과·읽어 둔 표는 갈아끼우고, 입력은 합친다. 요약."""
    z, meta = _open(data, KIND_PC)
    base = config.data_dir()
    for sub in ("cache", "snapshots"):
        shutil.rmtree(base / sub, ignore_errors=True)
    web.clear_files()     # 전에 올린 원천 엑셀이 PC 숫자보다 먼저 다시 읽히지 않게
    for n in z.namelist():
        if n.startswith(("cache/", "snapshots/")) and not n.endswith("/"):
            target = base / n
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(n))
    # 설정이 같으면 PC 계산 결과를 그대로 쓴다: 결과 표의 '설정 값'을 이 웹의 값으로 바꿔 다시 계산하지 않게.
    # 설정이 다르면(코드 버전 차이) 그대로 두어 웹에서 읽어 둔 표로 다시 계산한다
    same = meta.get("config_crc") == config.config_crc()
    if same:
        for p in (base / "cache").glob("*.json"):
            m = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(m, dict) and "settings_mtime" in m:
                m["settings_mtime"] = config.config_mtime()
                p.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
    merged = _merge(z, mine_only=False)
    return {**meta, "merged": merged, "same_settings": same}


def merge_inputs(data: bytes) -> dict:
    """웹에서 내보낸 입력을 공유 폴더 입력에 합친다 (PC). 내가 쓴 파일만. 요약."""
    z, meta = _open(data, KIND_INPUTS)
    return {**meta, "merged": _merge(z, mine_only=True)}


def _merge(z: zipfile.ZipFile, mine_only: bool) -> dict:
    dest, _ = inputs.folder()
    me = inputs.writer()
    out = {"added": [], "merged": [], "replaced": [], "same": 0, "skipped": []}
    for n in z.namelist():
        if not n.startswith("inputs/") or not n.endswith(".jsonl"):
            continue
        rel, data = n[len("inputs/"):], z.read(n)
        if mine_only and _owner(rel, data) != me:
            out["skipped"].append(rel)
            continue
        what = merge_file(dest, rel, data)
        if what:
            out[what].append(rel)
        else:
            out["same"] += 1
    return out


def merge_file(dest: Path, rel: str, data: bytes) -> str | None:
    """입력 파일 하나를 합친다. 'added' · 'merged' · 'replaced', 바뀐 것이 없으면 None."""
    target = dest / rel
    if not target.exists():
        _write(target, data)
        return "added"
    top = rel.split("/")[0]
    if top == "Inbound":                       # 이름 = 올린 시각 → 같은 이름이면 같은 파일
        return None
    old = target.read_bytes()
    if top == dp_history.FOLDER:               # 확정할 때마다 통째로 쓴다 → 더 최근 확정
        if (_first(data).get("confirmed_at") or "") > (_first(old).get("confirmed_at") or ""):
            _write(target, data)
            return "replaced"
        return None
    have = _lines(old)                         # 줄이 쌓이는 파일 → 없는 줄만 더하고 시각 순으로
    seen = set(have)
    new = [line for line in dict.fromkeys(_lines(data)) if line not in seen]
    if not new:
        return None
    rows = have + new
    rows.sort(key=lambda line: _at(line))      # 정렬은 안정적이라 같은 시각이면 원래 순서
    _write(target, ("\n".join(rows) + "\n").encode("utf-8"))
    return "merged"


def _lines(data: bytes) -> list[str]:
    return [line.strip() for line in data.decode("utf-8", errors="replace").splitlines() if line.strip()]


def _at(line: str) -> str:
    try:
        return str(json.loads(line).get("at") or "")
    except (ValueError, AttributeError):
        return ""


def _first(data: bytes) -> dict:
    for line in _lines(data):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        return r.get("_meta", r) if isinstance(r, dict) else {}
    return {}


def _owner(rel: str, data: bytes) -> str | None:
    """그 파일을 쓴 사람. DP 확정 = 확정한 사람, Inbound = 올린 사람, 나머지 = 파일 이름(<이름>.jsonl)."""
    top = rel.split("/")[0]
    if top == dp_history.FOLDER:
        return _first(data).get("confirmed_by")
    if top == "Inbound":
        return _first(data).get("by")
    return Path(rel).stem


def _write(path: Path, data: bytes) -> None:
    """다 쓴 뒤 이름을 바꾼다 (반쯤 쓴 파일이 OneDrive로 동기화되지 않게)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_bytes(data)
    for attempt in range(6):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:      # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    raise PermissionError(f"입력 파일을 쓰지 못했습니다: {path}")


if __name__ == "__main__":
    # py -m hub.bundle [폴더]  → PC 데이터 묶음을 그 폴더(기본: 내 PC 다운로드 폴더)에 만든다
    sys.stdout.reconfigure(encoding="utf-8")
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / "Downloads"
    data, meta = export_pc()
    path = folder / file_name(meta)
    path.write_bytes(data)
    print(f"{path} · {len(data) / 1024 / 1024:.1f} MB · 원천 {len(meta['sources'])}개 · 계산 결과 {meta['cache']}개 · 입력 {meta['inputs']}개")
