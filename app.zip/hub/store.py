"""스냅샷과 캐시 저장.

data/
  snapshots/<source_id>/manifest.jsonl          불러온 기록 (한 줄 = 한 번)
  snapshots/<source_id>/<시각>/<표>.parquet      불러온 원천 데이터. 한 번 만들면 덮어쓰지 않는다
  cache/<이름>.parquet                           최신 스냅샷으로 만든 결과 (Item Master 등). 매번 다시 만든다
"""

import json
import os
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

from . import config


def _snap_dir(source_id: str) -> Path:
    return config.data_dir() / "snapshots" / source_id


def _cache_dir() -> Path:
    return config.data_dir() / "cache"


# ---- 스냅샷 ---------------------------------------------------------------

def entries(source_id: str) -> list[dict]:
    """불러온 기록, 오래된 것부터."""
    path = _snap_dir(source_id) / "manifest.jsonl"
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def latest_entry(source_id: str) -> dict | None:
    rows = entries(source_id)
    return rows[-1] if rows else None


def save_snapshot(source_id: str, tables: dict[str, pd.DataFrame], meta: dict) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = _snap_dir(source_id) / stamp
    folder.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        df.to_parquet(folder / f"{name}.parquet", index=False)
    entry = {
        **meta,
        "snapshot": stamp,
        "loaded_at": datetime.now().isoformat(timespec="seconds"),
        "rows": {name: int(len(df)) for name, df in tables.items()},
    }
    with open(_snap_dir(source_id) / "manifest.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry


def load_table(source_id: str, table: str, entry: dict | None = None) -> pd.DataFrame | None:
    """스냅샷의 표 하나. entry를 안 주면 가장 최근 스냅샷."""
    entry = entry or latest_entry(source_id)
    if not entry:
        return None
    path = _snap_dir(source_id) / entry["snapshot"] / f"{table}.parquet"
    return pd.read_parquet(path) if path.exists() else None


def prune(source_id: str, retention_days: int) -> int:
    """보관 기간이 지난 스냅샷을 지운다. 가장 최근 것은 남긴다. 지운 개수."""
    rows = entries(source_id)
    if len(rows) <= 1:
        return 0
    cutoff = datetime.now() - timedelta(days=retention_days)
    keep, removed = [], 0
    for i, e in enumerate(rows):
        old = datetime.fromisoformat(e["loaded_at"]) < cutoff
        if old and i < len(rows) - 1:
            shutil.rmtree(_snap_dir(source_id) / e["snapshot"], ignore_errors=True)
            removed += 1
        else:
            keep.append(e)
    if removed:
        with open(_snap_dir(source_id) / "manifest.jsonl", "w", encoding="utf-8") as f:
            f.writelines(json.dumps(e, ensure_ascii=False) + "\n" for e in keep)
    return removed


# ---- 캐시 -----------------------------------------------------------------

def write_cache(name: str, df: pd.DataFrame) -> None:
    """임시 파일에 쓰고 바꿔치기한다. 다른 프로그램(MCP 서버)이 읽는 중이면 잠깐 기다렸다 다시 시도."""
    folder = _cache_dir()
    folder.mkdir(parents=True, exist_ok=True)
    tmp = folder / f"{name}.tmp.parquet"
    df.to_parquet(tmp, index=False)
    for attempt in range(10):
        try:
            os.replace(tmp, folder / f"{name}.parquet")
            return
        except PermissionError:
            time.sleep(0.3 * (attempt + 1))
    raise PermissionError(f"캐시 파일을 바꾸지 못했습니다: {name}.parquet (다른 프로그램이 사용 중)")


def cache_path(name: str) -> Path:
    return _cache_dir() / f"{name}.parquet"


def read_cache(name: str) -> pd.DataFrame | None:
    path = cache_path(name)
    return pd.read_parquet(path) if path.exists() else None


def write_cache_meta(meta: dict, name: str = "meta") -> None:
    folder = _cache_dir()
    folder.mkdir(parents=True, exist_ok=True)
    with open(folder / f"{name}.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)


def read_cache_meta(name: str = "meta") -> dict:
    path = _cache_dir() / f"{name}.json"
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        return json.load(f)
