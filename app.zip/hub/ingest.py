"""새 파일 확인 → 읽기 → 스냅샷 → 결과 표(Item Master, 재고) 다시 만들기.

명령줄: py -m hub.ingest [--force]
  --force  파일이 바뀌지 않았어도 결과 표를 다시 만든다
"""

import sys
import traceback
from datetime import datetime

from . import (config, dp_engine, files, flow, inbound, inventory, item_master, metrics, paths, readers, rr_engine, store,
               web)

# 결과 상태
LOADED = "loaded"        # 새 파일을 불러옴
UNCHANGED = "unchanged"  # 이미 불러온 파일과 같음
LOCKED = "locked"        # DRM으로 잠김 → Decrypt 필요
MISSING = "missing"      # 폴더나 파일이 없음
ERROR = "error"          # 읽다가 실패
PLANNED = "planned"      # 아직 연결하지 않은 데이터

STATUS_LABEL = {
    LOADED: "새로 불러옴", UNCHANGED: "최신", LOCKED: "잠김 (Decrypt 필요)",
    MISSING: "파일 없음", ERROR: "읽기 실패", PLANNED: "연결 예정",
}

# 스냅샷으로 만드는 결과 표: (모듈, 메타 이름, 이 원천이 바뀌면 다시 만든다). 순서대로 만든다.
# None = 앞의 원천·결과 표 중 하나라도 바뀌면 (아이템 지표는 모든 결과 표를 모은다)
DERIVED = [
    (item_master, "meta", {"base_item", "product_list", "pos_mapping", "dp_file"}),
    (inventory, "inventory_meta", {"hva_inventory", "dp_file"}),
    (flow, "flow_meta", {"daily_sales", "daily_returns", "adi_inventory", "dp_file", "pos_mapping"}),
    (inbound, inbound.META, set()),   # 파일은 화면에서 올린다. 바뀌면 stale()이 알린다
    (dp_engine, dp_engine.META, None),
    (metrics, "metrics_meta", None),
    (rr_engine, rr_engine.META, {"run_rate"}),   # 맨 뒤: 다시 만들어도 DP 계산·아이템 지표를 다시 만들지 않게
]
# 모듈에 stale(meta)가 있으면 그것도 본다 (예: 아이템 지표는 사람 입력 파일이 바뀌거나 날짜가 바뀌면 다시 만든다)


def _load(src: dict, path, file_date: datetime, reader_version: int) -> dict:
    """파일 하나를 읽어 스냅샷으로 저장. 실패하면 예외."""
    tables, extra = readers.READERS[src["reader"]](path)
    fp = files.fingerprint(path)
    return store.save_snapshot(src["id"], tables, {**fp, "file_date": file_date.isoformat(timespec="seconds"),
                                                   "reader_version": reader_version, **extra})


def check_source(src: dict) -> dict:
    """원천 하나를 확인하고, 새 파일이면 스냅샷을 만든다."""
    result = {"id": src["id"], "name": src["name"], "file": None, "file_date": None, "message": ""}
    if not src.get("enabled", True):
        return {**result, "status": PLANNED}

    root = paths.resolve_root(src["root"])
    if root is None:
        return {**result, "status": MISSING, "message": f"기준 폴더 '{src['root']}'를 찾지 못했습니다"}
    folder = root / src.get("folder", ".")
    path, file_date = files.pick_latest(folder, src)
    last = store.latest_entry(src["id"])
    if path is None:
        if web.is_web() and last:   # 웹: PC에서 가져온 데이터(읽어 둔 표)를 그대로 쓴다 (hub/bundle.py)
            return {**result, "status": UNCHANGED, "file": last.get("file"), "file_date": last.get("file_date"),
                    "message": "가져온 PC 데이터"}
        return {**result, "status": MISSING, "message": f"{folder} 에 '{src['pattern']}' 파일이 없습니다"}

    result.update(file=path.name, file_date=file_date.isoformat(timespec="seconds"))
    fp = files.fingerprint(path)
    reader_version = readers.VERSIONS.get(src["reader"], 1)
    same_file = last and all(last.get(k) == fp[k] for k in ("file", "size", "mtime"))
    if same_file and last.get("reader_version", 1) == reader_version:
        return {**result, "status": UNCHANGED,
                "message": f"{last['loaded_at'][:16].replace('T', ' ')} 에 불러온 파일"}

    if files.lock_state(path) == files.LOCKED:
        if last and last["file"] == path.name and last.get("reader_version", 1) == reader_version:
            # Decrypt해서 읽은 뒤 다시 잠긴 같은 파일 (누가 Excel로 열었거나 DRM이 다시 잠금) → 읽어 둔 값 그대로
            return {**result, "status": UNCHANGED,
                    "message": f"다시 잠겼지만 풀려 있을 때 읽은 값({last['loaded_at'][:16].replace('T', ' ')})을 씁니다"}
        msg = "Decrypt 후 다시 확인하십시오."
        if last:
            msg += f" 그동안 이전 스냅샷({last['file']}, {last['loaded_at'][:10]})을 씁니다."
        return {**result, "status": LOCKED, "message": msg}

    try:
        entry = _load(src, path, file_date, reader_version)
    except Exception as e:  # noqa: BLE001 - 화면에 이유를 보여주고 다른 원천은 계속 확인한다
        traceback.print_exc(file=sys.stderr)
        return {**result, "status": ERROR, "message": f"{type(e).__name__}: {e}"}
    rows = ", ".join(f"{k} {v:,}행" for k, v in entry["rows"].items())
    return {**result, "status": LOADED, "message": rows}


def run_all(force: bool = False) -> list[dict]:
    results = [check_source(src) for src in config.sources()]
    loaded_ids = {r["id"] for r in results if r["status"] == LOADED}
    rebuilt = False
    for module, meta_name, inputs in DERIVED:
        meta = store.read_cache_meta(meta_name)
        outdated = (meta.get("version") != module.VERSION
                    or meta.get("settings_mtime") != config.config_mtime()
                    or (hasattr(module, "stale") and module.stale(meta)))
        changed = (loaded_ids or rebuilt) if inputs is None else (loaded_ids & inputs)
        if force or outdated or changed or not store.cache_path(module.CACHE).exists():
            rebuilt = True
            try:
                summary = module.rebuild()
                status = LOADED
            except Exception as e:  # noqa: BLE001
                traceback.print_exc(file=sys.stderr)
                summary, status = f"{type(e).__name__}: {e}", ERROR
            results.append({"id": module.CACHE, "name": module.NAME, "status": status,
                            "file": None, "file_date": None, "message": summary})
    retention = int(config.settings().get("retention_days", 365))
    for src in config.sources():
        store.prune(src["id"], retention)
    return results


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    for r in run_all(force="--force" in sys.argv):
        print(f"[{STATUS_LABEL.get(r['status'], r['status'])}] {r['name']}: {r['file'] or ''} {r['message']}")


if __name__ == "__main__":
    main()
