"""HVA 재고: 가장 최근 재고 하나만, 팀이 쓰는 창고(CFC5 + SCA3 = OH)만.

SCA3 = 열상 카메라 창고 (사용자 2026-11-11). CFC5와 겹치는 아이템은 없다 (2026-11-10 파일: SCA3 16개, 겹침 0).

current inventory는 "파일을 뽑은 시점의 현재 재고"라서 최신 것만 쓴다 (사용자 확인 2026-10-23).
재고는 두 곳에서 올 수 있다 (형식 같음, docs/inventory.md):
  hva_inventory  공유 폴더 Current Inventory의 가장 최근 일별 파일 (Decrypt된 경우)
  dp_file        DP 파일 '1. HVA Inv' 시트 (DP를 만들 때 붙여 넣은 그 주 재고)
둘 중 재고 날짜(Key Date)가 더 최근인 것을 쓰고, 같으면 일별 파일을 쓴다.
결과: cache/inventory_latest.parquet (아이템 × 창고 행. 수주 재고(Special Stock E)는 행이 따로 있다)
"""

from datetime import datetime

from . import config, store

VERSION = 3  # 3: CFC5 + SCA3 (2026-11-11)
NAME = "재고"
CACHE = "inventory_latest"

SOURCES = [("hva_inventory", "stock", "일별 재고 파일"), ("dp_file", "hva_inv", "DP 파일 '1. HVA Inv'")]


def pick_latest():
    """두 원천 중 재고 날짜가 더 최근인 재고 표 (모든 창고). (표, 출처 정보) 또는 (None, None)."""
    picks = []
    for priority, (sid, table, label) in enumerate(SOURCES):
        e = store.latest_entry(sid)
        df = store.load_table(sid, table, e) if e else None
        if df is None or df.empty or df["key_date"].isna().all():
            continue
        picks.append((df["key_date"].max(), -priority, df, label, e["file"]))
    if not picks:
        return None, None
    key_date, _, df, label, file = max(picks, key=lambda x: (x[0], x[1]))
    return df, {"key_date": key_date.strftime("%Y-%m-%d"), "source": label, "file": file}


def rebuild() -> str:
    df, info = pick_latest()
    if df is None:
        if store.cache_path(CACHE).exists():
            store.cache_path(CACHE).unlink()
        store.write_cache_meta({"version": VERSION, "settings_mtime": config.config_mtime()}, "inventory_meta")
        return "재고 데이터가 아직 없습니다"

    locations = config.settings().get("inventory", {}).get("locations", ["CFC5", "SCA3"])
    latest = df[df["s_loc"].isin(locations)].copy()
    store.write_cache(CACHE, latest)
    meta = {
        "version": VERSION, "settings_mtime": config.config_mtime(),
        "built_at": datetime.now().isoformat(timespec="seconds"),
        **info, "locations": locations,
        "extract_date": None if latest["extract_date"].isna().all()
        else latest["extract_date"].max().strftime("%Y-%m-%d"),
    }
    store.write_cache_meta(meta, "inventory_meta")
    return (f"{meta['key_date']} 기준 ({info['source']}) · {', '.join(locations)} · 아이템 {latest['item'].nunique():,}개 · "
            f"Unrestricted {latest['unrestricted'].sum():,.0f}대")

