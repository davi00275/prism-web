"""업로드 엑셀 (docs/dp-history.md).

월요일 자원점검: `DP Upload.xlsx`와 같은 모양 (workbook).
금요일 DP: M1~M3 표 (dp_workbook). 양식 샘플을 아직 못 받아서 임시 모양이다.

양식 (samples/DP Upload.xlsx, 2026-10-22 분석):
  1~2행 머리글   A1:A2 To Site · B1:B2 Item · C1:G1 REPLY → C2 AIR · D2 VSL / TRK · E2 Delay · F2 Cancel · G2 Remarks
  3행부터        아이템 한 줄. 수량 형식 #,##0, 열 너비 13
행: 내 아이템 중 자원점검 > 0이거나 Remarks가 있는 것 (사용자 2026-11-03). 각자 확정, 각자 업로드.
To Site는 settings.yaml upload.to_site. Delay·Cancel은 아직 0 (쓰는 법을 사용자가 알려 주면 추가).
"""

from io import BytesIO

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

REPLY = ["AIR", "VSL / TRK", "Delay", "Cancel", "Remarks"]


def workbook(rows: pd.DataFrame, to_site: str) -> bytes:
    """rows 열: item, air, vsl, remarks."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws["A1"], ws["B1"], ws["C1"] = "To Site", "Item", "REPLY"
    for col, name in zip("CDEFG", REPLY):
        ws[f"{col}2"] = name
    for rng in ("A1:A2", "B1:B2", "C1:G1"):
        ws.merge_cells(rng)
    for cell in ("A1", "B1", "C1", "C2", "D2", "E2", "F2", "G2"):
        ws[cell].font = Font(bold=True)
        ws[cell].alignment = Alignment(horizontal="center", vertical="center")
    for r in rows.sort_values("item").itertuples(index=False):
        remarks = r.remarks if isinstance(r.remarks, str) and r.remarks else None
        ws.append([to_site, r.item, int(round(r.air or 0)), int(round(r.vsl or 0)), 0, 0, remarks])
    for col in "ABCDEFG":
        ws.column_dimensions[col].width = 13
    for row in ws.iter_rows(min_row=3, min_col=3, max_col=6):
        for cell in row:
            cell.number_format = "#,##0"
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def dp_workbook(rows: pd.DataFrame, to_site: str) -> bytes:
    """금요일 DP (임시 모양): To Site, Item, 그 주 달별 DP. M1~M3이 모두 0이어도 넣는다 (수요 없음이라는 뜻)."""
    months = [c for c in ("month_m1", "month_m2", "month_m3", "month_m4") if rows[c].notna().any()]
    wb = Workbook()
    ws = wb.active
    ws.title = "DP"
    ws.append(["To Site", "Item"] + [rows[c].dropna().iloc[0] for c in months])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for _, r in rows.sort_values("item").iterrows():
        ws.append([to_site, r["item"]] + [int(round(r[c.replace("month", "demand")] or 0)) for c in months])
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
