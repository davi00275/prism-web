"""원천 파일을 찾는 기준 폴더. 팀 공유 폴더는 PC마다 위치와 이름이 달라서 자동으로 찾는다.

예) C:/Users/<이름>/OneDrive - <회사>/<팀 폴더>
    C:/Users/<이름>/<회사>/<팀 폴더>/SCM
실제 예는 docs/team-setup.md (웹 버전으로 공개되는 코드라 폴더 이름을 적지 않는다)
"""

import os
from functools import lru_cache
from pathlib import Path

from . import config, web


def resolve_root(name: str) -> Path | None:
    """sources.yaml의 root 이름 → 실제 폴더. 없으면 None."""
    if web.is_web():    # 웹 버전: PC 폴더 대신 '원천 파일' 화면에서 올린 브라우저 저장소
        return web.root(name)
    value = config.settings().get("roots", {}).get(name)
    if not value:
        return None
    if value == "auto":
        return find_shared_root()
    p = Path(value)
    p = p if p.is_absolute() else config.ROOT / p
    return p if p.is_dir() else None


@lru_cache(maxsize=1)
def find_shared_root() -> Path | None:
    """표식 폴더(Current Inventory, Daily Sales 등)가 모두 있는 폴더를 찾는다. 한 번 찾으면 기억한다."""
    markers = config.settings().get("shared_root_markers", [])
    if not markers:
        return None
    for base in _candidates():
        for d in _walk(base, depth=2):
            if all((d / m).is_dir() for m in markers):
                return d
    return None


def _candidates() -> list[Path]:
    """OneDrive 관련 폴더들. 이름에 hanwhaworkplace가 들어간 폴더도 본다."""
    found: list[Path] = []
    for key in ("OneDriveCommercial", "OneDrive"):
        v = os.environ.get(key)
        if v:
            found.append(Path(v))
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    try:
        found += [c for c in home.iterdir() if c.is_dir() and "hanwhaworkplace" in c.name.lower()]
    except OSError:
        pass
    unique: list[Path] = []
    for p in found:
        if p.is_dir() and p not in unique:
            unique.append(p)
    return unique


def _walk(base: Path, depth: int):
    yield base
    if depth == 0:
        return
    try:
        children = sorted(c for c in base.iterdir() if c.is_dir())
    except OSError:
        return
    for c in children:
        yield from _walk(c, depth - 1)
