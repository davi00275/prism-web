"""DP 확정 기록: 금요일 DP를 확정하면 본인 아이템의 M1~M3을 공유 폴더에 남긴다 (docs/dp-history.md).

위치: <사람 입력 폴더>/DP 확정/<주차>/<이름>.jsonl   예) HVA SCM 입력\\DP 확정\\2026-W45\\Wonbin Shin.jsonl
  - 각자 확정, 각자 업로드 (사용자 2026-11-03). 파일 이름 = 담당자. 다시 확정하면 그 파일을 새로 쓴다
    (그 주의 마지막 확정이 남는다. 중간에 고친 과정은 사람 입력 기록 hub/inputs.py에 남아 있다)
  - 한 줄 = 아이템 하나: 그 주 계산 근거(R/R·EOH·재고·주문·ADI·입고) + 계산값 + 사람 수정 + 최종 DP·자원점검·AIR/VSL·Remarks
    → 나중에 "그 주에 어떻게 최종 DP가 되었는지"를 그대로 볼 수 있다
  - 주차가 지나도 지우지 않는다. 'DP 기록' 화면과 Item 360 'DP 이력'이 읽는다
  - 텍스트(JSON Lines): 같은 폴더의 사람 입력 파일처럼 DRM에 잠기지 않았다 (2026-10-28 확인). Excel로 열지 않는다
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import dp_engine, inputs, metrics

FOLDER = "DP 확정"

# 아이템 한 줄에 남기는 숫자 (plan 열 이름 그대로)
NUMBERS = ["rr", "rr_file", "eoh", "eoh_file", "hva_inv", "open_so", "open_do", "gi", "adi_inv", "adi_adjust",
           "calc_resource_check", "rc_formula", "rc_adjust", "resource_check", "air", "vsl"]
MONTHLY = ["inbound", "calc_demand", "demand", "carry"]


def root() -> Path:
    return inputs.folder()[0] / FOLDER


def _path(week: str, owner: str) -> Path:
    return root() / week / inputs._file_name(owner)


def _plain(v):
    if isinstance(v, (np.integer, np.floating)):
        v = v.item()
    if isinstance(v, float) and v != v:
        return None
    if isinstance(v, np.bool_):
        return bool(v)
    return v


# ---- 쓰기 -----------------------------------------------------------------

def write(owner: str, rows: pd.DataFrame, cal: dict, data_dates: dict, memo: str = "") -> Path:
    """담당 owner의 이번 주 DP(rows = dp_engine.plan 결과에서 그 담당 아이템)를 확정 기록으로 쓴다."""
    now = datetime.now().isoformat(timespec="seconds")
    by = inputs.writer()
    months, keys = cal["months"], cal["month_keys"]
    notes = metrics.edit_notes(rows) if len(rows) else pd.Series(dtype=str)
    lines = []
    for (_, r), note in zip(rows.iterrows(), notes):
        rec = {"week": cal["week"], "dp_week": cal["dp_week"], "base_date": cal["base_date"], "months": months,
               "workday_ratio": cal["workday_ratio"], "owner": owner, "confirmed_by": by, "confirmed_at": now,
               "memo": memo or "", "item": r["item"], "dp_status": r.get("dp_status"),
               "rr_review": r.get("rr_review") if isinstance(r.get("rr_review"), str) else "",
               "remarks": r.get("remarks") or "", "upload": bool(r["upload"]), "edited": bool(r["edited"]),
               "edit_note": note, "data_dates": data_dates}
        for c in NUMBERS:
            rec[c] = _plain(r[c])
        for i in range(1, dp_engine.MAX_MONTHS + 1):
            on = i <= months
            rec[f"month_m{i}"] = keys[i - 1] if on else None
            for c in MONTHLY:
                rec[f"{c}_m{i}"] = _plain(r[f"{c}_m{i}"]) if on else None
        lines.append(json.dumps(rec, ensure_ascii=False))
    path = _path(cal["week"], owner)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(tmp, path)   # 다 쓴 뒤 한 번에 바꾼다 (반쯤 쓴 파일이 동기화되지 않게)
            break
        except PermissionError:     # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    else:
        raise PermissionError(f"확정 파일을 쓰지 못했습니다: {path} (다른 프로그램이 사용 중)")
    _memo.clear()
    return path


# ---- 읽기 -----------------------------------------------------------------

_memo: dict = {}


def _read(path: Path) -> pd.DataFrame | None:
    try:
        st = path.stat()
    except OSError:
        return None
    key = (st.st_mtime, st.st_size)
    hit = _memo.get(path)
    if hit and hit[0] == key:
        return hit[1]
    rows = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    continue  # 동기화 중 반쯤 받은 줄
    df = pd.DataFrame(rows)
    _memo[path] = (key, df)
    return df


def week_files(week: str) -> list[dict]:
    """그 주차에 확정한 사람들 [{owner, path, modified}] (파일 이름만 본다)."""
    d = root() / week
    if not d.is_dir():
        return []
    out = []
    for p in sorted(d.glob("*.jsonl")):
        try:
            modified = datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
        except OSError:
            continue
        out.append({"owner": p.stem, "path": p, "modified": modified})
    return out


def weeks() -> list[dict]:
    """확정 기록이 있는 주차 (최근부터) [{week, owners}]."""
    r = root()
    if not r.is_dir():
        return []
    out = []
    for d in sorted((p for p in r.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True):
        owners = [f["owner"] for f in week_files(d.name)]
        if owners:
            out.append({"week": d.name, "owners": owners})
    return out


def load_owner(week: str, owner: str) -> pd.DataFrame | None:
    path = _path(week, owner)
    return _read(path) if path.exists() else None


def load_week(week: str, owner: str | None = None) -> pd.DataFrame:
    parts = [_read(f["path"]) for f in week_files(week) if owner is None or f["owner"] == owner]
    parts = [p for p in parts if p is not None and len(p)]
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def item_history(item: str) -> pd.DataFrame:
    """아이템의 주차별 확정값 (최근 주차부터). 모든 주차 파일을 읽는다 (작은 파일, 바뀐 것만 다시 읽음)."""
    parts = []
    for w in weeks():
        df = load_week(w["week"])
        if len(df) and "item" in df:
            parts.append(df[df["item"] == item])
    if not parts:
        return pd.DataFrame()
    out = pd.concat(parts, ignore_index=True)
    return out.sort_values("week", ascending=False).reset_index(drop=True)


def changed_items(snap: pd.DataFrame, rows: pd.DataFrame) -> list[str]:
    """확정한 뒤 M1~M4 DP 값, 입고, 아이템 목록이 바뀐 아이템."""
    if snap is None or snap.empty:
        return []
    cols = [f"demand_m{i}" for i in range(1, dp_engine.MAX_MONTHS + 1)]
    cols += [f"inbound_m{i}" for i in range(1, int(snap["months"].iloc[0]) + 1)]
    a = snap.set_index("item").reindex(columns=cols).apply(pd.to_numeric, errors="coerce")
    b = rows.set_index("item").reindex(columns=cols).apply(pd.to_numeric, errors="coerce")
    items = a.index.union(b.index)
    a, b = a.reindex(items), b.reindex(items)
    diff = ((a - b).abs() >= 0.5) | (a.isna() != b.isna())
    return sorted(items[diff.any(axis=1)])
