"""아이템 지표: 데이터마다 흩어진 숫자를 아이템 한 줄로 모으고, 주의 신호를 붙인다.

새 데이터를 붙이면 METRICS(열)와 ALERTS(주의 신호)에 한 줄씩 추가하고 rebuild()에서 값을 채운다.
그러면 다음에 자동으로 나온다:
  - '내 아이템' 목록의 열, 열 묶음 선택, 주의 신호 필터
  - Item 360 맨 위 요약 줄 (summary=True)
  - Claude 연결 list_items 도구
결과: cache/item_metrics.parquet (아이템 한 줄)
"""

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Callable

import pandas as pd

from . import config, dp_engine, inputs, store

VERSION = 7  # 7: DP 판정은 Base Item으로 (2026-11-06), 2: DP 판정, 3: EOL 날짜는 PriceList 이후만 (2026-10-26), 4: DP 숫자는 계산 엔진, 5: 자원점검 조정 (2026-10-28), 6: 수량은 정수 (2026-11-04)
NAME = "아이템 지표"
CACHE = "item_metrics"


@dataclass(frozen=True)
class Metric:
    key: str
    label: str
    group: str
    fmt: str = "int"            # int, float1, date, text
    help: str = ""
    summary: bool = False       # Item 360 요약 줄에 보임
    brief: bool = False         # 목록 '간단히'에서도 보임


GROUPS = ["기본", "재고", "주문·출고", "ADI", "DP"]

METRICS = [
    Metric("dp_status", "DP 판정", "기본", "text", "DP 대상 = Base Item에 있음 / Base 아님 (docs/dp-target.md)", brief=True),
    Metric("dp_reason", "판정 사유", "기본", "text", brief=True),
    Metric("item_name", "품명", "기본", "text"),
    Metric("product_group", "Group", "기본", "text", brief=True),
    Metric("owner", "담당", "기본", "text"),
    Metric("series", "Series", "기본", "text", brief=True),
    Metric("plc_status", "PLC", "기본", "text", brief=True),
    Metric("eop", "EOP", "기본", "date"),
    Metric("months_to_eop", "EOP까지(개월)", "기본", "float1"),
    Metric("inv_unrestricted", "OH", "재고", "int", "최신 재고 파일 Unrestricted, CFC5 + SCA3 (SCA3 = 열상 카메라 창고)", True, True),
    Metric("inv_available", "가용재고", "재고", "int", "OH − S/O − D/O (CFC5 + SCA3)", True, True),
    Metric("cover_months", "재고 커버(개월)", "재고", "float1", "OH ÷ R/R", True, True),
    Metric("inv_open_po", "Open PO", "재고", "int", "재고 파일 Open PO Qty (CFC5 + SCA3)"),
    Metric("inv_amount", "재고 금액($)", "재고", "int", "OH 금액 (CFC5 + SCA3)"),
    Metric("gi_qty", "당월 GI", "주문·출고", "int", "주문 + 반품 (Invoice + Not Invoice). DP Table F", True, True),
    Metric("gi_amt", "GI 금액($)", "주문·출고", "int"),
    Metric("open_so_qty", "Open SO", "주문·출고", "int", "주문 파일 Order 수량. DP Table H", True, True),
    Metric("so_block_qty", "SO Block", "주문·출고", "int", "Open SO 중 Block"),
    Metric("open_do_qty", "Open DO", "주문·출고", "int", "재고 파일 D/O (CFC5 + SCA3). DP Table I", True),
    Metric("adi_available_qty", "ADI 가용", "ADI", "int", "ADI Available (POS 매핑 합산). DP Table K", True, True),
    Metric("adi_backorder_qty", "ADI Backorder", "ADI", "int"),
    Metric("adi_total_qty", "ADI 전체", "ADI", "int"),
    Metric("rr", "R/R", "DP", "int", "DP 파일 R/R (DP Table L). 대시보드 수정 시 수정값", True, True),
    Metric("rr_current", "현행 R/R", "DP", "int", "DP list V열 (포털 현행 값)"),
    Metric("eoh", "EOH Target", "DP", "int", "DP 파일 EOH (DP Table N). 대시보드 수정 시 수정값"),
    Metric("demand_m1", "DP M1", "DP", "int", "계산 엔진 DP 값 M1 (최신 파일 기준, 수정값 반영)"),
    Metric("demand_m2", "DP M2", "DP", "int", "계산 엔진 DP 값 M2"),
    Metric("demand_m3", "DP M3", "DP", "int", "계산 엔진 DP 값 M3"),
    Metric("resource_check", "자원점검", "DP", "int",
           "계산 엔진 자원점검: 최신 재고·주문·ADI + R/R·EOH·월 DP 값·자원점검 조정(사람이 고친 값 반영). "
           "DP Upload 수량 (AIR / Vessel)", True, True),
    Metric("resource_check_calc", "자원점검 (계산)", "DP", "int", "수정 전 계산값 (DP 파일 R/R·EOH 기준)"),
    Metric("rc_adjust", "자원점검 조정", "DP", "int", "금주 DP 주차 수동 가감 수량 (추가 오더 등)"),
    Metric("resource_check_dp", "자원점검 (DP 파일)", "DP", "int", "DP Table 자원점검 (파일 작성 시점)"),
    Metric("vs_dp_file", "DP 파일과 차이", "DP", "int", "자원점검 − DP 파일 자원점검. 최신 데이터·수정값으로 인한 차이"),
    Metric("edit_note", "직접 수정", "DP", "text", "대시보드 수정 항목 (R/R, EOH, 월 DP 값, 자원점검 조정)",
           brief=True),
    Metric("rr_review", "RR Review", "DP", "text", "DP Table RR Review", brief=True),
]
METRIC_BY_KEY = {m.key: m for m in METRICS}


@dataclass(frozen=True)
class Alert:
    key: str
    label: str
    color: str                  # 화면 배지 색: red, orange, blue, violet, gray
    help: str
    rule: Callable[[pd.DataFrame, dict], pd.Series] = field(compare=False)


# 기준값은 config/settings.yaml의 alerts에서 바꾼다 (제안 값, 사용자가 조정)
ALERTS = [
    Alert("negative_available", "가용 마이너스", "red", "가용재고(OH − S/O − D/O) < 0",
          lambda d, c: d["inv_available"] < 0),
    Alert("low_cover", "재고 부족", "red", "R/R > 0 이고 재고 커버 < low_cover_months개월",
          lambda d, c: (d["rr"] > 0) & (d["cover_months"] < c["low_cover_months"])),
    Alert("high_cover", "재고 과다", "blue", "R/R > 0 이고 재고 커버 ≥ high_cover_months개월",
          lambda d, c: (d["rr"] > 0) & (d["cover_months"] >= c["high_cover_months"])),
    Alert("so_block", "SO Block", "orange", "Open SO 중 Block 걸린 수량이 있음",
          lambda d, c: d["so_block_qty"] > 0),
    Alert("adi_backorder", "ADI Backorder", "orange", "ADI에 Backorder가 있음",
          lambda d, c: d["adi_backorder_qty"] > 0),
    Alert("manual_input", "수동입력", "violet", "DP Table RR Review가 수동입력 (TAA, 대형프로젝트, 🔴)",
          lambda d, c: d["is_manual_input"]),
    Alert("eop_soon", "EOP 임박", "gray", "EOP까지 eop_months개월 이내",
          lambda d, c: (d["months_to_eop"] >= 0) & (d["months_to_eop"] <= c["eop_months"])),
    Alert("kv_switch", "K↔V 전환", "violet", "한국·베트남 생산 전환 모델 (합산 RR)",
          lambda d, c: d["is_kv_switch"]),
    Alert("edited", "직접 수정", "blue", "대시보드에서 R/R·EOH·월 DP 값·자원점검을 수정한 Item (수정자 무관)",
          lambda d, c: d["edited"]),
    Alert("edit_stale", "원본 값 변경", "red",
          "R/R·EOH를 고친 뒤 DP 파일의 원래 값이 바뀌었음 → 고친 값을 그대로 둘지 확인",
          lambda d, c: d["edit_stale"]),
    Alert("pl_status", "Limited/EOL", "gray", "PriceList Limited Stock(K~Q) 또는 EOL Product(S~AA)에 있음",
          lambda d, c: d["pl_limited"] | d["pl_eol"]),
    Alert("eol_selling", "EOL 후 판매", "orange",
          "Product List EOL 날짜가 지났는데 Open SO·당월 GI·최근 6개월 판매 있음 (PriceList에는 없어 DP 대상으로 남음) → 데이터 확인",
          lambda d, c: d["eol_passed"] & ((d["open_so_qty"] > 0) | (d["gi_qty"] > 0) | (d["sales_recent6"] > 0))),
]
ALERT_BY_KEY = {a.key: a for a in ALERTS}
ALERT_DEFAULTS = {"low_cover_months": 1, "high_cover_months": 6, "eop_months": 6}

# Item Master에서 가져오는 열 (필터·검색용 포함)
MASTER_COLUMNS = ["item", "item_name", "product_group", "owner", "plc_status", "eop", "in_base", "in_dp_list", "is_local",
                  "is_bom_header", "is_manual_input", "is_kv_switch", "dp_pl_status", "dp_review", "dp_rr_current",
                  "dp_series", "base", "family_key", "model_group", "search_key", "pl_limited", "pl_eol",
                  "eol_passed", "dp_exclude_reason", "dp_sales_recent6"]

# DP 판정 값
DP_TARGET, DP_NOT_BASE = "DP 대상", "Base 아님"
DP_STATUSES = [DP_TARGET, DP_NOT_BASE]


def alert_settings() -> dict:
    return {**ALERT_DEFAULTS, **(config.settings().get("alerts") or {})}


def rebuild() -> str:
    master = store.read_cache("item_master")
    if master is None:
        raise RuntimeError("Item Master가 없습니다")
    d = master[MASTER_COLUMNS].rename(columns={"dp_series": "series", "dp_rr_current": "rr_current",
                                               "dp_review": "rr_review", "dp_sales_recent6": "sales_recent6"})
    for c in ("pl_limited", "pl_eol", "eol_passed"):
        d[c] = d[c].fillna(False).astype(bool)

    inv = store.read_cache("inventory_latest")
    if inv is not None and len(inv):
        g = inv.groupby("item").agg(inv_unrestricted=("unrestricted", "sum"), inv_available=("available", "sum"),
                                    inv_open_po=("open_po", "sum"), inv_amount=("amount", "sum"),
                                    open_do_qty=("do_qty", "sum"))
        d = d.merge(g, left_on="item", right_index=True, how="left")
    flow = store.read_cache("item_flow")
    if flow is not None and len(flow):
        keep = [c for c in ("gi_qty", "gi_amt", "open_so_qty", "so_block_qty", "adi_available_qty",
                            "adi_backorder_qty", "adi_total_qty") if c in flow.columns]
        d = d.merge(flow[["item"] + keep], on="item", how="left")
    plan, _ = dp_engine.current_plan()
    if plan is not None and len(plan):
        p = plan[["item", "rr", "eoh", "demand_m1", "demand_m2", "demand_m3", "resource_check", "calc_resource_check",
                  "rc_adjust", "dpf_resource_check", "vs_dp_file", "edited"]].rename(
            columns={"dpf_resource_check": "resource_check_dp", "calc_resource_check": "resource_check_calc"})
        p["edit_stale"] = plan["rr_stale"] | plan["eoh_stale"]
        p["edit_note"] = edit_notes(plan)
        d = d.merge(p, on="item", how="left")
    for c in ("edited", "edit_stale"):
        d[c] = d[c].fillna(False).astype(bool) if c in d else False

    # 데이터가 아직 없는 열도 만들어 둔다 (화면·도구가 열 이름에 기대므로)
    for m in METRICS:
        if m.key not in d.columns:
            d[m.key] = None
    qty = ["inv_unrestricted", "inv_available", "inv_open_po", "inv_amount", "open_do_qty", "gi_qty", "gi_amt",
           "open_so_qty", "so_block_qty", "adi_available_qty", "adi_backorder_qty", "adi_total_qty"]
    d[qty] = d[qty].apply(pd.to_numeric, errors="coerce").fillna(0)
    d["rr"] = pd.to_numeric(d["rr"], errors="coerce")
    d["sales_recent6"] = pd.to_numeric(d["sales_recent6"], errors="coerce").fillna(0)
    d["cover_months"] = (d["inv_unrestricted"] / d["rr"]).where(d["rr"] > 0).round(1)
    eop = pd.to_datetime(d["eop"], errors="coerce")
    d["months_to_eop"] = ((eop - pd.Timestamp(date.today())).dt.days / 30.4).round(1)
    d["dp_status"], d["dp_reason"] = dp_judgement(d)

    cfg = alert_settings()
    for a in ALERTS:
        d[f"alert_{a.key}"] = a.rule(d, cfg).fillna(False).astype(bool)
    flags = d[[f"alert_{a.key}" for a in ALERTS]]
    d["alerts"] = [[a.label for a, on in zip(ALERTS, row) if on] for row in flags.itertuples(index=False)]
    d["alert_count"] = flags.sum(axis=1)

    store.write_cache(CACHE, d)
    store.write_cache_meta({"version": VERSION, "settings_mtime": config.config_mtime(),
                            "built_at": datetime.now().isoformat(timespec="seconds"),
                            "built_on": date.today().isoformat(), "inputs_signature": _signature(),
                            "alert_settings": cfg}, "metrics_meta")
    n = d["dp_status"].value_counts()
    return " · ".join(f"{s} {int(n.get(s, 0)):,}" for s in DP_STATUSES)


def dp_judgement(d: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """DP 판정과 이유 (docs/dp-target.md). Base Item에 있으면 DP 대상, 없으면 Base 아님 (사용자 2026-11-06)."""
    on = d["in_base"].fillna(False).astype(bool)
    return on.map({True: DP_TARGET, False: DP_NOT_BASE}), on.map({True: "", False: "Base Item에 없음"})


def _signature() -> list:
    return [list(x) for x in inputs.signature()]


def stale(meta: dict) -> bool:
    """사람 입력 파일이 바뀌었거나(다른 사람 입력이 동기화됨) 날짜가 바뀌면(남은 근무일 비율) 다시 만든다."""
    return meta.get("built_on") != date.today().isoformat() or meta.get("inputs_signature") != _signature()


def edit_notes(plan: pd.DataFrame) -> pd.Series:
    """'R/R 45→50 · M2 900→1,100 · 자원점검 +200' 같은 짧은 설명. 고친 것이 없으면 빈 글자."""
    notes = []
    for r in plan.itertuples(index=False):
        parts = []
        for f, label in (("rr", "R/R"), ("eoh", "EOH")):
            if getattr(r, f"{f}_edit"):
                parts.append(f"{label} {_n(getattr(r, f'{f}_file'))}→{_n(getattr(r, f))}")
        for i in range(1, dp_engine.MAX_MONTHS + 1):
            if getattr(r, f"manual_by_m{i}") is not None:
                parts.append(f"M{i} {_n(getattr(r, f'calc_demand_m{i}'))}→{_n(getattr(r, f'demand_m{i}'))}")
        if r.rc_adjust_by is not None:
            parts.append(f"자원점검 {r.rc_adjust:+,.0f}")
        if getattr(r, "air_by", None) is not None:
            parts.append(f"AIR {r.air_input:,.0f}")
        if getattr(r, "remarks_by", None) is not None:
            parts.append("Remarks")
        notes.append(" · ".join(parts))
    return pd.Series(notes, index=plan.index)


def _n(v) -> str:
    if v is None or pd.isna(v):
        return "–"
    return f"{v:,.0f}"
