"""설정 파일(config/*.yaml)을 읽고 폴더 위치를 푼다."""

import hashlib
import os
import re
import shutil
import zlib
from datetime import date
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def _load(name: str) -> dict:
    with open(ROOT / "config" / name, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


# 파일을 고치면 앱을 다시 켜지 않아도 반영되도록 매번 읽는다 (작은 파일이라 부담 없음)
def today() -> date:
    """오늘. 테스트는 HVA_HUB_TODAY로 고정한다 (샘플이 W45라서, 날짜가 지나도 같은 결과가 나오게)."""
    v = os.environ.get("HVA_HUB_TODAY")
    return date.fromisoformat(v) if v else date.today()


def settings() -> dict:
    return _load("settings.yaml")


def sources() -> list[dict]:
    return _load("sources.yaml").get("sources", [])


def source(source_id: str) -> dict:
    for s in sources():
        if s["id"] == source_id:
            return s
    raise KeyError(source_id)


def optional(name: str) -> dict:
    """없어도 되는 설정 파일."""
    return _load(name) if (ROOT / "config" / name).exists() else {}


def config_mtime() -> float:
    """config 폴더 설정 파일 중 가장 최근 수정 시각. 바뀌면 결과 표를 다시 만든다.
    웹 버전(hub/web.py)은 앱을 열 때마다 코드가 새로 풀려 수정 시각이 바뀌므로 파일 내용으로 정한다
    (안 그러면 열 때마다 결과 표를 전부 다시 만든다)."""
    found = sorted((ROOT / "config").glob("*.yaml"))
    if os.environ.get("HVA_HUB_FILES_DIR"):
        return float(zlib.crc32(b"".join(p.name.encode() + p.read_bytes() for p in found)))
    return max(p.stat().st_mtime for p in found)


def data_dir() -> Path:
    """스냅샷·캐시 폴더.

    local = PC마다 따로: %LOCALAPPDATA%\\HVA SCM Hub\\<프로젝트 폴더 이름>-<경로 해시>
      프로젝트를 공유 폴더(OneDrive)에 두고 여러 명이 실행해도 서로 같은 파일을 고치지 않게 한다.
      같은 PC에서 프로젝트 사본이 둘이어도 섞이지 않게 경로 해시를 붙인다.
    그 밖의 값 = 프로젝트 폴더 기준 상대 경로 또는 절대 경로
    """
    override = os.environ.get("HVA_HUB_DATA_DIR")  # 시험용: 빈 폴더로 '처음 켜는 PC'를 흉내 낼 때
    if override:
        return Path(override)
    value = settings().get("data_dir", "local")
    if value != "local":
        p = Path(value)
        return p if p.is_absolute() else ROOT / p
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local") / "HVA SCM Hub"
    slug = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", ROOT.name)
    target = base / f"{slug}-{hashlib.md5(str(ROOT).lower().encode()).hexdigest()[:8]}"
    legacy = ROOT / "data"
    if not target.exists() and legacy.is_dir():
        # 예전처럼 프로젝트 안 data/에 쌓인 스냅샷이 있으면 한 번 옮겨 온다 (Decrypt했을 때 읽어 둔 값 보존)
        shutil.copytree(legacy, target)
    return target
