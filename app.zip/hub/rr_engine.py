"""RR 리뷰: 제안 RR v4.2를 원재료(Sell-in·Sell-out)로 다시 계산하고 엑셀 결과와 맞춰 본다 (docs/run-rate.md).

입력 = RR 파일 스냅샷 (readers.run_rate): Sell-in, Sell-out, pricelist, K-V, POS master (+ 있으면 '이전 RR 현행 RR' 탭).
'이전 RR 현행 RR' 탭은 아이템 마스터(현행 R/R·EOH·SRA·EOP)와 검증 정답지로만 쓴다. RR은 원재료로 계산한다.
수량은 소수 그대로 계산한다 (엑셀처럼 RR은 소수 1자리, EOH는 정수로 반올림). 화면에서만 정수로 보인다 (사용자 2026-11-10).
"""

import calendar
import math
import statistics
from datetime import date, datetime

import numpy as np
import pandas as pd

from . import config, store

VERSION = 3  # 3: 공식 플래그 PM 확인·EOP는 제안 RR > 0일 때만 (엑셀과 같게, 2026-11-11)
NAME = "RR 리뷰"
CACHE = "rr_result"
META = "rr_meta"
MONTHS = "rr_months"
CHECK = "rr_check"
SOURCE = "run_rate"

MONTH_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# 적용 규칙 이름 = 엑셀 BF 값 그대로
R_LIMITED, R_EOL, R_ZERO, R_MANUAL, R_DROP = "⓪ PL Limited", "⓪ PL EOL", "③ 6M≤1→0", "⑧ SRA<1년·SO부족→수동", "⑦ 급감→SI 3M"
R_SO, R_BLEND, R_SI = "⑨ SO만(SI 신뢰불가)", "⑥ 블렌드", "⑤ Sell-in만"
RULES = [R_LIMITED, R_EOL, R_ZERO, R_MANUAL, R_DROP, R_SO, R_BLEND, R_SI]
RED, YELLOW, NEW, EARLY = "🔴 수동입력", "🟡 검토", "🔵 신규 PM", "🟢 초기 RR"

# 엑셀 '이전 RR 현행 RR' 탭 열 → 계산 결과 열 이름 (검증할 때 같은 이름끼리 비교한다)
EXCEL = {
    "AU": "si_cap_base", "AV": "so_cap_base", "AW": "si6", "AX": "so6", "AY": "so3", "AZ": "so_flag", "BA": "blend",
    "BB": "trend", "BC": "sra_years", "BD": "age_factor", "BE": "formula_v41", "BF": "rule", "BG": "proposed_rr",
    "BH": "delta", "BI": "delta_pct", "BJ": "si6_only", "BK": "eop_months", "BL": "eop_factor", "BM": "formula_flags",
    "BN": "si_cv", "BO": "eoh_multiple", "BP": "eoh_rule", "BQ": "proposed_eoh", "BR": "eoh_cover", "BT": "pl_status",
    "BU": "pl_notes", "BV": "si3", "BW": "si6_b", "BX": "risk_flag", "BY": "risk_reason", "CB": "so_cv",
    "CC": "valid_months", "CD": "cv_ratio", "CE": "so_trend", "CF": "rr_v3", "CG": "si12_avg", "CH": "so12_avg",
    "CI": "si_so_ratio", "CJ": "v41_judgement", "CK": "rr_v4_raw", "EA": "formula_v42",
}
EXCEL_TEXT = {"so_flag", "rule", "formula_flags", "eoh_rule", "pl_status", "pl_notes", "risk_flag", "risk_reason", "v41_judgement"}

# 처음 어긋나는 단계를 찾을 때의 순서 (검증 리포트)
STAGES = [
    ("12개월 값", ["si12_check", "so12_check"]),
    ("캡 기준(중앙값)", ["si_cap_base", "so_cap_base"]),
    ("평균 (SI6·SI3·SO6·SO3)", ["si6", "si6_b", "si6_only", "si3", "so6", "so3", "so_flag"]),
    ("계수 (추세·나이·EOP)", ["trend", "so_trend", "sra_years", "age_factor", "eop_months", "eop_factor"]),
    ("변동성·총량비", ["si_cv", "so_cv", "cv_ratio", "valid_months", "si12_avg", "so12_avg", "si_so_ratio"]),
    ("PriceList", ["pl_status", "pl_notes"]),
    ("공식값", ["blend", "formula_v41", "rr_v3", "rr_v4_raw", "v41_judgement", "formula_v42"]),
    ("적용 규칙", ["rule"]),
    ("최종 제안 RR", ["proposed_rr", "delta", "delta_pct"]),
    ("EOH Target", ["eoh_multiple", "eoh_rule", "proposed_eoh", "eoh_cover"]),
    ("플래그", ["formula_flags", "risk_flag", "risk_reason"]),
]

# 화면 플래그: (코드, 표시, 이름, 리뷰가 필요한 것인지). 순서 = 심각한 순 (목록 정렬)
FLAGS = [
    ("red", "🔴", "수동입력 필요", True), ("manual", "✋", "수동 RR 필요", True), ("yellow", "🟡", "검토", True),
    ("delta", "⚠", "Δ 검토", True), ("project", "🏗", "프로젝트 보정", True), ("new", "🔵", "신규", True),
    ("early", "🟢", "초기", True), ("surge", "📈", "급증", True), ("drop", "📉", "급감", True),
    ("pl", "⛔", "Limited/EOL", False), ("eop", "⏳", "EOP 6M 이내", False), ("kv", "🇰🇷", "K/V 그룹", False),
    # 엔진이 붙이지 않는다. RR 파일에 없는 Base Item에 화면이 붙인다 (service.rr_table, 사용자 2026-11-11). 맨 뒤라 RANK는 그대로
    ("norr", "📝", "RR 파일 없음", True),
]
FLAG = {c: (icon, name, review) for c, icon, name, review in FLAGS}
RANK = {c: i for i, (c, *_) in enumerate(FLAGS)}
# 우선순위 (화면 목록 정렬·배지, Claude 제안 2026-11-10): 리뷰 플래그 중 가장 높은 것
HIGH, MID, LOW = "상", "중", "하"
PRIORITY = {"red": HIGH, "manual": HIGH, "norr": HIGH, "yellow": MID, "delta": MID, "project": MID,
            "new": LOW, "early": LOW, "surge": LOW, "drop": LOW}
PRIORITIES = [HIGH, MID, LOW]


def params() -> dict:
    return config.optional("rr.yaml")


# ---- 반올림·달 ------------------------------------------------------------------------

def xround(x, digits: int = 0):
    """Excel ROUND (0.5는 0에서 먼 쪽). 빈 값은 그대로."""
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return float("nan")
    f = 10 ** digits
    return math.copysign(math.floor(abs(x) * f + 0.5 + 1e-9) / f, x)


def mshift(ym: str, k: int) -> str:
    y, m = int(ym[:4]), int(ym[5:7])
    n = y * 12 + (m - 1) + k
    return f"{n // 12:04d}-{n % 12 + 1:02d}"


def mrange(end: str, n: int) -> list[str]:
    """end로 끝나는 n개월."""
    return [mshift(end, k) for k in range(-n + 1, 1)]


def mlabel(ym: str) -> str:
    """'2026-01' → '26-Jan' (엑셀 근거 문구 모양)."""
    return f"{ym[2:4]}-{MONTH_ABBR[int(ym[5:7]) - 1]}"


def _nan(x) -> bool:
    return x is None or (isinstance(x, float) and math.isnan(x))


def _mean(v: list) -> float:
    return sum(v) / len(v) if v else 0.0


def _median(v: list) -> float:
    return statistics.median(v) if v else 0.0


def _cv(v: list) -> float:
    """표준편차(표본) ÷ 평균, 음수는 0. 평균 0이면 빈칸 (엑셀 IFERROR)."""
    v = [max(x, 0) for x in v]
    a = _mean(v)
    return statistics.stdev(v) / a if a and len(v) > 1 else float("nan")


# ---- 기간 ------------------------------------------------------------------------------

def periods(si: pd.DataFrame, so: pd.DataFrame, p: dict) -> dict:
    """RR 기간. SI 마지막 달 = 실적이 있는 마지막 달, RR 기준일 = 그 달 말일, SO 마지막 달 = Sell-out 실적이 있는 마지막 달."""
    def last_month(t):
        t = t[t["qty"].abs() > 0]
        return t["month"].max() if len(t) else None
    si_end = last_month(si)
    so_end = last_month(so) or mshift(si_end, -1)
    y, m = int(si_end[:4]), int(si_end[5:7])
    base = date(y, m, calendar.monthrange(y, m)[1])
    return {"si_end": si_end, "so_end": so_end, "base_date": base.isoformat(), "pos_lag": _months_between(so_end, si_end),
            "basis": mshift(si_end, 1),        # RR 기준월 (리뷰 입력을 묶는 단위)
            "si12": mrange(si_end, 12), "si6": mrange(si_end, 6), "si3": mrange(si_end, 3),
            "so12": mrange(so_end, 12), "so6": mrange(so_end, 6), "so3": mrange(so_end, 3),
            "si_all": sorted(si["month"].unique()), "so_all": sorted(so["month"].unique())}


def _months_between(a: str, b: str) -> int:
    return (int(b[:4]) * 12 + int(b[5:7])) - (int(a[:4]) * 12 + int(a[5:7]))


# ---- PriceList 판정 (엑셀 BT·BU와 1,818개 같음, 2026-11-10) -------------------------------

def _one_line(v) -> str:
    """엑셀처럼 줄바꿈을 ' | '로 (앞뒤 공백은 그대로)."""
    return "" if _nan(v) else str(v).replace("\r\n", "\n").replace("\n", " | ")


def pl_status(items: list[str], pricelist: pd.DataFrame, eol: pd.DataFrame, pos_master: pd.DataFrame,
              taa: pd.DataFrame | None = None) -> pd.DataFrame:
    """PriceList Item#(모델명)을 아이템에 붙인다: Item#가 아이템과 같으면 그대로, 아니면 POS master에서
    그 POS SKU의 첫 줄 PO SKU (엑셀 VLOOKUP처럼 첫 줄만). Notes에 'Limited Stock' → Limited, EOL 목록 → EOL (EOL이 우선)."""
    up = lambda s: str(s).strip().upper() if isinstance(s, str) and s.strip() else None
    first = {}
    for pos, po in zip(pos_master["pos_sku"], pos_master["po_sku"]):
        if up(pos) and up(pos) not in first:
            first[up(pos)] = up(po)
    key = {up(i): i for i in items}
    def targets(no):
        return {key[t] for t in (up(no), first.get(up(no))) if t in key}
    out = {i: {"item": i, "pl_status": "", "pl_notes": "", "msrp": np.nan, "pl_item": None, "eol_date": pd.NaT,
               "replacement": None, "taa": False} for i in items}
    for r in pricelist.itertuples(index=False):
        for t in targets(r.item_no):
            o = out[t]
            if o["pl_item"] is None:
                o.update(pl_item=r.item_no, msrp=_num(r.msrp))
            if "LIMITED STOCK" in str(r.notes or "").upper() and not o["pl_status"]:
                o.update(pl_status="Limited", pl_notes=_one_line(r.notes))
    for r in eol.itertuples(index=False):
        for t in targets(r.item_no):
            d = pd.to_datetime(r.eol_date, errors="coerce")
            rep = _one_line(r.replacement)
            out[t].update(pl_status="EOL", eol_date=d, replacement=rep,
                          pl_notes=f"EOL {d:%Y-%m-%d} / 대체: {rep}" if pd.notna(d) else f"EOL / 대체: {rep}")
            if _nan(out[t]["msrp"]):
                out[t]["msrp"] = _num(r.msrp)
    if taa is not None:
        for no in taa["item_no"]:
            for t in targets(no):
                out[t]["taa"] = True
    return pd.DataFrame(list(out.values()))


# ---- 월 값 (K/V 배분) --------------------------------------------------------------------

def monthly(items: list[str], si: pd.DataFrame, so: pd.DataFrame, kv: pd.DataFrame, per: dict) -> tuple[pd.DataFrame, pd.DataFrame, set]:
    """아이템 × 달 표 (Sell-in, Sell-out). K/V 그룹은 그룹 합계 × 배분비율 (배분비율 = 자기 최근 3M Sell-in ÷ 그룹 최근 3M,
    음수 0). Sell-out이 있는 아이템 = Sell-out 탭에 있거나 K/V 그룹에 Sell-out이 있는 아이템."""
    si_w = si.pivot_table(index="item", columns="month", values="qty", aggfunc="sum").reindex(columns=per["si_all"]).fillna(0.0)
    so_w = so.pivot_table(index="item", columns="month", values="qty", aggfunc="sum").reindex(columns=per["so_all"]).fillna(0.0)
    has_so = set(so_w.index)
    si_out = si_w.reindex(items).fillna(0.0)
    so_out = so_w.reindex(items).fillna(0.0)
    for base, g in kv.groupby("base_model"):
        members = [m for m in g["item"] if m in si_out.index]
        if not members:
            continue
        own3 = si_w.reindex(members).fillna(0.0)[per["si3"]].clip(lower=0).sum(axis=1)
        total3 = own3.sum()
        ratio = own3 / total3 if total3 else pd.Series(1.0 / len(members), index=members)
        si_group = si_w.reindex(g["item"]).fillna(0.0).sum()
        so_group = so_w.reindex(g["item"]).fillna(0.0).sum()
        group_has_so = any(m in has_so for m in g["item"])
        for m in members:
            si_out.loc[m] = si_group * ratio[m]
            so_out.loc[m] = so_group * ratio[m]
            if group_has_so:
                has_so.add(m)
    return si_out, so_out, has_so & set(items)


# ---- 계산 ------------------------------------------------------------------------------

def calc(master: pd.DataFrame, si_w: pd.DataFrame, so_w: pd.DataFrame, has_so: set, pl: pd.DataFrame,
         per: dict, p: dict, kv_items: set = frozenset()) -> pd.DataFrame:
    """아이템마다 엑셀 '이전 RR 현행 RR' W:EC와 같은 값을 만든다 (docs/run-rate.md 4장)."""
    base = date.fromisoformat(per["base_date"])
    hoard = {g: set(ms) for g, ms in (p.get("hoarding_months") or {}).items()}
    ages = sorted(p["age_factors"])
    so6p = p["so_only"]
    plmap = pl.set_index("item").to_dict("index")
    rows = []
    for r in master.itertuples(index=False):
        item, group = r.item, (r.product_group if isinstance(r.product_group, str) else "")
        si = si_w.loc[item]
        so = so_w.loc[item]
        ex = hoard.get(group, set())
        o = {"item": item, "has_so": item in has_so}
        si12 = [float(si[m]) for m in per["si12"]]
        so12 = [float(so[m]) for m in per["so12"]]
        o["si12"], o["so12"] = si12, so12
        keep = [m for m in per["si12"] if m not in ex]
        vals = [max(float(si[m]), 0) for m in keep]
        au = _median(vals) or _mean(vals)
        o["si_cap_base"] = au

        def si_avg(months, k):
            v = [min(max(float(si[m]), 0), au * k) for m in months if m not in ex]
            return _mean(v)
        o["si6"] = o["si6_b"] = si_avg(per["si6"], p["cap_blend"])
        o["si6_only"] = si_avg(per["si6"], p["cap_si_only"])
        o["si3"] = si_avg(per["si3"], p["cap_blend"])
        if o["has_so"]:
            v = [max(x, 0) for x in so12]
            av = _median(v) or _mean(v)
            o["so_cap_base"] = av
            o["so6"] = _mean([min(max(float(so[m]), 0), av * p["cap_blend"]) for m in per["so6"]])
            o["so3"] = _mean([min(max(float(so[m]), 0), av * p["cap_blend"]) for m in per["so3"]])
            o["blend"] = p["blend_so_weight"] * o["so6"] + (1 - p["blend_so_weight"]) * o["si6"]
            o["so_flag"] = ""
        else:
            o.update(so_cap_base=np.nan, so6=np.nan, so3=np.nan, blend=np.nan, so_flag="SO없음")
        a, cap = p["trend_alpha"], p["trend_cap"]
        r_so = o["so3"] / o["so6"] if o["has_so"] and o["so6"] else None
        r_si = o["si3"] / o["si6"] if o["si6"] else None
        ratios = [x for x in (r_so, r_si) if x is not None]
        o["trend"] = max(1 - cap, min(1 + cap, 1 + (_mean(ratios) - 1) * a)) if ratios else 1.0
        o["so_trend"] = max(1 - cap, min(1 + cap, 1 + ((r_so if r_so is not None else 1) - 1) * a))
        sra, eop = _date(r.sra), _date(r.eop)
        o["sra_years"] = (base - sra).days / 365 if sra else np.nan
        o["age_factor"] = 1.0 if not sra else next((f for lo, f in reversed(ages) if o["sra_years"] >= lo), ages[0][1])
        o["eop_months"] = xround((eop - base).days / 30.4, 1) if eop else np.nan
        o["eop_factor"] = p["eop_factor"] if eop and o["eop_months"] <= p["eop_months"] else 1.0
        o["si_cv"] = _cv(si12)
        o["so_cv"] = _cv(so12) if o["has_so"] else np.nan
        o["cv_ratio"] = o["si_cv"] / o["so_cv"] if not _nan(o["si_cv"]) and not _nan(o["so_cv"]) and o["so_cv"] else np.nan
        lim = max(au, 0 if _nan(o["so6"]) else o["so6"]) * so6p["si_outlier"]
        o["valid_months"] = sum(1 for m in per["si6"] if m not in ex and not float(si[m]) > lim)
        o["si12_avg"] = _mean([max(x, 0) for x in si12])
        o["so12_avg"] = _mean([max(x, 0) for x in so12]) if o["has_so"] else np.nan
        o["si_so_ratio"] = o["si12_avg"] / o["so12_avg"] if not _nan(o["so12_avg"]) and o["so12_avg"] else np.nan

        # 공식값 (BE = v4.1)
        age, eopf = o["age_factor"], o["eop_factor"]
        blend_ok = o["has_so"] and o["so6"] >= p["blend_min_so6"] and group not in (p.get("si_only_groups") or [])
        v4 = bool(blend_ok and _le(o["so_cv"], so6p["so_cv_max"])
                  and ((_ge(o["si_cv"], so6p["si_cv_min"]) and _ge(o["cv_ratio"], so6p["cv_ratio_min"]))
                       or o["valid_months"] < so6p["min_valid_months"]))
        v41 = v4 and _ge(o["si_so_ratio"], so6p["ratio_low"]) and not _ge(o["si_so_ratio"], so6p["ratio_high"])
        o["v4_so_only"], o["v41_so_only"] = v4, v41
        si_only_value = o["si6_only"] * age * eopf
        if blend_ok:
            o["blend_value"] = o["blend"] * o["trend"] * age * eopf
            o["so_only_value"] = o["so6"] * o["so_trend"] * age * eopf
            value, formula = (o["so_only_value"], R_SO) if v41 else (o["blend_value"], R_BLEND)
            v3_value, v4_value = o["blend_value"], (o["so_only_value"] if v4 else value)
        else:
            o["blend_value"] = o["so_only_value"] = np.nan
            value, formula = si_only_value, R_SI
            v3_value = v4_value = value
        o["si_only_value"] = si_only_value
        o["formula"] = formula
        o["v41_judgement"] = ("⑨ 유지" if v41 else "⑥ 블렌드 복귀(SI총량<SO)" if _nan(o["si_so_ratio"]) or o["si_so_ratio"] < so6p["ratio_low"]
                              else "⑥ 블렌드 복귀(SI총량≫SO)") if v4 else ""
        o["formula_v41"] = xround(value, 1)
        # v4.2 프로젝트 보정: 원천 라인이 없어 엑셀 값(EA)을 그대로 받는다. 차감이 없으면 v4.1과 같다
        proj_qty = _num(getattr(r, "proj_qty", np.nan))
        proj_rr = _num(getattr(r, "proj_rr", np.nan))
        o["proj_qty"] = proj_qty
        o["formula_v42"] = proj_rr if proj_qty > 0 and not _nan(proj_rr) else o["formula_v41"]

        # 최종 제안 RR (BG): 먼저 걸리는 규칙
        pi = plmap.get(item, {})
        pls = pi.get("pl_status", "")
        o["pl_status"], o["pl_notes"] = pls, pi.get("pl_notes", "")
        v42 = o["formula_v42"]
        so6v = 0.0 if _nan(o["so6"]) else o["so6"]
        current = _num(r.rr_current)
        manual = _num(getattr(r, "manual_rr", np.nan))

        def final(v, formula_rule):
            if pls == "Limited":
                return R_LIMITED, min(v, o["si6"]) * p["limited_factor"]
            if pls == "EOL":
                return R_EOL, min(v, o["si3"], o["si6"]) * p["eol_factor"]
            if max(o["si6_only"], so6v) <= p["zero_max"]:
                return R_ZERO, 0.0
            if sra and o["sra_years"] < p["manual_sra_years"] and so6v < p["blend_min_so6"]:
                return R_MANUAL, manual if not _nan(manual) else (0.0 if _nan(current) else current)
            if o["si6"] >= p["drop_min_si6"] and o["si3"] <= o["si6"] * p["drop_ratio"]:
                return R_DROP, min(v, o["si3"])
            return formula_rule, v
        rule, rr = final(v42, formula)
        o["rule"], o["proposed_rr"] = rule, xround(rr, 1)
        if rule not in (R_BLEND, R_SO):
            o["v41_judgement"] = ""      # 엑셀 CJ는 ⑥·⑨로 확정된 아이템에만 쓴다
        o["rr_v3"] = xround(final(xround(v3_value, 1), formula)[1], 1)        # CF: ⑨ 전에 (v3 공식) 규칙까지
        o["rr_v4_raw"] = xround(final(xround(v4_value, 1), formula)[1], 1)    # CK: ⑨를 총량비로 되돌리기 전 (v4)
        o["manual_rr"] = manual
        o["rr_current"] = current
        o["delta"] = xround(o["proposed_rr"] - current, 1) if not _nan(current) else np.nan
        o["delta_pct"] = (o["proposed_rr"] - current) / current if not _nan(current) and current else np.nan

        # EOH Target
        e = p["eoh"]
        if pls in ("Limited", "EOL"):
            mult, erule = e["limited_multiple"] if pls == "Limited" else e["eol_multiple"], f"⓪ PL {pls} → ×0"
        elif o["proposed_rr"] == 0:
            mult, erule = 0, "① RR 0"
        elif o["eop_factor"] < 1:
            mult, erule = e["eop_multiple"], "③ EOP≤6M → ×0"
        elif _ge(o["si_cv"], e["cv_min"]):
            mult, erule = e["high_cv"], "④ 고변동 CV≥1 → ×1.5"
        else:
            mult, erule = e["base"], "⑤ 기본 ×1"
        o["eoh_multiple"], o["eoh_rule"] = mult, erule
        o["proposed_eoh"] = xround(o["proposed_rr"] * mult, 0)
        o["eoh_cover"] = o["proposed_eoh"] / o["proposed_rr"] if o["proposed_rr"] else 0.0
        o["eoh_current"] = _num(getattr(r, "eoh_current", np.nan))

        o["formula_flags"] = _formula_flags(o, sra, current, p)
        o["risk_flag"], o["risk_reason"], o["early_rr"] = _risk(o, sra, si, so, per, p)
        o["kv"] = item in kv_items
        rows.append(o)
    out = pd.DataFrame(rows)
    return _screen_flags(out, si_w, so_w, per, p)


def _num(v) -> float:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return float("nan")
    return f


def _date(v):
    if v is None or (isinstance(v, float) and math.isnan(v)) or v is pd.NaT:
        return None
    try:
        d = pd.Timestamp(v)
    except (TypeError, ValueError):
        return None
    return None if pd.isna(d) else d.date()


def _ge(x, y) -> bool:
    return not _nan(x) and x >= y


def _le(x, y) -> bool:
    return not _nan(x) and x <= y


def _formula_flags(o: dict, sra, current: float, p: dict) -> str:
    """엑셀 BM. 현행·제안이 둘 다 0이면 ⑧ 문구만.
    PM 확인·EOP 문구는 제안 RR > 0일 때만 (2026-11-11 파일: 현행 > 0 · 제안 0인 SKU 11개에서 엑셀은 안 붙임,
    제안 > 0이면 PM 39/39 · EOP 139/139 붙임). Δ 문구는 제안이 0이어도 붙는다."""
    t = []
    proposed = o["proposed_rr"] > 0
    if o["rule"] == R_MANUAL:
        t.append("수동입력 필요(SRA<1년, 현행값 임시)")
    elif sra and o["sra_years"] < p["manual_sra_years"] and proposed:
        t.append("PM 확인(SRA<1년)")
    if o["eop_factor"] < 1 and proposed:
        t.append(f"EOP≤{p['eop_months']}M(×{p['eop_factor']})")
    d = p["delta_review"]
    if not _nan(o["delta_pct"]) and abs(o["delta_pct"]) > d["pct"] and abs(o["delta"]) >= d["min_units"]:
        t.append(f"Δ±{d['pct']:.0%}↑ 검토")
    if o["proposed_rr"] == 0 and (_nan(current) or current == 0):
        return t[0] if o["rule"] == R_MANUAL else ""
    return " ".join(t)


def _risk(o: dict, sra, si: pd.Series, so: pd.Series, per: dict, p: dict) -> tuple[str, str, float]:
    """엑셀 BX·BY (RR 위험 플래그·근거). 🟢 초기는 최근 3M으로 RR을 제안한다 (세 번째 값)."""
    k = p["risk"]
    if o["pl_status"] in ("Limited", "EOL"):
        return "", "", np.nan
    si12 = [max(x, 0) for x in o["si12"]]
    so12 = [max(x, 0) for x in o["so12"]] if o["has_so"] else [0.0] * 12
    s12, o12 = sum(si12), sum(so12)
    si_share = max(si12) / s12 if s12 else 0
    so_share = max(so12) / o12 if o12 else 0
    si_part = f"SI {mlabel(per['si12'][si12.index(max(si12))])} {max(si12):,.0f} (12M 중 {xround(si_share * 100):.0f}%)"
    so_part = f"SO {mlabel(per['so12'][so12.index(max(so12))])} {max(so12):,.0f} (12M 중 {xround(so_share * 100):.0f}%)"
    flag, reason = "", ""
    if o["has_so"] and o12 >= k["min_total"]:
        if si_share >= k["yellow_share"] and so_share >= k["yellow_share"]:
            flag = RED if max(si_share, so_share) >= k["red_share"] else YELLOW
            reason = f"SI·SO 모두 단월 집중 → 프로젝트성, RR 직접 판단 | {si_part} · {so_part}"
        elif so_share >= k["red_share"]:
            flag, reason = YELLOW, f"SO만 단월 집중 → 프로젝트성 의심 | {so_part}"
    elif s12 >= k["min_total"]:
        head = f"SO 12M {o12:,.0f}대 미미 → SI만 판정" if o["has_so"] else "SO 매핑 없음 → SI만 판정"
        if si_share >= k["red_share"]:
            flag, reason = RED, f"{head} | {si_part}"
        elif si_share >= k["yellow_share"]:
            flag, reason = YELLOW, f"{head} | {si_part}"
    years = o["sra_years"]
    if sra and 0 <= years < k["new_sra_years"] and max(s12, o12) >= k["min_total"]:
        return NEW, f"SRA {mlabel(sra.strftime('%Y-%m'))} ({xround(years * 12):.0f}M) → PM FCST", np.nan
    if flag and sra and years < k["early_sra_years"]:
        use_so = o["has_so"] and sum(1 for x in so12 if x > 0) >= k["early_so_months"]
        months = per["so3"] if use_so else per["si3"]
        v = [max(float((so if use_so else si)[m]), 0) for m in months]
        total = sum(v)
        cut = next((i for i, x in enumerate(v) if total and x >= total * k["early_single_month"]), None)
        rest = [x for i, x in enumerate(v) if i != cut]
        early = xround(_mean(rest))
        shown = "/".join(f"{x:,.0f}" + ("(제외)" if i == cut else "") for i, x in enumerate(v))
        return EARLY, f"SRA {xround(years * 12):.0f}M | {'SO' if use_so else 'SI'} 3M {shown} → RR 제안 {early:.0f}", early
    return flag, reason, np.nan


def _screen_flags(out: pd.DataFrame, si_w: pd.DataFrame, so_w: pd.DataFrame, per: dict, p: dict) -> pd.DataFrame:
    """화면 플래그와 한 줄 사유. 엑셀에 없는 📈 급증만 Claude 제안 (config/rr.yaml surge)."""
    s = p.get("surge") or {"ratio": 2.0, "min_units": 10}
    codes, reasons = [], []
    for o in out.to_dict("records"):
        c, why = [], []
        if o["risk_flag"] == RED:
            c.append("red"); why.append(o["risk_reason"])
        if o["rule"] == R_MANUAL:
            c.append("manual")
            why.append("출시 1년 미만·Sell-out 부족 → 수동 RR 필요 (수동 RR 데이터 미연결, 지금은 현행 R/R 임시)")
        if o["risk_flag"] == YELLOW:
            c.append("yellow"); why.append(o["risk_reason"])
        d = p["delta_review"]
        if not _nan(o["delta_pct"]) and abs(o["delta_pct"]) > d["pct"] and abs(o["delta"]) >= d["min_units"]:
            c.append("delta")
            why.append(f"현행 {o['rr_current']:,.0f} → 제안 {o['proposed_rr']:,.0f} ({o['delta']:+,.0f}, {o['delta_pct']:+.0%})")
        if o.get("proj_qty", 0) > 0:
            c.append("project"); why.append(f"$1M↑ 프로젝트 수량 {o['proj_qty']:,.0f}대를 빼고 계산")
        if o["risk_flag"] == NEW:
            c.append("new"); why.append(o["risk_reason"])
        if o["risk_flag"] == EARLY:
            c.append("early"); why.append(o["risk_reason"])
        surge = []      # SI·SO 둘 다 급증이면 한 줄로 (플래그 하나 = 사유 한 줄)
        for kind, w, months in (("SI", si_w, per["si6"]), ("SO", so_w, per["so6"])):
            if kind == "SO" and not o["has_so"]:
                continue
            v = [max(float(w.loc[o["item"], m]), 0) for m in months]
            avg6, last1, last2 = _mean(v), v[-1], _mean(v[-2:])
            top = max(last1, last2)
            if avg6 and top >= avg6 * s["ratio"] and top >= s["min_units"]:
                label = f"{mlabel(months[-1])} {last1:,.0f}" if last1 >= last2 else f"최근 2개월 평균 {last2:,.0f}"
                surge.append(f"{kind} {label} = 6M 평균 {avg6:,.0f}의 {top / avg6:.1f}배")
        if surge:
            c.append("surge"); why.append(" · ".join(surge))
        if o["rule"] == R_DROP:
            c.append("drop"); why.append(f"SI 3M {o['si3']:,.0f} ≤ SI 6M {o['si6']:,.0f} × {p['drop_ratio']} → SI 3M으로")
        if o["pl_status"]:
            c.append("pl"); why.append(f"PriceList {o['pl_status']}: {o['pl_notes']}")
        if o["eop_factor"] < 1:
            c.append("eop"); why.append(f"EOP까지 {o['eop_months']:.1f}개월 → ×{p['eop_factor']}")
        if o["kv"]:
            c.append("kv"); why.append("K/V 그룹: 그룹 합계 × 배분비율로 계산 (SKU끼리 합치지 않음, TAA)")
        codes.append(c)
        reasons.append(why)
    out["flags"] = codes
    out["flag_reasons"] = reasons
    out["flag_icons"] = [" ".join(FLAG[x][0] for x in c) for c in codes]
    out["review"] = [any(FLAG[x][2] for x in c) for c in codes]
    out["severity"] = [min((RANK[x] for x in c if FLAG[x][2]), default=len(FLAGS)) for c in codes]
    out["priority"] = [next((PRIORITY[x] for x in sorted(c, key=RANK.get) if x in PRIORITY), "") for c in codes]
    return out


def flag_rule(code: str, p: dict) -> str:
    """플래그가 걸리는 기준 (화면 '플래그 근거'의 '기준' 줄). 숫자는 config/rr.yaml 값."""
    k, d, s = p["risk"], p["delta_review"], p.get("surge") or {}
    return {
        "red": f"12M 판매 {k['min_total']}대 이상인데 한 달에 {k['red_share']:.0%} 이상 몰림 (Sell-out이 있으면 SI·SO 둘 다 {k['yellow_share']:.0%} 이상)",
        "manual": f"⑧ SRA {p['manual_sra_years']}년 미만 · SO6 {p['blend_min_so6']} 미만 → PM 포캐스트로 수동 RR",
        "yellow": f"12M 판매 {k['min_total']}대 이상인데 한 달에 {k['yellow_share']:.0%} 이상 몰림 (SO만이면 {k['red_share']:.0%} 이상)",
        "delta": f"|제안 − 현행| ÷ 현행 > {d['pct']:.0%} 이고 차이 {d['min_units']}대 이상",
        "project": "$1M 이상 프로젝트 수량을 빼고 계산 (v4.2)",
        "new": f"SRA {k['new_sra_years'] * 12:.0f}개월 미만 · 12M 판매 {k['min_total']}대 이상 → PM 포캐스트",
        "early": f"위험 플래그 + SRA {k['early_sra_years']}년 미만 → 최근 3개월로 RR 제안 (한 달이 {k['early_single_month']:.0%} 이상이면 그 달 빼고)",
        "surge": f"최근 1개월 또는 2개월 평균이 6M 평균의 {s.get('ratio')}배 이상 · {s.get('min_units')}대 이상 (Claude 제안 기준)",
        "drop": f"⑦ SI6 {p['drop_min_si6']} 이상 · SI3 ≤ SI6 × {p['drop_ratio']}",
        "pl": "PriceList Limited Stock 또는 EOL 목록 → ⓪ 작은 값 규칙",
        "eop": f"EOP까지 {p['eop_months']}개월 이내 → × {p['eop_factor']}",
        "kv": "K/V 그룹 (TAA): 그룹 합계를 SKU별 최근 3M 비율로 나눔",
        "norr": "Base Item인데 RR 파일에 없음 → Sell-in·Sell-out·제안 RR 없음, RR 직접 입력",
    }.get(code, "")


# ---- 아이템 마스터 -------------------------------------------------------------------------

MASTER = ["item", "item_name", "product_group", "series", "model_group", "product_type", "asp", "from_site", "to_site",
          "sra", "eol", "eop", "rr_current", "eoh_current", "avg_prev_year", "avg_6m", "avg_3m", "old_model", "manual_rr",
          "proj_qty", "proj_first_so", "proj_rr", "proj_delta", "proj_flag"]


def master_from_sources(si_items: list[str], so_info: pd.DataFrame, descs: dict) -> pd.DataFrame:
    """'이전 RR 현행 RR' 탭이 없을 때: Sell-in·Sell-out에 있는 아이템, 마스터는 Sell-out 탭 속성. 현행 R/R은 없음."""
    info = so_info.drop_duplicates("item").set_index("item")
    items = sorted(set(si_items) | set(info.index))
    m = pd.DataFrame({"item": items})
    for c in ("product_group", "series", "sra", "eol", "eop"):
        m[c] = m["item"].map(info[c]) if c in info else None
    m["item_name"] = m["item"].map(descs)
    for c in MASTER:
        if c not in m:
            m[c] = np.nan
    return m[MASTER]


# ---- 검증: 엑셀 결과와 맞춰 보기 -------------------------------------------------------------

def _same(a, b, text: bool) -> bool:
    if text:
        return str("" if _nan(a) else a).strip() == str("" if _nan(b) else b).strip()
    an, bn = _nan(a), _nan(b)
    if an or bn:
        return an and bn
    return abs(float(a) - float(b)) <= 1e-6 * max(1.0, abs(float(b)))


def validate(result: pd.DataFrame, excel: pd.DataFrame, excel_months: pd.DataFrame | None, per: dict) -> tuple[dict, pd.DataFrame]:
    """엑셀 '이전 RR 현행 RR' 값과 아이템마다 비교. (요약, 어긋난 아이템 표: item, stage, column, excel, engine)."""
    r = result.set_index("item")
    x = excel.set_index("item")
    items = [i for i in x.index if i in r.index]
    if excel_months is not None and len(excel_months):
        em = excel_months.pivot_table(index="item", columns=["kind", "month"], values="qty", aggfunc="sum")
    else:
        em = None
    cols = {c: (c in EXCEL_TEXT) for c in EXCEL.values() if c in x.columns}
    summary = {c: {"match": 0, "total": 0} for c in list(cols) + ["si12_check", "so12_check"]}
    bad = []
    for i in items:
        first = None
        miss = []
        for c, is_text in cols.items():
            ev, gv = x.at[i, c], r.at[i, c]
            if c in ("formula_v41", "formula_v42", "rr_v3", "rr_v4_raw") and _nan(ev) and r.at[i, "rule"] in (R_ZERO, R_MANUAL):
                ev = gv       # 엑셀은 ③·⑧이면 공식값을 비워 둔다
            ok = _same(ev, gv, is_text)
            summary[c]["total"] += 1
            summary[c]["match"] += ok
            if not ok:
                miss.append((c, ev, gv))
        if em is not None and i in em.index:
            for kind, months, key in (("si", per["si12"], "si12"), ("so", per["so12"], "so12")):
                ev = [em.at[i, (kind, m)] if (kind, m) in em.columns else np.nan for m in months]
                gv = r.at[i, key]
                ok = all(_same(a, b, False) for a, b in zip(ev, gv))
                summary[f"{key}_check"]["total"] += 1
                summary[f"{key}_check"]["match"] += ok
                if not ok:
                    miss.append((f"{key}_check", "", ""))
        if miss:
            names = {m[0] for m in miss}
            stage = next((s for s, cs in STAGES if names & set(cs)), "기타")
            c0 = next(m for s, cs in STAGES if s == stage for m in miss if m[0] in cs) if stage != "기타" else miss[0]
            bad.append({"item": i, "stage": stage, "column": c0[0], "excel": str(c0[1]), "engine": str(c0[2]),
                        "columns": ", ".join(sorted(names))})
    check = pd.DataFrame(bad, columns=["item", "stage", "column", "excel", "engine", "columns"])
    by_stage = check["stage"].value_counts().to_dict() if len(check) else {}
    letters = {v: k for k, v in EXCEL.items()}
    out = {"items": len(items), "all_match": len(items) - len(check),
           "columns": [{"column": c, "excel_col": letters.get(c, "W:AT"), "match": v["match"], "total": v["total"]}
                       for c, v in summary.items() if v["total"]],
           "by_stage": by_stage}
    return out, check


def param_diff(p: dict, formula: dict) -> list[dict]:
    """config/rr.yaml 값과 RR 파일 'RR Formula' 탭 값이 다른 것."""
    def get(d, path):
        for k in path.split("."):
            if not isinstance(d, dict) or k not in d:
                return None
            d = d[k]
        return d
    out = []
    for key, v in (formula or {}).items():
        mine = get(p, key)
        if mine is None or v is None:
            continue
        same = (abs(float(mine) - float(v)) < 1e-9) if isinstance(mine, (int, float)) and isinstance(v, (int, float)) else mine == v
        if not same:
            out.append({"key": key, "config": mine, "excel": v})
    return out


# ---- 만들기 (ingest.DERIVED) ----------------------------------------------------------------

def run(tables: dict, entry: dict | None = None, p: dict | None = None) -> dict:
    """스냅샷 표들로 계산 + 검증. 결과 dict: result, months, check, meta."""
    p = p or params()
    si, so = tables["sell_in"], tables["sell_out"]
    per = periods(si, so, p)
    master = tables.get("master")
    if master is None or master.empty:
        descs = si.drop_duplicates("item").set_index("item")["desc"].to_dict() if "desc" in si else {}
        master = master_from_sources(sorted(si["item"].unique()), tables["sell_out_info"], descs)
        master_source = "Sell-in·Sell-out 탭 (현행 R/R 없음)"
    else:
        master_source = "이전 RR 현행 RR 탭"
    items = master["item"].tolist()
    kv = tables["kv"]
    si_w, so_w, has_so = monthly(items, si, so, kv, per)
    pl = pl_status(items, tables["pricelist"], tables["pl_eol"], tables["pos_master"], tables.get("taa"))
    result = calc(master, si_w, so_w, has_so, pl, per, p, kv_items=set(kv["item"]) & set(items))
    keep = ["item"] + [c for c in MASTER if c not in result.columns]
    result = master[keep].merge(result, on="item", how="right")
    result = result.merge(pl[["item", "msrp", "pl_item", "eol_date", "replacement", "taa"]], on="item", how="left")
    info = tables.get("sell_out_info")
    if info is not None and len(info):
        cols = [c for c in ("pos_model", "pos_count", "bom", "plc_status", "soc", "resolution", "moq_lt", "category") if c in info]
        result = result.merge(info.drop_duplicates("item")[["item"] + cols], on="item", how="left")
    groups = kv.set_index("item")["base_model"].to_dict()
    result["kv_group"] = result["item"].map(groups)
    months = _months_long(items, si_w, so_w, tables, per)
    meta = {"version": VERSION, "settings_mtime": config.config_mtime(), "built_at": datetime.now().isoformat(timespec="seconds"),
            "file": (entry or {}).get("file"), "file_date": (entry or {}).get("file_date"),
            "periods": {k: v for k, v in per.items() if k not in ("si_all", "so_all")},
            "params_version": p.get("version"), "master_source": master_source,
            "formula": (entry or {}).get("formula") or {}, "param_diff": param_diff(p, (entry or {}).get("formula") or {}),
            "items": len(result), "kv_items": int(result["kv"].sum()),
            "project_status": (entry or {}).get("project_status"), "excel_base_date": (entry or {}).get("excel_base_date"),
            "excel_version": (entry or {}).get("excel_version")}
    check = pd.DataFrame(columns=["item", "stage", "column", "excel", "engine", "columns"])
    excel = tables.get("excel")
    if excel is not None and not excel.empty:
        meta["validation"], check = validate(result, excel, tables.get("excel_months"), per)
    return {"result": result, "months": months, "check": check, "meta": meta}


def _months_long(items, si_w, so_w, tables, per) -> pd.DataFrame:
    """차트용 달별 값 (계산에 쓴 값 = K/V는 배분 후)."""
    def long(w, kind):
        t = w.reindex(items).stack().rename("qty").reset_index()
        t.columns = ["item", "month", "qty"]
        t["kind"] = kind
        return t
    out = pd.concat([long(si_w, "si"), long(so_w, "so")], ignore_index=True)
    adj = tables.get("project_adj")
    if adj is not None and len(adj):
        out = out.merge(adj.rename(columns={"qty": "after_project"}), on=["item", "kind", "month"], how="left")
    else:
        out["after_project"] = np.nan
    return out[["item", "kind", "month", "qty", "after_project"]]


LISTS = {"si12", "so12", "flags", "flag_reasons"}


def for_parquet(df: pd.DataFrame) -> pd.DataFrame:
    """Parquet은 열마다 형식이 하나여야 한다: 글자 열의 빈 값은 None, 날짜 열은 날짜로."""
    out = df.copy()
    for c in out.columns:
        if c in LISTS:
            continue
        if c in ("sra", "eol", "eop", "eol_date", "proj_first_so"):
            out[c] = pd.to_datetime(out[c], errors="coerce")
        elif out[c].dtype == object:
            if out[c].map(lambda v: isinstance(v, (bool, np.bool_)) or v is None).all():
                out[c] = out[c].map(lambda v: bool(v) if v is not None else False)
            else:
                out[c] = out[c].map(lambda v: None if _nan(v) or v is pd.NaT else str(v))
    return out


def rebuild() -> str:
    entry = store.latest_entry(SOURCE)
    if not entry:
        store.write_cache(CACHE, pd.DataFrame(columns=["item"]))
        store.write_cache_meta({"version": VERSION, "settings_mtime": config.config_mtime(), "missing": True}, META)
        return "RR 파일 없음 (samples/Run Rate)"
    names = list(entry.get("rows", {}))
    tables = {n: store.load_table(SOURCE, n, entry) for n in names}
    out = run(tables, entry)
    res = for_parquet(out["result"])
    store.write_cache(CACHE, res)
    store.write_cache(MONTHS, out["months"])
    store.write_cache(CHECK, out["check"])
    store.write_cache_meta(out["meta"], META)
    v = out["meta"].get("validation")
    tail = f", 엑셀과 다 같은 아이템 {v['all_match']:,}/{v['items']:,}" if v else ""
    return f"아이템 {len(res):,}개{tail}"


# ---- 화면용: 계산 순서 (Item 상세 'RR 계산 해부') ----------------------------------------------

def steps(o: dict, p: dict) -> list[dict]:
    """판정 순서대로 규칙 조건과 참/거짓. 먼저 걸린 규칙이 확정."""
    so6 = 0.0 if _nan(o.get("so6")) else o["so6"]
    sra = not _nan(o.get("sra_years"))
    so_p = p["so_only"]
    blend_ok = bool(o["has_so"]) and so6 >= p["blend_min_so6"] and o.get("product_group") not in (p.get("si_only_groups") or [])
    checks = [
        (R_LIMITED, "PriceList Notes에 Limited Stock", o["pl_status"] == "Limited", "MIN(공식값, SI6)"),
        (R_EOL, "PriceList EOL 목록", o["pl_status"] == "EOL", "MIN(공식값, SI3, SI6)"),
        (R_ZERO, f"MAX(SI6(⑤) {o['si6_only']:.1f}, SO6 {so6:.1f}) ≤ {p['zero_max']}", max(o["si6_only"], so6) <= p["zero_max"], "0"),
        (R_MANUAL, f"SRA {o['sra_years']:.1f}년 < {p['manual_sra_years']} AND SO6 {so6:.1f} < {p['blend_min_so6']}" if sra else "SRA 없음",
         sra and o["sra_years"] < p["manual_sra_years"] and so6 < p["blend_min_so6"], "수동 RR (없으면 현행 R/R)"),
        (R_DROP, f"SI6 {o['si6']:.1f} ≥ {p['drop_min_si6']} AND SI3 {o['si3']:.1f} ≤ SI6 × {p['drop_ratio']}",
         o["si6"] >= p["drop_min_si6"] and o["si3"] <= o["si6"] * p["drop_ratio"], "MIN(공식값, SI3)"),
        (R_SO, f"SO6 ≥ {p['blend_min_so6']}, SO CV ≤ {so_p['so_cv_max']}, (SI CV ≥ {so_p['si_cv_min']} & 비율 ≥ {so_p['cv_ratio_min']} 또는 "
               f"유효월 < {so_p['min_valid_months']}), 총량비 {so_p['ratio_low']}~{so_p['ratio_high']}", bool(o.get("v41_so_only")),
         "SO6 × SO추세 × 나이 × EOP"),
        (R_BLEND, f"SO6 {so6:.1f} ≥ {p['blend_min_so6']}" + (" (RECORDER 제외)" if o.get("product_group") in (p.get("si_only_groups") or []) else ""),
         blend_ok, "(w×SO6 + (1−w)×SI6) × 추세 × 나이 × EOP"),
        (R_SI, "그 밖 (Sell-out 없음·부족, RECORDER)", True, "SI6(⑤) × 나이 × EOP"),
    ]
    out, done = [], False
    for rule, cond, hit, how in checks:
        hit = bool(hit)
        out.append({"rule": rule, "condition": cond, "hit": hit, "how": how, "applied": rule == o["rule"]})
    return out


def _n(v) -> str:
    """화면 수량: 정수 (사용자 2026-11-10)."""
    return "–" if _nan(v) else f"{xround(v):,.0f}"


def explain(o: dict, p: dict) -> str:
    """자동 설명문: 어떤 규칙으로 몇 대가 나왔는지 (수량은 정수, 계수는 소수 2자리)."""
    age = f"나이 {o['age_factor']:.2f}" + (f"(SRA {o['sra_years']:.1f}년)" if not _nan(o.get("sra_years")) else "(SRA 없음)")
    eop = f" × EOP {o['eop_factor']:.1f}(EOP까지 {o['eop_months']:.1f}개월)" if o["eop_factor"] < 1 else ""
    rule, rr = o["rule"], _n(o["proposed_rr"])
    if rule == R_BLEND:
        s = (f"⑥ 블렌드 규칙 적용. SO6 {_n(o['so6'])}, SI6 {_n(o['si6'])} → 블렌드 {_n(o['blend'])} × 추세 {o['trend']:.2f} × {age}{eop}"
             f" = {rr}대/월.")
    elif rule == R_SO:
        s = (f"⑨ SO만 규칙 적용 (Sell-in 변동성 큼: SI CV {o['si_cv']:.2f}, SO CV {o['so_cv']:.2f}). "
             f"SO6 {_n(o['so6'])} × SO추세 {o['so_trend']:.2f} × {age}{eop} = {rr}대/월.")
    elif rule == R_SI:
        why = ("RECORDER" if o.get("product_group") in (p.get("si_only_groups") or []) else
               "Sell-out 없음" if not o["has_so"] else f"SO6 {_n(o['so6'])} < {p['blend_min_so6']}")
        s = f"⑤ Sell-in만 규칙 적용 ({why}). SI6 {_n(o['si6_only'])} × {age}{eop} = {rr}대/월."
    elif rule == R_LIMITED:
        s = f"⓪ PriceList Limited: 공식값 {_n(o['formula_v42'])}과 SI6 {_n(o['si6'])} 중 작은 값 = {rr}대/월."
    elif rule == R_EOL:
        s = f"⓪ PriceList EOL: 공식값 {_n(o['formula_v42'])}, SI3 {_n(o['si3'])}, SI6 {_n(o['si6'])} 중 가장 작은 값 = {rr}대/월."
    elif rule == R_ZERO:
        so6 = 0 if _nan(o["so6"]) else o["so6"]
        s = f"③ 최근 6개월 SI6 {_n(o['si6_only'])}·SO6 {_n(so6)}이 {p['zero_max']}대 이하 → RR 0."
    elif rule == R_MANUAL:
        s = (f"⑧ SRA {o['sra_years']:.1f}년(1년 미만)·Sell-out 부족 → 수동 RR 필요 (PM 포캐스트). "
             f"수동 RR 데이터 미연결 · 현행 R/R {_n(o['rr_current'])} 임시 적용.")
    elif rule == R_DROP:
        s = (f"⑦ 급감: SI3 {_n(o['si3'])} ≤ SI6 {_n(o['si6'])} × {p['drop_ratio']} → 공식값 {_n(o['formula_v42'])} 대신 SI3 = {rr}대/월.")
    else:
        s = f"{rule}: {rr}대/월."
    if o.get("proj_qty", 0) > 0:
        s += f" 프로젝트 수량 {_n(o['proj_qty'])}대 차감 후 계산 (v4.2)."
    if not _nan(o.get("rr_current")):
        s += f" 현행 {_n(o['rr_current'])} 대비 {xround(o['delta']):+,.0f}"
        s += "" if _nan(o.get("delta_pct")) else f"({o['delta_pct']:+.0%})"
        s += (" → Δ 검토." if "delta" in list(o.get("flags") if o.get("flags") is not None else []) else ".")
    return s


WHY = {
    R_BLEND: "Sell-out(SO6)·Sell-in(SI6) 50:50 블렌드 × 추세·나이 계수",
    R_SO: "Sell-out 단독 적용 (Sell-in 변동성 과다)",
    R_SI: "Sell-in 단독 적용 (Sell-out 없음·부족 또는 RECORDER)",
    R_LIMITED: "PriceList Limited → 공식값과 SI6 중 작은 값",
    R_EOL: "PriceList EOL → 공식값·SI3·SI6 중 가장 작은 값",
    R_ZERO: "최근 6개월 판매 미미 → 0",
    R_MANUAL: "출시 1년 미만·Sell-out 부족 → 수동 RR 필요 (현재 현행값 적용)",
    R_DROP: "최근 3개월 Sell-in이 6개월 평균의 50% 이하 → SI3 적용",
}


# 화면 이름 (검증·기준값 탭)
LABELS = {
    "si12_check": "Sell-in 12개월 값", "so12_check": "Sell-out 12개월 값", "si_cap_base": "SI 12M 캡 기준", "so_cap_base": "SO 12M 캡 기준",
    "si6": "SI6 (블렌드용)", "si6_b": "SI6 (캡·음수 0)", "si6_only": "SI6 (⑤용)", "si3": "SI3", "so6": "SO6", "so3": "SO3",
    "so_flag": "SO 플래그", "blend": "블렌드", "trend": "추세계수", "so_trend": "SO 추세계수", "sra_years": "SRA 경과년",
    "age_factor": "SRA 나이계수", "eop_months": "EOP까지 (개월)", "eop_factor": "EOP 계수", "si_cv": "SI CV", "so_cv": "SO CV",
    "cv_ratio": "CV 비율", "valid_months": "유효월", "si12_avg": "SI 12M 평균", "so12_avg": "SO 12M 평균", "si_so_ratio": "SI/SO 총량비",
    "pl_status": "PL Status", "pl_notes": "PL Notes", "formula_v41": "공식값 v4.1", "rr_v3": "RR v3 (참고)",
    "rr_v4_raw": "RR v4 보정 전 (참고)", "v41_judgement": "v4.1 판정", "formula_v42": "공식값 v4.2", "rule": "적용 규칙",
    "proposed_rr": "최종 제안 RR", "delta": "Δ (제안−현행)", "delta_pct": "Δ%", "eoh_multiple": "EOH 배수", "eoh_rule": "EOH 규칙",
    "proposed_eoh": "EOH Target", "eoh_cover": "EOH 커버 (개월)", "formula_flags": "플래그 (BM)", "risk_flag": "RR 위험 플래그",
    "risk_reason": "RR 위험 근거",
}
PARAM_LABELS = {
    "blend_so_weight": "Sell-out 가중치 w", "cap_blend": "캡 k (⑥ 블렌드)", "cap_si_only": "캡 k (⑤ Sell-in만)",
    "trend_alpha": "추세 α", "trend_cap": "추세계수 상한 ±", "eop_months": "EOP 근접 기준 (개월)", "eop_factor": "EOP 감소계수",
    "zero_max": "RR 0 임계 (MAX(SI6, SO6) 이하)", "si_only_groups": "Sell-in만 제품군 (⑤)", "blend_min_so6": "블렌드 최소 SO6",
    "manual_sra_years": "⑧ SRA 기준 (년 미만)", "drop_ratio": "⑦ 급감 기준 (SI3 ÷ SI6 ≤)", "drop_min_si6": "⑦ 최소 SI6",
    "so_only.si_outlier": "⑨ SI 이상치 배수", "so_only.si_cv_min": "⑨ SI CV 기준 (≥)", "so_only.so_cv_max": "⑨ SO CV 기준 (≤)",
    "so_only.cv_ratio_min": "⑨ CV 비율 (≥)", "so_only.min_valid_months": "⑨ 최소 유효월", "so_only.ratio_low": "⑨ 총량비 하한 (≥)",
    "so_only.ratio_high": "⑨ 총량비 상한 (<)", "limited_factor": "Limited RR 계수", "review_reasons": "보정 사유 목록 (화면)", "eol_factor": "EOL RR 계수",
    "age_factors": "SRA 나이계수 [경과년 하한, 계수]", "hoarding_months.CAMERA": "사재기 제외월 CAMERA",
    "hoarding_months.PERIPHERAL": "사재기 제외월 PERIPHERAL", "eoh.base": "EOH 배수 기본", "eoh.high_cv": "EOH 배수 고변동",
    "eoh.cv_min": "EOH 고변동 CV (≥)", "eoh.eop_multiple": "EOH 배수 EOP 임박", "eoh.limited_multiple": "EOH 배수 Limited",
    "eoh.eol_multiple": "EOH 배수 EOL", "delta_review.pct": "Δ 검토 |Δ%| 초과", "delta_review.min_units": "Δ 검토 최소 대수",
    "risk.min_total": "위험 플래그 최소 12M 합", "risk.yellow_share": "🟡 한 달 비중 (≥)", "risk.red_share": "🔴 한 달 비중 (≥)",
    "risk.new_sra_years": "🔵 신규 SRA (년 미만)", "risk.early_sra_years": "🟢 초기 SRA (년 미만)",
    "risk.early_so_months": "🟢 SO 쓰는 최소 개월", "risk.early_single_month": "🟢 한 달 제외 비중 (≥)",
    "surge.ratio": "📈 급증 배수 (Claude 제안)", "surge.min_units": "📈 급증 최소 대수 (Claude 제안)",
}
