"""RR 리뷰에서 사람이 넣는 값: 보정 RR · 사유 · 리뷰 상태 (docs/run-rate.md 7장).

리뷰 상태: 미검토 → 확인(제안 RR 그대로) / 보정(현행 유지 또는 직접 입력, 사유 필수) / 보류(아직 못 정함, 보정 RR은 그대로 둠).

저장: <사람 입력 폴더>/RR Review/<이름>.jsonl. 한 줄 = 아이템 하나의 그때 값 (기준월별).
  같은 (기준월, 아이템)의 가장 최근 줄이 지금 값. 누가 고쳤든 상관없다. 지난 값은 지우지 않아 기록으로 남는다.
  사람마다 자기 파일에만 쓴다 (OneDrive 충돌 없음). 다음 기준월(새 RR 파일)은 빈 상태에서 시작한다.
  한 줄에 그때의 현행 R/R·제안 RR도 같이 남긴다 (rr_current·proposed_rr, 사용자 2026-11-11):
  다음 달 RR 파일이 오면 지난달 제안값은 화면에서 다시 볼 수 없어서, '현행 30 · 제안 40 → 보정 25'를 기록으로 남긴다.
  2026-11-11 전에 저장한 줄에는 이 두 값이 없다.
  지난 기준월의 마지막 결정은 previous()로 (RR 리뷰 패널 위 '지난 리뷰', 목록 '지난 리뷰' 열).
보정 RR은 계산값처럼 소수로 저장하고 화면에서만 정수로 보인다.
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import inputs

FOLDER = "RR Review"
NOT_YET, CHECKED, ADJUSTED, HOLD = "미검토", "확인", "보정", "보류"
STATUSES = [NOT_YET, CHECKED, ADJUSTED, HOLD]
CONTEXT = ["rr_current", "proposed_rr"]   # 저장할 때 그 SKU의 현행 R/R·제안 RR (결정 근거, 비교에는 안 씀)
COLS = ["at", "by", "basis", "item", "adj_rr", "reason", "status", *CONTEXT]


def root() -> Path:
    return inputs.folder()[0] / FOLDER


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and v != v) or (isinstance(v, str) and not v.strip())


def clean(adj_rr, reason, status) -> dict:
    """화면 값 → 저장 모양. 보정 RR을 넣었는데 상태가 미검토면 '보정'으로."""
    try:
        rr = None if _blank(adj_rr) else round(float(str(adj_rr).replace(",", "")), 4)
    except ValueError:
        rr = None
    if rr is not None and rr < 0:
        rr = 0.0
    reason = None if _blank(reason) else str(reason).strip()
    status = status if status in STATUSES else NOT_YET
    if rr is not None and status == NOT_YET:
        status = ADJUSTED
    return {"adj_rr": rr, "reason": reason, "status": status}


def load() -> pd.DataFrame:
    """모든 사람 파일의 모든 줄 (저장 시각 순)."""
    d = root()
    rows = []
    for p in sorted(d.glob("*.jsonl")) if d.is_dir() else []:
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue    # 동기화 중 반쯤 받은 줄
                if isinstance(r, dict) and r.get("item") and r.get("basis"):
                    rows.append(r)
    return pd.DataFrame(rows, columns=COLS).sort_values("at", kind="stable", ignore_index=True)


def current(basis: str) -> pd.DataFrame:
    """그 기준월의 지금 값 (아이템마다 가장 최근 줄). 열: item, adj_rr, reason, status, by, at."""
    a = load()
    a = a[a["basis"] == basis]
    cols = ["item", "adj_rr", "reason", "status", "by", "at"]
    if a.empty:
        return pd.DataFrame(columns=cols)
    last = a.groupby("item", sort=False).tail(1)[cols].reset_index(drop=True)
    last["adj_rr"] = pd.to_numeric(last["adj_rr"], errors="coerce")
    return last


def history(item: str) -> pd.DataFrame:
    a = load()
    return a[a["item"] == item].sort_values("at", ascending=False, ignore_index=True)


def previous(basis: str) -> pd.DataFrame:
    """지난 리뷰: 아이템마다 지금 기준월보다 앞선 기준월 중 가장 최근 기준월의 마지막 결정.
    열: item, basis, adj_rr, reason, status, rr_current, proposed_rr, by, at."""
    cols = ["item", "basis", "adj_rr", "reason", "status", *CONTEXT, "by", "at"]
    a = load()
    a = a[a["basis"].astype(str) < basis] if basis else a.iloc[0:0]
    if a.empty:
        return pd.DataFrame(columns=cols)
    a = a.sort_values(["basis", "at"], kind="stable")
    last = a.groupby("item", sort=False).tail(1)[cols].reset_index(drop=True)
    for c in ("adj_rr", *CONTEXT):
        last[c] = pd.to_numeric(last[c], errors="coerce")
    return last


def _num(v) -> float | None:
    try:
        return None if _blank(v) else round(float(v), 4)
    except (TypeError, ValueError):
        return None


def changes(basis: str, before: list[dict], after: list[dict]) -> list[dict]:
    """화면에 보였던 값(before)과 고친 값(after)을 비교해서 바뀐 아이템만 저장할 줄로.
    after에 rr_current·proposed_rr를 주면 같이 남긴다 (바뀌었는지 볼 때는 쓰지 않는다)."""
    now = datetime.now().isoformat(timespec="seconds")
    by = inputs.writer()
    old = {r["item"]: clean(r.get("adj_rr"), r.get("reason"), r.get("status")) for r in before}
    lines = []
    for r in after:
        v = clean(r.get("adj_rr"), r.get("reason"), r.get("status"))
        if old.get(r["item"]) == v:
            continue
        lines.append({"at": now, "by": by, "basis": basis, "item": r["item"], **v, **{k: _num(r.get(k)) for k in CONTEXT}})
    return lines


def save(basis: str, before: list[dict], after: list[dict]) -> int:
    """바뀐 아이템만 내 파일에 쓴다. 쓴 줄 수."""
    lines = changes(basis, before, after)
    if not lines:
        return 0
    d = root()
    d.mkdir(parents=True, exist_ok=True)
    path = d / inputs._file_name(inputs.writer())
    data = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in lines)
    for attempt in range(6):
        try:
            with open(path, "a", encoding="utf-8", newline="\n") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            return len(lines)
        except PermissionError:      # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    raise PermissionError(f"RR 리뷰 파일에 쓰지 못했습니다: {path}")
