"""Inbound: Sync Plan − 입고(GR)를 주차별 In-transit · Air · Vessel로 나눈다 (사용자 2026-11-06, docs/inbound.md).

  Sync Plan (MP_PSI, 화요일마다 SCM 포털에서 받음)   아이템 × 주차 × 운송수단 도착 계획. 베이스
  GR (SAP 입고 파일)                                Sync Plan 뒤에 입고된 수량 → 뺀다
  In-transit (DYN_In-transit)                       이미 출발해서 오는 중인 줄 (HVA-NORTH만). 지난 ETA = 밀려서 아직 안 온 것 → 이번 주 도착
                                                    (이번 주 = 오늘 기준. In-transit의 ETA는 처음 정한 날짜로 남아 있다, 사용자 2026-11-09)

파일은 'Inbound' 화면에서 고른다. 읽은 내용은 공유 폴더에 쌓인다 (hub/inbound_store.py).
운송수단: Priority → Air, Vestrk(베슬트럭) → Vessel (사용자).
주차별 세 칸은 겹치지 않는다. 합 = Sync − GR (이전 매크로 InboundReport와 같음):
  In-transit = 이미 출발   Air = Air 계획 − 출발분   Vessel = Vessel 계획 − 출발분
In-transit은 실제 운송수단으로 다시 나눈다 (it_air·it_vessel). 화면의 Air·Vessel 보기는 In-transit을 포함한 전체
(= 미선적 + In-transit), In-transit 보기는 주차 × Air·Vessel (사용자 2026-11-11).

화면 숫자 = DP 숫자 (사용자 2026-11-06): allocate()가 만든 줄 하나에서 주차표(화면)와 달별표(DP 입고)를 함께 만든다.
In-transit은 매일 바뀌어서 ETA가 Sync와 어긋난다. 그래도 합계는 Sync − GR로 두고, 옮겨 간 만큼 계획에서 뺀다:
  ETA가 다음 달로 밀리면 M1 입고가 줄고 M2 입고가 는다. 계획을 넘는 In-transit은 합계에 넣지 않고 알린다.

GR 적용 범위: GR Date가 Sync Plan 주차 월요일 이후인 것 전부. 새 Sync Plan이 오면 그 전 GR은 이미 반영됐다고 본다
(W45에서 11/2·11/3 GR 25개 아이템이 Sync W45 Vessel과 수량까지 같음을 확인, 2026-11-06).
Sync Plan은 그 Sync 주차부터만 본다. 지난 주차 칸은 보지 않는다 (upcoming(), 사용자 2026-11-11).
GR Status = C인 줄만 뺀다 (이전 매크로 ApplyGR).
입고된 물량은 그 컨테이너가 도착하기로 한 주차에서 뺀다 (사용자 2026-11-09, 이전 매크로와 같음. gr_targets()).
지난 주차에 남은 계획은 이번 주로 옮긴다 (이전 매크로 ApplyDelayed와 같음).

결과: cache/inbound_weekly (아이템 × 주차 세 칸), inbound_monthly (아이템 × 달 세 칸, qty = 계산 엔진 입고),
      inbound_transit (오는 중인 줄), inbound_moved (ETA·운송수단이 Sync와 달라진 수량)
"""

from collections import defaultdict
from datetime import date, datetime, timedelta

import pandas as pd

from . import config, inbound_store as IS, store

VERSION = 7  # 4: 이번 주 = 오늘 기준, GR은 그 컨테이너의 계획 주차에서. 5: 매크로와 같은 조건(BL·PO·수량)과 SCM ETA 주차 (2026-11-09)
#              6: In-transit을 실제 운송수단으로 나눈 칸 it_air·it_vessel. 7: Sync의 지난 주차 칸 제외 (2026-11-11)
NAME = "Inbound"
CACHE = "inbound_weekly"
MONTHLY = "inbound_monthly"
TRANSIT = "inbound_transit"
MOVED = "inbound_moved"
META = "inbound_meta"

AIR, VESSEL = "Air", "Vessel"
GROUP = {"AIR": AIR, "PRIORITY": AIR, "VESSEL": VESSEL, "VESTRK": VESSEL}
BUCKETS = ["in_transit", "air", "vessel"]     # 겹치지 않는 세 칸 (합 = Sync − GR = DP 입고)
SPLIT = ["it_air", "it_vessel"]                 # In-transit을 실제 운송수단(In-transit 파일 TP Mode)으로 나눈 칸. 합 = in_transit
PLAN_BUCKET = {AIR: "air", VESSEL: "vessel"}
SPLIT_OF = {AIR: "it_air", VESSEL: "it_vessel"}


def week_of(d) -> str:
    """날짜 → '202645' (월요일 시작 ISO 주차. Sync Plan 주차 열과 같다)."""
    y, w, _ = pd.Timestamp(d).isocalendar()
    return f"{y}{w:02d}"


def week_monday(week: str) -> date:
    return date.fromisocalendar(int(week[:4]), int(week[4:6]), 1)


def week_range(first: str, last: str) -> list[str]:
    """first부터 last까지 빠짐없는 주차 (수량이 0인 주차도 칸이 있어야 한다, 사용자 2026-11-09)."""
    out, d = [], week_monday(first)
    while week_of(d) <= last:
        out.append(week_of(d))
        d += timedelta(days=7)
    return out


def week_month(week: str) -> str:
    """주차의 달 = 그 주 목요일의 달 (이전 매크로, DP 주차와 같은 기준. Sync 달 열과 W45 파일 전부 일치)."""
    return (week_monday(week) + timedelta(days=3)).strftime("%Y-%m")


def upcoming(plan: pd.DataFrame, plan_week: str | None) -> pd.DataFrame:
    """Sync Plan은 그 Sync 주차(올린 주)부터 뒤로만 본다. 지난 주차 칸은 보지 않는다 (사용자 2026-11-11).
    밀린 물량은 Sync가 이번 주 뒤로 옮겨 놓는다. 지난 칸을 그대로 두면 roll()이 이번 주로 옮겨 두 번 잡힌다
    (202646 Sync의 W45 Vessel 1,738이 W46에 나왔다).
    주차 열은 '202649A'처럼 글자가 붙을 수 있다. 글자 비교로 '202649A' >= '202649'."""
    if plan is None or not len(plan) or not plan_week:
        return plan
    return plan[plan["week"].astype(str) >= str(plan_week)]


def _near(rows: list[dict], week: str) -> list[dict]:
    """계획 줄을 week에 가까운 순서로: 같은 주차, 앞선 주차(가까운 것부터, 밀리는 일이 많다), 뒤 주차."""
    day = week_monday(week)
    gap = lambda r: (week_monday(r["week"]) - day).days
    return sorted(rows, key=lambda r: (gap(r) > 0, abs(gap(r)), r["col_order"]))


FOUND_KEYS, FOUND_BL_PO = "In-transit BL·PO·수량", "In-transit BL·PO"
FOUND_SN, FOUND_CONTAINER, FOUND_SAVED, FOUND_NONE = "In-transit SN", "In-transit 컨테이너", "올릴 때 찾음", "GR 날짜"

# GR 줄과 In-transit 줄을 잇는 조건. 앞에서부터 찾는다.
# 1번은 이전 매크로 WB_Inbound의 수식과 같다 (사용자 2026-11-09): Material·House BL No·PO Number·SN Qty
#   = In-transit Item·BL No·PO No·I/T Qty. 11/3 In-transit으로 W45 입고 25줄을 이 조건으로 전부 찾았고 매크로 WEEK와 25/25 같았다.
#   SN No로는 같은 25줄을 하나도 못 찾았다 (그래서 SN·컨테이너는 뒤로).
MATCH = [
    (("item", "bl_no", "po_no", "qty"), FOUND_KEYS),
    (("item", "bl_no", "po_no"), FOUND_BL_PO),     # 일부만 입고돼 수량이 다를 때
    (("item", "sn_no"), FOUND_SN),
    (("item", "container"), FOUND_CONTAINER),
]


def _key(r: dict, cols: tuple) -> tuple | None:
    vals = []
    for c in cols:
        v = r.get(c)
        if v is None or (isinstance(v, float) and v != v) or v == "":
            return None
        vals.append(float(v) if c == "qty" else str(v))
    return tuple(vals)


def match_lines(gr: pd.DataFrame, lines: pd.DataFrame | None) -> list[tuple]:
    """GR 줄마다 (In-transit 줄 번호 또는 None, 근거)."""
    maps = [(cols, found, {}) for cols, found in MATCH]
    if lines is not None and len(lines):
        for i, r in zip(lines.index, lines.to_dict("records")):
            for cols, _, m in maps:
                k = _key(r, cols)
                if k is not None:
                    m.setdefault(k, i)
    out = []
    for r in gr.to_dict("records"):
        hit = (None, FOUND_NONE)
        for cols, found, m in maps:
            k = _key(r, cols)
            if k is not None and k in m:
                hit = (m[k], found)
                break
        out.append(hit)
    return out


def gr_targets(gr: pd.DataFrame, lines: pd.DataFrame | None) -> pd.DataFrame:
    """GR 줄마다 그 물량이 계획된 주차·운송수단(plan_week, plan_group), 근거(found), 이어진 In-transit 줄(line)을 붙인다.

    사용자 2026-11-09: 입고된 컨테이너는 가장 이른 주차가 아니라 그 컨테이너가 도착하기로 한 주차에서 뺀다 (이전 매크로와 같음).
      1. 올릴 때 찾아 둔 주차 (확인 창에서 본 그대로. 나중에 In-transit에서 그 줄이 없어져도 같다)
      2. In-transit에서 같은 줄을 찾으면 (MATCH 순서) 그 줄의 SCM ETA 주차와 TP Mode.
         CHG ETA가 아니라 SCM ETA다: 매크로 WEEK 열이 SCM ETA 주차이고, W45 입고 중 12줄은 CHG ETA가 W44였지만 Sync 계획은 W45였다
      3. 못 찾으면 GR Date 주차 (컨테이너가 있으면 Vessel, 없으면 Air. 추정)
    """
    g = gr.copy()
    for c in ("plan_week", "plan_group", "found", "sn_no", "container", "bl_no", "po_no"):
        if c not in g:
            g[c] = None
    out = []
    for r, (line, found) in zip(g.to_dict("records"), match_lines(g, lines)):
        r["line"] = line
        if pd.isna(r["plan_week"]) or not r["plan_week"]:
            if line is not None:
                hit = lines.loc[line]
                r.update(plan_week=hit["scm_week"], plan_group=hit["group"], found=found)
            else:
                r.update(plan_week=week_of(r["gr_date"]), plan_group=VESSEL if r["container"] else AIR, found=FOUND_NONE)
        elif not r["found"]:
            r["found"] = FOUND_SAVED
        out.append(r)
    return pd.DataFrame(out, columns=list(g.columns) + ["line"])


def subtract_gr(plan: pd.DataFrame, gr: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """계획에서 입고를 뺀다 (gr = gr_targets 결과). (뺀 뒤 계획, 계획보다 많이 들어온 수량 [item, qty]).
    그 주차·운송수단에서 먼저, 모자라면 가까운 주차(앞선 주차부터), 그다음 다른 운송수단."""
    left = plan.copy()
    left["qty"] = left["qty"].astype(float)
    if not len(gr):
        return left, pd.DataFrame(columns=["item", "qty"])
    rows = [dict(r, _i=i) for i, r in zip(left.index, left.to_dict("records"))]
    by_item = defaultdict(list)
    for r in rows:
        by_item[r["item"]].append(r)
    over = []
    for g in gr.sort_values("plan_week").to_dict("records"):
        need = float(g["qty"])
        mine = by_item[g["item"]]
        for r in (_near([r for r in mine if r["group"] == g["plan_group"]], g["plan_week"])
                  + _near([r for r in mine if r["group"] != g["plan_group"]], g["plan_week"])):
            take = min(need, r["qty"])
            r["qty"] -= take
            need -= take
            if need <= 0:
                break
        if need > 0:
            over.append({"item": g["item"], "qty": need})
    left["qty"] = pd.Series({r["_i"]: r["qty"] for r in rows}).reindex(left.index).astype(float)
    over = pd.DataFrame(over, columns=["item", "qty"]).groupby("item", as_index=False)["qty"].sum()
    return left, over


def received(lines: pd.DataFrame, gr: pd.DataFrame) -> pd.DataFrame:
    """이미 입고된 줄을 In-transit에서 뺀다 (gr = gr_targets 결과의 line).
    In-transit 파일이 GR보다 오래돼 그 줄이 남아 있어도 두 번 잡히지 않게."""
    if not len(lines) or not len(gr) or "line" not in gr:
        return lines
    t = lines.copy()
    t["qty"] = t["qty"].astype(float)
    for i, q in zip(gr["line"], gr["qty"]):
        if i is not None and not (isinstance(i, float) and i != i) and i in t.index:
            t.at[i, "qty"] -= min(float(q), t.at[i, "qty"])
    return t[t["qty"] > 0]


def roll(left: pd.DataFrame, this_week: str) -> pd.DataFrame:
    """지난 주차에 남은 계획(아직 안 들어온 것)은 이번 주로 옮긴다 (이전 매크로 ApplyDelayed와 같음).
    다음 화요일 Sync Plan이 오면 Sync가 다시 잡는다."""
    left = left.copy()
    past = left["week"] < this_week
    left.loc[past, "month"] = week_month(this_week)
    left.loc[past, "week"] = this_week
    return left


LINE_COLUMNS = ["item", "mode", "sn_no", "container", "bl_no", "po_no", "qty", "eta", "eta_week", "scm_week", "week",
                "overdue", "month", "group"]


def transit_weeks(transit: pd.DataFrame, this_week: str) -> pd.DataFrame:
    """오는 중인 줄에 도착 주차·달을 붙인다. ETA = SN ETA → CHG ETA → SCM ETA.
    ETA가 이번 주(오늘 기준)보다 앞이면 밀려서 아직 안 온 것 → 이번 주 도착 (사용자 2026-11-06, 11-09)."""
    if transit is None or not len(transit):
        return pd.DataFrame(columns=LINE_COLUMNS)
    t = transit.copy()
    t["eta"] = t["sn_eta"].fillna(t["chg_eta"]).fillna(t["scm_eta"])
    t["eta_week"] = t["eta"].map(lambda d: week_of(d) if pd.notna(d) else this_week)
    t["scm_week"] = t["scm_eta"].map(lambda d: week_of(d) if pd.notna(d) else None).fillna(t["eta_week"])   # GR이 빠질 주차
    t["week"] = t["eta_week"].where(t["eta_week"] >= this_week, this_week)
    t["overdue"] = t["eta_week"] < this_week
    t["month"] = t["eta"].dt.strftime("%Y-%m").where(t["eta_week"] >= this_week, week_month(this_week))
    t["group"] = t["mode"].map(GROUP)
    return t


def allocate(left: pd.DataFrame, lines: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """뺀 뒤 계획과 오는 중인 줄을 겹치지 않게 맞춘다. 결과의 합 = 뺀 뒤 계획 (Sync − GR이 전체라는 규칙).

    (parts [item, week, month, bucket, qty], moved [Sync와 달라진 수량], over [계획을 넘는 In-transit]).
    출발한 줄이 계획의 어디를 쓰는지 (ETA·TP Mode가 Sync 뒤에 바뀌는 경우는 추정, docs/inbound.md):
      1. 같은 주차·같은 운송수단   2. 같은 운송수단의 다른 주차   3. 다른 운송수단
      다른 주차는 앞선 주차부터 가까운 순서로 쓴다 (ETA는 밀리는 일이 많다. 그 뒤에 뒤 주차를 가까운 순서로).
    남은 계획은 아직 안 떠난 Air·Vessel이다.
    """
    rows = left[left["qty"] > 0].sort_values("col_order").to_dict("records")
    by_item = defaultdict(list)
    for r in rows:
        by_item[r["item"]].append(r)
    parts, moved = [], []

    def use(t: dict, plan_rows: list[dict]) -> None:
        for r in plan_rows:
            q = min(t["need"], r["qty"])
            if q <= 0:
                continue
            r["qty"] -= q
            t["need"] -= q
            same_week = r["week"] == t["week"]
            group = t["group"] if isinstance(t["group"], str) else r["group"]     # 운송수단을 모르면 계획의 운송수단
            parts.append({"item": t["item"], "week": t["week"], "month": r["month"] if same_week else t["month"],
                          "bucket": "in_transit", "group": group, "qty": q})
            if not same_week or r["group"] != t["group"]:
                moved.append({"item": t["item"], "qty": q, "plan_week": r["week"], "week": t["week"],
                              "plan_month": r["month"], "month": r["month"] if same_week else t["month"],
                              "plan_group": r["group"], "group": t["group"]})

    near = lambda t, plan_rows: _near(plan_rows, t["week"])

    todo = [{**t, "need": t["qty"]} for t in lines.sort_values("week").to_dict("records")]
    for t in todo:
        use(t, [r for r in by_item[t["item"]] if r["group"] == t["group"] and r["week"] == t["week"]])
    for t in todo:
        use(t, near(t, [r for r in by_item[t["item"]] if r["group"] == t["group"]]))
    for t in todo:
        use(t, near(t, by_item[t["item"]]))
    parts += [{"item": r["item"], "week": r["week"], "month": r["month"], "bucket": PLAN_BUCKET[r["group"]], "group": r["group"],
               "qty": r["qty"]} for r in rows if r["qty"] > 0]
    over = pd.DataFrame([{"item": t["item"], "week": t["week"], "group": t["group"], "qty": t["need"]}
                         for t in todo if t["need"] > 0], columns=["item", "week", "group", "qty"])
    moved = pd.DataFrame(moved, columns=["item", "qty", "plan_week", "week", "plan_month", "month", "plan_group", "group"])
    return pd.DataFrame(parts, columns=["item", "week", "month", "bucket", "group", "qty"]), moved, over


def spread(parts: pd.DataFrame, by: str) -> pd.DataFrame:
    """allocate 결과를 아이템 × 주차(또는 달) 세 칸으로 편다. 열: item, by, in_transit, air, vessel, it_air, it_vessel, total.
    it_air·it_vessel = In-transit을 실제 운송수단으로 나눈 것 (화면 'In-transit' 보기, Air·Vessel 전체 = 미선적 + In-transit)."""
    t = parts.pivot_table(index=["item", by], columns="bucket", values="qty", aggfunc="sum", fill_value=0)
    t = t.reindex(columns=BUCKETS, fill_value=0)
    it = parts[parts["bucket"] == "in_transit"].assign(split=lambda d: d["group"].map(SPLIT_OF))
    s = it.pivot_table(index=["item", by], columns="split", values="qty", aggfunc="sum", fill_value=0) if len(it) else None
    for c in SPLIT:
        t[c] = s[c].reindex(t.index, fill_value=0) if s is not None and c in s.columns else 0
    t["total"] = t[BUCKETS].sum(axis=1)
    t.columns.name = None
    return t[t["total"] > 0].reset_index()


def after_plan(gr: pd.DataFrame, plan_week: str) -> pd.DataFrame:
    """Sync Plan 주차 월요일 이후 입고만. 그 전 입고는 Sync Plan에 이미 반영됐다고 본다."""
    return gr[gr["gr_date"] >= pd.Timestamp(week_monday(plan_week))] if len(gr) else gr


def build(plan: pd.DataFrame, transit: pd.DataFrame | None, this_week: str, gr: pd.DataFrame) -> dict:
    """Sync Plan(readers.sync_plan의 표) − 입고, In-transit으로 나누기. 화면과 DP가 쓰는 표를 한 번에 만든다.
    순서: 입고를 그 계획 주차에서 뺀다 → 입고된 줄을 In-transit에서 뺀다 → 지난 주차 계획을 이번 주로 → 세 칸 나누기."""
    lines = transit_weeks(transit, this_week)
    gr = gr_targets(gr, lines) if len(gr) else gr
    left, gr_over = subtract_gr(plan.assign(group=plan["mode"].map(GROUP)), gr)
    lines = received(lines, gr)
    parts, moved, over = allocate(roll(left, this_week), lines)
    return {"weekly": spread(parts, "week"), "monthly": spread(parts, "month").rename(columns={"total": "qty"}),
            "transit": lines, "moved": moved, "transit_over": over, "gr_over": gr_over, "gr": gr}


def rebuild() -> str:
    pm, raw = IS.latest(IS.SYNC)
    if raw is None:
        # 빈 표를 남긴다 (표가 없으면 켤 때마다 다시 만든다). 달별 표가 없으면 계산은 DP 파일 입고를 쓴다
        store.write_cache(CACHE, pd.DataFrame(columns=["item", "week"] + BUCKETS + SPLIT + ["total"]))
        for name in (MONTHLY, TRANSIT, MOVED):
            store.cache_path(name).unlink(missing_ok=True)
        store.write_cache_meta({"version": VERSION, "settings_mtime": config.config_mtime(),
                                "signature": IS.signature()}, META)
        return "Sync Plan 미업로드 ('Inbound' 화면)"

    plan = upcoming(raw, pm["plan_week"])
    since = week_monday(pm["plan_week"]).isoformat()
    batches = IS.gr_batches(since)
    frames = [df for _, df in batches if len(df)]
    gr = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["item", "qty", "gr_date", "container"])
    if len(gr):   # 둘이 같은 GR을 동시에 올려도 한 번만 뺀다
        gr = after_plan(gr.drop_duplicates(["gr_doc", "gr_item"]), pm["plan_week"])
    tm, transit = IS.latest(IS.TRANSIT)
    this_week = week_of(config.today())
    t = build(plan, transit, this_week, gr)
    cells = t["weekly"]

    store.write_cache(CACHE, cells)
    store.write_cache(MONTHLY, t["monthly"])
    store.write_cache(TRANSIT, t["transit"])
    store.write_cache(MOVED, t["moved"])
    meta = {
        "version": VERSION, "settings_mtime": config.config_mtime(),
        "built_at": datetime.now().isoformat(timespec="seconds"),
        "plan_file": pm.get("file"), "plan_version": pm.get("plan_version"), "plan_week": pm["plan_week"],
        "plan_by": pm.get("by"), "plan_at": pm.get("at"),
        "transit_file": tm.get("file"), "transit_date": tm.get("file_date"), "transit_week": this_week, "this_week": this_week,
        "transit_by": tm.get("by"), "transit_at": tm.get("at"),
        "gr_since": since, "gr_total": float(pd.to_numeric(gr["qty"]).sum()) if len(gr) else 0.0,
        "gr_last": gr["gr_date"].max().strftime("%Y-%m-%d") if len(gr) else None,
        "gr_batches": [{k: m.get(k) for k in ("path", "by", "at", "files", "sn", "qty", "gr_dates", "weeks")} for m, _ in batches],
        "gr_over": t["gr_over"].to_dict("records"), "transit_over": float(t["transit_over"]["qty"].sum()),
        "transit_over_items": t["transit_over"].to_dict("records"), "transit_moved": float(t["moved"]["qty"].sum()),
        "plan_total": float(plan["qty"].sum()), "weeks": sorted(cells["week"].unique()), "signature": IS.signature(),
    }
    store.write_cache_meta(meta, META)
    return (f"Sync {pm.get('plan_version')} · 입고 뺌 {meta['gr_total']:,.0f} · In-transit {cells['in_transit'].sum():,.0f} · "
            f"Air {cells['air'].sum():,.0f} · Vessel {cells['vessel'].sum():,.0f}")


def stale(meta: dict) -> bool:
    """공유 폴더의 Inbound 파일이 바뀌거나 (다른 사람이 올린 것이 동기화돼도) 주가 바뀌면 다시 만든다
    (월요일이 되면 지난 주 ETA가 이번 주로 옮겨 가야 한다)."""
    if meta.get("plan_version") and meta.get("this_week") != week_of(config.today()):
        return True
    return meta.get("signature") != IS.signature()


# ---- 지난 Sync와 비교 ----------------------------------------------------------

GREW, SHRANK, NEW, GONE, WEEK_ONLY, MODE_ONLY = "증가", "감소", "신규", "삭제", "주차 변경", "운송수단 변경"
KINDS = [GREW, SHRANK, NEW, GONE, WEEK_ONLY, MODE_ONLY]


def compare(old: pd.DataFrame, new: pd.DataFrame, new_week: str, gr: pd.DataFrame, old_week: str | None = None) -> dict:
    """지난 Sync와 이번 Sync를 같은 시점(이번 Sync 주차 월요일)의 '앞으로 올 수량'으로 맞춰 비교한다.

    지난 Sync는 그 사이 입고(gr)를 빼고, 이번 주차보다 앞선 주차에 남은 수량은 이번 주차로 옮긴다
    (안 그러면 지난 주에 들어온 물량이 전부 '감소'로 나온다).
    두 Sync 모두 그 Sync 주차부터만 본다 (upcoming).
    결과: items [item, old, new, delta, kind, change], months [item, month, old, new, delta]
    """
    old, new = upcoming(old, old_week), upcoming(new, new_week)
    left, _ = subtract_gr(old.assign(group=old["mode"].map(GROUP)), gr_targets(gr, None) if len(gr) else gr)
    left = left[left["qty"] > 0].copy()
    past = left["week"] < new_week
    left.loc[past, "month"] = week_month(new_week)
    left.loc[past, "week"] = new_week
    now = new.assign(group=new["mode"].map(GROUP))

    def both(keys: list[str]) -> pd.DataFrame:
        t = pd.concat({"old": left.groupby(keys)["qty"].sum(), "new": now.groupby(keys)["qty"].sum()}, axis=1).fillna(0)
        t["delta"] = t["new"] - t["old"]
        return t

    def text(t: pd.DataFrame, name) -> pd.Series:
        t = t[t["delta"].abs() >= 0.5].reset_index().sort_values(["item", t.index.names[1]])
        if t.empty:
            return pd.Series(dtype="object")
        words = t[t.columns[1]].map(name) + " " + t["delta"].map("{:+,.0f}".format)
        return words.groupby(t["item"]).agg(" · ".join)

    by_week, by_mode, items = both(["item", "week"]), both(["item", "group"]), both(["item"])
    week_text, mode_text = text(by_week, lambda w: f"W{w[-2:]}"), text(by_mode, str)
    items["kind"] = None
    items.loc[items["delta"] > 0, "kind"] = GREW
    items.loc[items["delta"] < 0, "kind"] = SHRANK
    items.loc[items["old"] == 0, "kind"] = NEW
    items.loc[items["new"] == 0, "kind"] = GONE
    same = items["delta"] == 0
    items.loc[same & items.index.isin(mode_text.index), "kind"] = MODE_ONLY
    items.loc[same & items.index.isin(week_text.index), "kind"] = WEEK_ONLY
    items["change"] = week_text.reindex(items.index).fillna("")
    only_mode = items["kind"] == MODE_ONLY
    items.loc[only_mode, "change"] = mode_text.reindex(items.index[only_mode]).fillna("")
    items = items[items["kind"].notna()].reset_index()
    items = items.sort_values("delta", key=lambda d: d.abs(), ascending=False, ignore_index=True)
    return {"items": items, "months": both(["item", "month"]).reset_index()}
