"""Inbound 저장소: 'Inbound' 화면에서 고른 Sync Plan·In-transit·GR을 공유 폴더에 쌓는다 (docs/inbound.md).

위치: <사람 입력 폴더>/Inbound/<Sync Plan|In-transit|GR>/<올린 시각> <이름>.jsonl
  첫 줄 = {"_meta": {...}} (원본 파일 이름, 올린 사람·시각, 계획 버전 등), 다음 줄부터 표 한 줄씩

엑셀을 그대로 두지 않고 읽은 내용을 저장한다:
  - 프로젝트 폴더에 파일을 넣지 않아도 되고, 한 사람이 올리면 OneDrive로 팀원 PC에도 같은 Inbound가 보인다
  - 엑셀은 DRM이 다시 잠글 수 있는데, 텍스트 파일은 이 폴더에서 잠긴 적이 없다 (2026-10-28 확인)
  - 올린 시각이 파일 이름이라 서로 다른 파일이다 → 둘이 동시에 올려도 충돌하지 않는다. 지난 Sync Plan도 남는다

Sync Plan·In-transit은 가장 최근에 올린 것 하나를 쓴다. GR은 올릴 때마다 쌓이고, 잘못 뺐으면 취소 줄을 남긴다.
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

from . import inputs

SYNC, TRANSIT, GR = "sync_plan", "in_transit", "gr"
FOLDER = {SYNC: "Sync Plan", TRANSIT: "In-transit", GR: "GR"}
DATES = {SYNC: [], TRANSIT: ["ship_date", "scm_eta", "chg_eta", "sn_eta"], GR: ["gr_date"]}


def root() -> Path:
    override = os.environ.get("HVA_HUB_INBOUND_DIR")   # 테스트: 공유 폴더와 상관없이 늘 같은 Inbound로 돌린다
    return Path(override) if override else inputs.folder()[0] / "Inbound"


def folder(kind: str) -> Path:
    return root() / FOLDER[kind]


def _plain(v):
    if v is None or v is pd.NaT or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, (pd.Timestamp, datetime)):
        return v.isoformat()
    return v.item() if hasattr(v, "item") else v


def save(kind: str, table: pd.DataFrame, meta: dict) -> Path:
    """표 하나를 새 파일로 쓴다. 다 쓴 뒤 이름을 바꿔서 반쯤 쓴 파일이 동기화되지 않게 한다."""
    d = folder(kind)
    d.mkdir(parents=True, exist_ok=True)
    now = datetime.now()
    by = inputs.writer()
    head = {**meta, "kind": kind, "by": by, "at": now.isoformat(timespec="seconds"), "rows": int(len(table))}
    path = d / inputs._file_name(f"{now:%Y%m%d-%H%M%S}-{now.microsecond // 1000:03d} {by}")
    lines = [json.dumps({"_meta": head}, ensure_ascii=False)]
    lines += [json.dumps({k: _plain(v) for k, v in row.items()}, ensure_ascii=False) for row in table.to_dict("records")]
    tmp = path.with_suffix(".tmp")
    tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for attempt in range(6):
        try:
            os.replace(tmp, path)
            break
        except PermissionError:   # OneDrive가 올리는 중이면 잠깐 잠길 수 있다
            time.sleep(0.5 * (attempt + 1))
    else:
        raise PermissionError(f"Inbound 파일을 쓰지 못했습니다: {path}")
    _memo.clear()
    return path


_memo: dict = {}


def read(path: Path) -> tuple[dict, pd.DataFrame]:
    """(설명, 표). 파일이 바뀌지 않았으면 다시 읽지 않는다."""
    st = path.stat()
    key = (st.st_mtime, st.st_size)
    hit = _memo.get(path)
    if hit and hit[0] == key:
        return hit[1], hit[2]
    meta, rows = {}, []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue   # 동기화 중 반쯤 받은 줄
            if "_meta" in r:
                meta = r["_meta"]
            else:
                rows.append(r)
    df = pd.DataFrame(rows)
    for c in DATES.get(meta.get("kind"), []):
        if c in df:
            df[c] = pd.to_datetime(df[c], errors="coerce")
    meta["path"] = path.name
    _memo[path] = (key, meta, df)
    return meta, df


def listing(kind: str) -> list[Path]:
    """올린 파일, 최근 것부터 (파일 이름이 올린 시각)."""
    d = folder(kind)
    return sorted(d.glob("*.jsonl"), key=lambda p: p.name, reverse=True) if d.is_dir() else []


def sync_plans(n: int = 2, recent: int = 8) -> list[tuple[dict, pd.DataFrame]]:
    """계획 버전이 높은 순 (지난 버전을 나중에 올려도 순서가 맞다). 최근에 올린 몇 개만 연다."""
    got = [g for g in (read(p) for p in listing(SYNC)[:recent]) if g[0]]
    return sorted(got, key=lambda g: (g[0].get("plan_version") or "", g[0]["path"]), reverse=True)[:n]


def latest(kind: str) -> tuple[dict, pd.DataFrame | None]:
    """지금 쓰는 것 (설명, 표). Sync Plan은 가장 높은 버전, 나머지는 가장 최근에 올린 것. 없으면 ({}, None)."""
    if kind == SYNC:
        got = sync_plans(1)
        return got[0] if got else ({}, None)
    for p in listing(kind):
        meta, df = read(p)
        if meta:
            return meta, df
    return {}, None


def gr_batches(since: str | None = None) -> list[tuple[dict, pd.DataFrame]]:
    """뺀 입고 묶음 (최근 것부터). 취소한 묶음은 빠진다. since = 'YYYY-MM-DD' 이후에 올린 것만."""
    items = [read(p) for p in listing(GR) if since is None or p.name[:8] >= since.replace("-", "")]
    cancelled = {m["cancel"] for m, _ in items if m.get("cancel")}
    return [(m, df) for m, df in items if not m.get("cancel") and m.get("path") not in cancelled]


def cancel_gr(name: str, memo: str = "") -> Path:
    """뺀 입고 묶음을 취소한다 (파일을 지우지 않고 취소 줄을 남긴다)."""
    return save(GR, pd.DataFrame(), {"cancel": name, "memo": memo})


def signature() -> list:
    """저장된 파일 목록. 바뀌면 Inbound를 다시 만든다 (다른 사람이 올린 것이 동기화돼도)."""
    out = []
    for kind in FOLDER:
        for p in listing(kind):
            try:
                out.append([kind, p.name, p.stat().st_size])
            except OSError:
                continue
    return out
