"""계산 엔진: DP 파일 DP Table의 수식을 Python으로 옮긴 것 (docs/dp-engine.md).

같은 입력이면 DP 파일과 모든 아이템이 같은 값이어야 한다 (tests/test_engine.py로 확인).
DP_W42_v07 수식 기준으로 옮긴 것 (2026-10-28):
  BOM 전개 (8. DP Material)   총 RR = 단품 RR + Σ(BOM 헤더 RR × Qty). EOH도 같다
  R/R·EOH (DP Table L·N)     8. DP Material 총 값. 단 R/R은 Setting S열 목록에 있는 아이템만 (없으면 0)
  ADI 보정 (M)               ADI 재고일수가 적정일수(60일)보다 많으면 월 수요에서 뺀다 (Setting I44:I49)
  입고 (O~S)                 3. Inbound의 월별 합계(T 칸)
  월별 수요·이월 (T~AB), 자원점검 (X)
  남은 근무일 비율 (AF1), DP 개월 수 (Setting B2), 기준 목요일 (Setting B9)

전환 기간 (사용자 결정 2026-10-28): R/R·EOH는 DP 파일 숫자를 그대로 쓴다. 사람이 대시보드에서 R/R·EOH를
고치면(hub/inputs.py) 그 값으로 자원점검까지 다시 계산한다. 계산 결과도 사람이 바꾼다: M1~M4 DP 값(그 달 값을 바꿈,
DP Table 수동입력 열과 같다)과 자원점검(더하거나 뺌, 추가 오더·줄임). RR·EOH 계산 로직은 다음 단계.

주차는 날짜로 정한다 (사용자 2026-11-03): 오늘이 속한 주의 목요일이 이번 DP 주차 (calendar()).
계산하는 아이템은 Base Item 전부다 (사용자 2026-11-06). DP 파일에 없는 아이템은 R/R·EOH 0으로 계산한다.
입고는 Sync Plan − GR (hub/inbound.py). DP 파일은 R/R·EOH(월 RR 세팅)·Setting 값을 주는 곳이고 매주 넣지 않아도 된다.

입력은 두 가지 (mode):
  latest   Base Item 전부. 재고·주문·ADI = 가장 최근 파일, 입고 = Sync − GR, 주차·근무일 비율 = 오늘. (화면 기본)
  dp_file  DP Table 아이템. DP 파일에 붙여 넣은 그 주 데이터·입고, 파일의 주차·근무일 비율 → DP Table과 같은 숫자 (대조용)
결과: cache/dp_inputs.parquet (아이템별 입력), dp_inputs_meta.json. 계산은 plan()이 그때그때 한다 (1,400행, 빠름).
"""

from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd

from . import base_items, config, flow, inbound, inputs, inventory, store

VERSION = 3  # 2: 주차·기간은 날짜로, 입고는 모든 달 (2026-11-03), 3: Base Item 행, 입고 Sync − GR (2026-11-06)
NAME = "DP 계산 입력"
CACHE = "dp_inputs"
META = "dp_inputs_meta"

MAX_MONTHS = 4          # DP Table은 M1~M4까지 (기준 목요일 + 10주가 속한 달까지라 3 또는 4)
INBOUND_MONTHS = 5      # 입고는 M1~M5 (화면 참고용, 계산은 M4까지)

# mode별로 바뀌는 입력 (latest = 이 이름, dp_file = 'dpf_' + 이름)
DATA_INPUTS = ["gi", "hva_inv", "open_so", "open_do", "adi_inv", "adi_iv", "adi_us"]
LATEST, DP_FILE = "latest", "dp_file"
MODE_LABEL = {LATEST: "최신 파일 (오늘 기준)", DP_FILE: "DP 파일에 넣은 데이터 그대로"}


# ---- 날짜 -----------------------------------------------------------------

def base_thursday(week: int, today: date) -> date:
    """Setting B9: DP 주차의 목요일. 연도는 오늘 기준 (40주 이후인데 1~2월이면 작년, 10주 이전인데 11~12월이면 내년)."""
    year = today.year
    if week >= 40 and today.month <= 2:
        year -= 1
    elif week <= 10 and today.month >= 11:
        year += 1
    jan4 = date(year, 1, 4)
    return jan4 - timedelta(days=jan4.weekday()) + timedelta(days=7 * (week - 1) + 3)


def dp_months(base: date) -> int:
    """Setting B2: 기준 목요일 + 10주(SOP 3주 + Vessel 7주)가 속한 달까지 몇 달인가 (3 또는 4)."""
    end = base + timedelta(days=70)
    return (end.year - base.year) * 12 + end.month - base.month + 1


def month_keys(base: date, n: int) -> list[str]:
    """M1(기준 목요일이 속한 달)부터 n개월: ['2026-10', '2026-11', ...]"""
    out = []
    y, m = base.year, base.month
    for _ in range(n):
        out.append(f"{y}-{m:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def month_label(key: str) -> str:
    return datetime.strptime(key, "%Y-%m").strftime("%b")


def workday_ratio(today: date, holidays: list[date]) -> float:
    """DP Table AF1: 오늘~월말 근무일 ÷ 이번 달 전체 근무일 (Excel NETWORKDAYS, 근무일에서 빼는 공휴일만)."""
    first = today.replace(day=1)
    nxt = (first + timedelta(days=32)).replace(day=1)
    h = np.array(holidays, dtype="datetime64[D]")
    total = np.busday_count(first, nxt, holidays=h)
    left = np.busday_count(today, nxt, holidays=h)
    return float(left / total) if total else 0.0


def holidays_off(settings: dict) -> list[date]:
    return [date.fromisoformat(d) for d, off in settings.get("holidays", []) if off]


def this_thursday(today: date) -> date:
    """오늘이 속한 주(월~일)의 목요일 = 이번 DP 주차의 기준일 (사용자 2026-11-03: 11/3 화 → 11/5 목, W45)."""
    return today - timedelta(days=today.weekday()) + timedelta(days=3)


def week_name(base: date) -> str:
    """'2026-W45' (기준 목요일의 ISO 연도·주차). 사람 입력·확정 기록이 이 이름으로 주차를 가른다."""
    y, w, _ = base.isocalendar()
    return f"{y}-W{w:02d}"


def current_week(today: date | None = None) -> str:
    return week_name(this_thursday(today or config.today()))


def calendar(meta: dict, mode: str = LATEST, today: date | None = None) -> dict:
    """이번 DP의 주차·기간·남은 근무일 비율.

    latest   오늘이 속한 주의 목요일로 정한다 (DP 파일과 상관없이 날짜만으로, 사용자 2026-11-03).
             남은 근무일 비율은 M1 달 기준: 오늘이 M1 달이면 오늘~월말, M1 달 전이면 1, 지났으면 0
             (DP 파일 AF1은 늘 TODAY() 기준이라 목·금 DP 날에는 같다. 다른 요일 미리보기만 다름, Claude 결정)
    dp_file  DP 파일 Setting의 기준 목요일(B9)과 파일에 저장된 비율(AF1) → DP Table과 대조"""
    today = today or config.today()
    if mode == DP_FILE:
        base = (date.fromisoformat(meta["file_base_date"]) if meta.get("file_base_date")
                else base_thursday(int(meta["dp_week"]), today))
    else:
        base = this_thursday(today)
    months = dp_months(base)
    keys = month_keys(base, INBOUND_MONTHS)
    if mode == DP_FILE and meta.get("file_workday_ratio") is not None:
        ratio = float(meta["file_workday_ratio"])
    else:
        m1 = today.strftime("%Y-%m")
        ratio = (workday_ratio(today, [date.fromisoformat(d) for d in meta.get("holidays_off", [])]) if m1 == keys[0]
                 else 1.0 if m1 < keys[0] else 0.0)
    return {"mode": mode, "today": today.isoformat(), "base_date": base.isoformat(), "dp_week": base.isocalendar()[1],
            "week": week_name(base), "dp_days": [base.isoformat(), (base + timedelta(days=1)).isoformat()],
            "months": months, "month_keys": keys, "workday_ratio": ratio}


# ---- 계산 -----------------------------------------------------------------

def excel_round(x, digits: int = 0):
    """Excel ROUND (0.5는 0에서 먼 쪽으로). Python round는 짝수 쪽이라 다르다."""
    f = 10 ** digits
    return np.sign(x) * np.floor(np.abs(x) * f + 0.5 + 1e-9) / f


def bom_links(pos_master: pd.DataFrame) -> pd.DataFrame:
    """8. DP Material O:Q: POS Master에서 구분 = BOM이고 헤더 ≠ 구성품인 (헤더, 구성품, Qty). 같은 줄은 한 번만."""
    m = pos_master[(pos_master["kind"] == "BOM") & pos_master["dp_material"].notna()
                   & (pos_master["po_sku"] != pos_master["dp_material"])]
    out = m[["po_sku", "dp_material", "qty"]].rename(columns={"po_sku": "header", "dp_material": "component"})
    return out.drop_duplicates().sort_values(["header", "component"]).reset_index(drop=True)


def bom_contribution(own: pd.Series, links: pd.DataFrame) -> pd.Series:
    """8. DP Material G·J: 구성품별 Σ(헤더 값 × Qty). own = 아이템 → 단품 값 (헤더 포함)."""
    v = links["header"].map(own).fillna(0) * links["qty"].fillna(0)
    return v.groupby(links["component"]).sum()


def dp_items(dp_list: pd.DataFrame, pos_master: pd.DataFrame, prefixes: list[str]) -> list[str]:
    """8. DP Material A열 = DP Table 아이템: DP list에서 BOM 헤더와 제외 접두어를 뺀 것 + DP list에 없는 BOM 구성품."""
    headers = set(pos_master.loc[pos_master["kind"] == "BOM", "po_sku"].dropna())
    excluded = lambda s: any(s.startswith(p) for p in prefixes)
    listed = sorted(i for i in dp_list["item"].dropna() if i not in headers and not excluded(i))
    links = bom_links(pos_master)
    extra = [c for c in links["component"].drop_duplicates() if not excluded(c) and c not in set(listed)]
    return listed + extra


def adi_stats(detail: pd.DataFrame) -> pd.DataFrame:
    """ADI 보정에 쓰는 아이템별 ADI 재고(iv)와 월 Sell-out(us).
    detail = flow.adi_by_item의 상세 (수량은 이미 POS 1개당 Qty를 곱함).
    iv = Σ Total Inv Qty,  us = Σ (Total Inv Qty ÷ DOS) × 30  (DOS가 없거나 0이면 0, Excel IFERROR)"""
    d = detail[["item", "total_qty", "dos"]].copy()
    d["total_qty"] = d["total_qty"].fillna(0)
    dos = pd.to_numeric(d["dos"], errors="coerce")
    d["daily"] = (d["total_qty"] / dos).where(dos.notna() & (dos != 0), 0.0)
    g = d.groupby("item").agg(adi_iv=("total_qty", "sum"), adi_us=("daily", "sum"))
    g["adi_us"] = g["adi_us"] * 30
    return g


def adi_adjust(rr: pd.Series, iv: pd.Series, us: pd.Series, p: dict, digits: int = 1) -> pd.Series:
    """DP Table M: 보정 = (적정일수 − ADI 재고일수) ÷ 30 × 월 Sell-out ÷ 분산 개월, RR × ±상한 안으로, 소수 1자리
    (DP 파일). 대시보드 수량 계산은 digits=0 (정수). '차감만'이면 마이너스(ADI 과잉)만 쓴다.
    ADI 재고·Sell-out·RR 중 하나라도 0 이하면 0."""
    if not p.get("on"):
        return pd.Series(0.0, index=rr.index)
    rr, iv, us = rr.fillna(0), iv.fillna(0), us.fillna(0)
    ok = (iv > 0) & (us > 0) & (rr > 0)
    safe_us = us.where(us > 0, 1.0)
    raw = (p["target_days"] - iv / safe_us * 30) / 30 * safe_us / p["spread_months"]
    capped = np.minimum(p["cap"] * rr, raw)
    capped = np.maximum(-p["cap"] * rr, capped)
    aj = excel_round(capped, digits)
    if p.get("direction") == "차감만":
        aj = np.minimum(aj, 0)
    return pd.Series(np.where(ok, aj, 0.0), index=rr.index)


def monthly(t: pd.DataFrame, months: int, ratio: float, whole: bool = False) -> pd.DataFrame:
    """DP Table T~AB, X. t 열: gi, hva_inv, open_so, open_do, rr, adi_adjust, eoh, inbound_m1~m4, manual_m1~m4.
    whole=True면 M1의 'RR × 남은 근무일 비율'을 반올림한다 → 입력이 정수면 모든 결과가 정수 (수량, 사용자 2026-11-04).

    M1 수요 = MIN( MAX(RR × 남은 근무일 비율 + ADI보정, 0) + GI + SO + DO ,  GI + HVA재고 + M1입고 )
    M1 이월 = (RR × 비율 + ADI보정 + GI + SO + DO) − (GI + HVA재고 + M1입고)   (+ 못 채운 수요, − 남는 공급)
    M2 = MIN( MAX(M1이월,0) + RR + ADI보정 ,  MAX(−M1이월,0) + M2입고 ), M2 이월도 같은 모양
    3개월이면 M3 = MAX(M2이월,0) + RR + ADI보정 (공급 한도 없음), 자원점검 = MAX(M3이월 + EOH, 0)
    4개월이면 M3은 M2처럼 한도 있음, M4 = MAX(M3이월,0) + RR (ADI보정 없음), 자원점검 = MAX(M4이월 + EOH, 0)
    수동입력이 있으면 그 달 수요만 바꾼다. 이월은 M3(3개월)·M4(4개월) 수요만 수동입력을 따른다 (DP 파일 수식 그대로).
    """
    n = lambda c: t[c].fillna(0).astype(float)
    L, M, F, G, H, I, N = n("rr"), n("adi_adjust"), n("gi"), n("hva_inv"), n("open_so"), n("open_do"), n("eoh")
    O, P, Q, R = n("inbound_m1"), n("inbound_m2"), n("inbound_m3"), n("inbound_m4")
    man = [pd.to_numeric(t.get(f"manual_m{i}"), errors="coerce") if f"manual_m{i}" in t else
           pd.Series(np.nan, index=t.index) for i in range(1, 5)]
    pos, neg = (lambda x: x.clip(lower=0)), (lambda x: (-x).clip(lower=0))
    use = lambda manual, calc: manual.where(manual.notna(), calc)

    out = pd.DataFrame(index=t.index)
    Lr = excel_round(L * ratio) if whole else L * ratio   # 이번 달 남은 기간의 R/R
    Y = (Lr + M + F + H + I) - (F + G + O)
    T = use(man[0], np.minimum((Lr + M).clip(lower=0) + F + H + I, F + G + O))
    Z = (pos(Y) + L + M) - (neg(Y) + P)
    U = use(man[1], np.minimum(pos(Y) + L + M, neg(Y) + P))
    if months < 4:
        V = use(man[2], pos(Z) + L + M)
        AA = V - (neg(Z) + Q)
        W = AB = pd.Series(np.nan, index=t.index)
        X = (AA + N).clip(lower=0)
    else:
        V = use(man[2], np.minimum(pos(Z) + L + M, neg(Z) + Q))
        AA = (pos(Z) + L + M) - (neg(Z) + Q)
        W = use(man[3], pos(AA) + L)
        AB = W - (neg(AA) + R)
        X = (AB + N).clip(lower=0)
    for i, (d, c) in enumerate([(T, Y), (U, Z), (V, AA), (W, AB)], start=1):
        out[f"demand_m{i}"] = d
        out[f"carry_m{i}"] = c
    out["resource_check"] = X
    return out


# ---- 입력 표 만들기 (ingest가 부른다) ----------------------------------------

def rebuild() -> str:
    e = store.latest_entry("dp_file")
    t = lambda name: store.load_table("dp_file", name, e) if e else None
    table, material, rr_items, dp_inbound = t("dp_table"), t("dp_material"), t("rr_items"), t("inbound")
    if e is None or table is None or material is None or dp_inbound is None or "dp_settings" not in e:
        raise RuntimeError("DP 파일에 계산 엔진 입력이 없습니다 (DP 파일을 다시 읽어야 합니다)")
    settings = e["dp_settings"]

    base = table[["item", "type", "bom", "pl_status", "rr_review", "review_reason"]].copy()
    # DP 파일 DP Table 값 (정답지). R/R·EOH는 전환 기간 동안 이 값을 쓴다
    base["rr_file"], base["eoh_file"] = table["rr"], table["eoh"]
    for i in range(1, MAX_MONTHS + 1):
        base[f"manual_file_m{i}"] = table[f"manual_m{i}"] if f"manual_m{i}" in table else np.nan
    for c in ["adi_adjust", "resource_check"] + [f"demand_m{i}" for i in range(1, 5)] + [f"carry_m{i}" for i in range(1, 5)]:
        base[f"dpf_{c}"] = table[c]
    # 8. DP Material: 단품 + BOM 전개 (화면 설명용)
    base = base.merge(material[["item", "kind", "own_rr", "bom_rr", "own_eoh", "bom_eoh", "headers", "rr_basis"]],
                      on="item", how="left")
    base["in_rr_list"] = base["item"].isin(set(rr_items["item"])) if rr_items is not None else True

    # 입고 (대조 보기용): DP 파일 3. Inbound 월별 합계. 최신 기준 입고는 아래 Sync − GR
    inb = dp_inbound.pivot_table(index="item", columns="month", values="total", aggfunc="first")
    for k in sorted(inb.columns):
        base[f"inbf_{k}"] = base["item"].map(inb[k]).fillna(0)
    dpf_inv = t("hva_inv")
    data_date = (None if dpf_inv is None or dpf_inv["key_date"].isna().all()
                 else dpf_inv["key_date"].max().strftime("%Y-%m-%d"))

    # dp_file 입력: DP 파일에 붙여 넣은 그 주 데이터 (DP Table F·G·H·I·K + ADI 보정용 2. ADI Inv)
    for ours, theirs in (("gi", "gi"), ("hva_inv", "hva_inv"), ("open_so", "open_so"), ("open_do", "open_do"),
                         ("adi_inv", "adi_inv")):
        base[f"dpf_{ours}"] = table[theirs].fillna(0)
    _, dpf_detail = flow.adi_by_item(t("adi"), t("pos_master"))
    s = adi_stats(dpf_detail)
    base["dpf_adi_iv"], base["dpf_adi_us"] = base["item"].map(s["adi_iv"]), base["item"].map(s["adi_us"])

    # 계산할 아이템: DP Table + Base Item. Base에만 있으면 DP 파일 값이 없어 R/R·EOH 0으로 계산한다
    base["in_dp_table"] = True
    active = set(base_items.active()["item"])
    extra = sorted(active - set(base["item"]))
    if extra:
        base = pd.concat([base, pd.DataFrame({"item": extra, "in_dp_table": False})], ignore_index=True)
    base["in_dp_table"] = base["in_dp_table"].astype(bool)
    base["in_rr_list"] = base["in_rr_list"].fillna(False).astype(bool)
    base["in_base"] = base["item"].isin(active) if active else base["in_dp_table"]   # Base 파일을 못 읽었으면 DP Table로

    # latest 입력: 가장 최근 파일 (없으면 DP 파일 값). 입고 = Sync − GR
    sources = {}
    monthly = store.read_cache(inbound.MONTHLY)
    if monthly is not None:
        for k, g in monthly.groupby("month"):
            base[f"inbs_{k}"] = base["item"].map(g.set_index("item")["qty"]).fillna(0)
    stock, info = inventory.pick_latest()
    if stock is not None:
        locs = settings.get("hva_inv_locations") or ["CFC5", "SCA3"]
        g = stock[stock["s_loc"].isin(locs)].groupby("item")[["unrestricted", "do_qty"]].sum()
        base["hva_inv"] = base["item"].map(g["unrestricted"]).fillna(0)
        base["open_do"] = base["item"].map(g["do_qty"]).fillna(0)
        sources["inventory"] = {**info, "locations": locs}
    fl = store.read_cache("item_flow")
    fm = store.read_cache_meta("flow_meta")
    if fl is not None:
        f = fl.set_index("item")
        for ours, theirs in (("gi", "gi_qty"), ("open_so", "open_so_qty"), ("adi_inv", "adi_available_qty")):
            if theirs in f:
                base[ours] = base["item"].map(f[theirs]).fillna(0)
        sources.update({k: fm.get(k) for k in ("orders", "returns", "adi")})
    detail = store.read_cache("adi_detail")
    if detail is not None:
        s = adi_stats(detail)
        base["adi_iv"], base["adi_us"] = base["item"].map(s["adi_iv"]), base["item"].map(s["adi_us"])
    for c in DATA_INPUTS:
        if c not in base:
            base[c] = base[f"dpf_{c}"]
            sources.setdefault("fallback", []).append(c)

    store.write_cache(CACHE, base)
    meta = {
        "version": VERSION, "settings_mtime": config.config_mtime(),
        "built_at": datetime.now().isoformat(timespec="seconds"),
        "dp_file": e["file"], "dp_week": e["dp_week"], "rr_base_month": e.get("rr_base_month"),
        "dp_file_data_date": data_date, "sync_inbound": monthly is not None,
        "file_months": settings.get("dp_months"), "file_base_date": settings.get("base_date"),
        "file_workday_ratio": e.get("workday_ratio"), "file_resource_check_label": e.get("resource_check_label"),
        "holidays_off": [d.isoformat() for d in holidays_off(settings)],
        "adi_adjust": settings.get("adi_adjust", {}), "sources": sources,
    }
    store.write_cache_meta(meta, META)
    cal = calendar(meta)
    return (f"이번 DP W{cal['dp_week']} · M1~M{cal['months']} "
            f"({', '.join(month_label(k) for k in cal['month_keys'][:cal['months']])}) · 아이템 {len(base):,}개 · "
            f"R/R·EOH는 {e['file']} (W{e['dp_week']}), 입고는 " + ("Sync − GR" if monthly is not None else "DP 파일"))


# ---- 계산 (화면·Claude·아이템 지표가 부른다) ---------------------------------

EDIT_FIELDS = ["rr", "eoh"]   # 입력값 (RR 기준월에 적용)


def plan(base: pd.DataFrame, meta: dict, edits: pd.DataFrame | None = None, mode: str = LATEST,
         today: date | None = None) -> pd.DataFrame:
    """아이템별 DP 계산. edits = 사람 입력 (inputs.active() 모양: item, field, period, week, value, original, by, at, memo).

    고친 값 적용:
      rr, eoh     period = RR 기준월인 것만. 고친 값이 R/R·EOH를 바꾼다 (ADI 보정도 바뀐 R/R로 다시 계산)
      manual      이 DP 주차에 고친 것. period = 그 달. 그 달 DP 값(수요)을 이 값으로 (DP Table 수동입력 열과 같다)
      rc_adjust   이 DP 주차에 고친 것. 자원점검 = MAX(계산한 자원점검 + 조정, 0)
      air, remarks  이 DP 주차의 업로드 나누기. AIR은 자원점검을 넘지 않고, VSL/TRK = 자원점검 − AIR
    calc_demand_m*, calc_resource_check = 사람 수정 없이 DP 파일 값만으로 계산한 값 (비교 기준)
    rc_formula = 고친 R/R·EOH·월 DP 값으로 계산한 자원점검 (조정 전)
    주차·기간은 calendar(): 화면 기본(latest)은 오늘 날짜로, dp_file은 DP 파일 Setting 주차로.
    """
    cal = calendar(meta, mode, today)
    months = cal["months"]
    keys = cal["month_keys"][:months]
    week = cal["week"]
    base = base[base["in_dp_table"] if mode == DP_FILE else base["in_base"]].reset_index(drop=True)
    t = base[["item", "in_dp_table", "type", "bom", "pl_status", "rr_review", "review_reason", "kind", "own_rr", "bom_rr",
              "own_eoh", "bom_eoh", "headers", "rr_basis", "in_rr_list"]].copy()
    src = "" if mode == LATEST else "dpf_"
    for c in DATA_INPUTS:
        t[c] = base[src + c].fillna(0)
    use = "inbs_" if mode == LATEST and meta.get("sync_inbound") else "inbf_"   # Sync − GR, 없으면 DP 파일
    for i, k in enumerate(cal["month_keys"], start=1):
        t[f"inbound_m{i}"] = base[use + k].fillna(0) if use + k in base else 0.0
    if use == "inbs_":   # 달이 넘어갔는데 아직 안 들어온 지난 달 몫은 M1에 넣는다 (ETA가 지나면 이번 주 도착과 같은 규칙)
        past = [c for c in base.columns if c.startswith("inbs_") and c[len(use):] < cal["month_keys"][0]]
        if past:
            t["inbound_m1"] = t["inbound_m1"] + base[past].fillna(0).sum(axis=1)
    inbound_missing = [k for k in keys if use + k not in base] if use == "inbf_" else []
    t["rr_file"], t["eoh_file"] = base["rr_file"].fillna(0), base["eoh_file"].fillna(0)
    t["rr"], t["eoh"] = t["rr_file"], t["eoh_file"]
    for i in range(1, MAX_MONTHS + 1):
        # DP 파일 수동입력 열은 그 파일의 달 기준이라 대조 보기에서만 쓴다
        t[f"manual_file_m{i}"] = base[f"manual_file_m{i}"] if i <= months and mode == DP_FILE else np.nan
        t[f"manual_m{i}"] = t[f"manual_file_m{i}"]
        t[f"manual_by_m{i}"] = None

    for f in EDIT_FIELDS:
        t[f"{f}_edit"] = False
        t[f"{f}_by"] = t[f"{f}_at"] = t[f"{f}_memo"] = None
        t[f"{f}_original"] = np.nan
    t["rc_adjust"] = 0.0
    t["rc_adjust_by"] = t["rc_adjust_at"] = t["rc_adjust_memo"] = None
    t["air_input"], t["remarks"] = 0.0, ""
    t["air_by"] = t["remarks_by"] = None
    if edits is not None and len(edits):
        idx = pd.Series(t.index, index=t["item"])

        def pick(mask):
            e = edits[mask]
            e = e[e["item"].isin(idx.index)]
            return e, idx[e["item"]].to_numpy()

        for f in EDIT_FIELDS:
            e, rows = pick((edits["field"] == f) & (edits["period"] == meta.get("rr_base_month")))
            t.loc[rows, f] = e["value"].astype(float).to_numpy()
            t.loc[rows, f"{f}_edit"] = True
            t.loc[rows, f"{f}_original"] = pd.to_numeric(e["original"], errors="coerce").to_numpy(dtype=float)
            for k in ("by", "at", "memo"):
                t.loc[rows, f"{f}_{k}"] = e[k].to_numpy()
        this_week = edits["week"] == week if "week" in edits else pd.Series(False, index=edits.index)
        for i, k in enumerate(keys, start=1):
            e, rows = pick(this_week & (edits["field"] == "manual") & (edits["period"] == k))
            t.loc[rows, f"manual_m{i}"] = e["value"].astype(float).to_numpy()
            t.loc[rows, f"manual_by_m{i}"] = e["by"].to_numpy()
        e, rows = pick(this_week & (edits["field"] == "rc_adjust"))
        t.loc[rows, "rc_adjust"] = e["value"].astype(float).to_numpy()
        for k in ("by", "at", "memo"):
            t.loc[rows, f"rc_adjust_{k}"] = e[k].to_numpy()
        e, rows = pick(this_week & (edits["field"] == "air"))
        t.loc[rows, "air_input"] = e["value"].astype(float).to_numpy()
        t.loc[rows, "air_by"] = e["by"].to_numpy()
        if "text" in edits:
            e, rows = pick(this_week & (edits["field"] == "remarks"))
            t.loc[rows, "remarks"] = e["text"].fillna("").astype(str).to_numpy()
            t.loc[rows, "remarks_by"] = e["by"].to_numpy()
    # 숫자는 아이템 수량이라 정수로 (사용자 2026-11-04): R/R·EOH·ADI 보정·사람 입력과 M1의 R/R × 남은 근무일 비율을
    # 반올림(Excel ROUND)하면 월 DP 값·이월·자원점검·AIR/VSL이 모두 정수가 된다.
    # 대조 보기(dp_file)만 DP 파일과 똑같이 소수 그대로 계산한다 (DP Table과 같은지 확인용, 화면에는 반올림해서 보임)
    whole = mode != DP_FILE
    if whole:
        for c in ["rr", "eoh", "rr_file", "eoh_file", "rc_adjust", "air_input"] + \
                 [f"{k}_m{i}" for k in ("manual", "manual_file") for i in range(1, MAX_MONTHS + 1)]:
            t[c] = excel_round(pd.to_numeric(t[c], errors="coerce"))
    for f in EDIT_FIELDS:
        # 고친 뒤에 DP 파일의 원래 값이 바뀌었으면 알린다 (낡은 수정이 조용히 남지 않게)
        orig = pd.to_numeric(t[f"{f}_original"], errors="coerce")
        orig = excel_round(orig) if whole else orig
        t[f"{f}_stale"] = t[f"{f}_edit"] & orig.notna() & ((orig - t[f"{f}_file"]).abs() > 1e-6)

    ratio = cal["workday_ratio"]
    p = meta.get("adi_adjust", {})
    digits = 0 if whole else 1
    # 사람 수정 없이: DP 파일 R/R·EOH·수동입력 그대로
    t0 = t.assign(rr=t["rr_file"], eoh=t["eoh_file"],
                  **{f"manual_m{i}": t[f"manual_file_m{i}"] for i in range(1, MAX_MONTHS + 1)})
    t0["adi_adjust"] = adi_adjust(t0["rr"], t0["adi_iv"], t0["adi_us"], p, digits)
    calc = monthly(t0, months, ratio, whole)
    # 사람 수정 반영
    t["adi_adjust"] = adi_adjust(t["rr"], t["adi_iv"], t["adi_us"], p, digits)
    t = pd.concat([t, monthly(t, months, ratio, whole)], axis=1)
    for i in range(1, MAX_MONTHS + 1):
        t[f"calc_demand_m{i}"] = calc[f"demand_m{i}"]
    t["calc_resource_check"] = calc["resource_check"]
    t["rc_formula"] = t["resource_check"]
    t["resource_check"] = (t["rc_formula"] + t["rc_adjust"]).clip(lower=0)
    # 업로드 나누기 (DP Upload.xlsx의 AIR · VSL / TRK). 대조 보기에서도 업로드 수량은 정수
    upload_qty = excel_round(t["resource_check"])
    t["air"] = np.minimum(t["air_input"].clip(lower=0), upload_qty)
    t["vsl"] = upload_qty - t["air"]
    t["upload"] = (upload_qty > 0) | (t["remarks"] != "")
    t["available"] = t["hva_inv"] + t["adi_inv"] - t["open_so"] - t["open_do"]
    t["dpf_resource_check"] = base["dpf_resource_check"]
    t["vs_dp_file"] = t["resource_check"] - t["dpf_resource_check"].fillna(0)
    t["edited"] = (t["rr_edit"] | t["eoh_edit"] | t["rc_adjust_by"].notna()
                   | t[[f"manual_by_m{i}" for i in range(1, MAX_MONTHS + 1)]].notna().any(axis=1))
    t.attrs["workday_ratio"] = ratio
    t.attrs["week"] = week
    t.attrs["calendar"] = cal
    t.attrs["inbound_missing"] = inbound_missing
    return t


def current_plan(mode: str = LATEST, pending: list[dict] | None = None) -> tuple[pd.DataFrame, dict] | tuple[None, dict]:
    """저장된 입력 표 + 사람 입력(+ 아직 저장 안 한 수정 pending)으로 계산. (결과, meta)"""
    base = store.read_cache(CACHE)
    meta = store.read_cache_meta(META)
    if base is None or not meta:
        return None, meta
    edits = inputs.active(pending)
    return plan(base, meta, edits, mode), meta


def workday_text(meta: dict, today: date | None = None) -> str:
    """'3 / 22일' 같은 설명 (오늘 포함 남은 근무일 / 이번 달 근무일)."""
    today = today or config.today()
    first = today.replace(day=1)
    nxt = (first + timedelta(days=32)).replace(day=1)
    h = np.array(meta.get("holidays_off", []), dtype="datetime64[D]")
    return f"{np.busday_count(today, nxt, holidays=h)} / {np.busday_count(first, nxt, holidays=h)}일"
