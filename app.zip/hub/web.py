"""웹(링크) 버전 (사용자 2026-11-18, docs/web.md).

GitHub Pages에 올린 HTML(web/build.py)에서 이 앱이 브라우저 안의 파이썬(stlite · Pyodide)으로 돈다.
브라우저는 PC 폴더(samples·OneDrive 공유 폴더)를 못 보므로:
  - 원천 파일은 '원천 파일' 화면(views/web_files.py)에서 올린다 → 브라우저 저장소 /data/files/<root>/<folder>
  - 캐시(/data/cache)·사람 입력(/data/inputs)도 그 브라우저(IndexedDB)에만 남는다. 팀원·다른 PC에는 안 보인다
  - 회사 데이터는 GitHub로 가지 않는다 (파이썬이 브라우저 안에서 읽고 계산한다)
웹 버전 여부 = 환경 변수 HVA_HUB_FILES_DIR (web/index.html이 넣는다). PC 버전(run_hub.bat)은 그대로다.
"""

import os
import shutil
from pathlib import Path

from . import config, files

PAGE = "views/web_files.py"
EXCEL = ["xlsx", "xlsb", "xlsm", "xls"]


def files_dir() -> Path | None:
    v = os.environ.get("HVA_HUB_FILES_DIR")
    return Path(v) if v else None


def is_web() -> bool:
    return files_dir() is not None


def root(name: str) -> Path:
    """sources.yaml root 이름(samples·shared) → 브라우저 저장소 폴더."""
    p = files_dir() / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def sources() -> list[dict]:
    """올릴 수 있는 원천 (폴더에서 읽는 것). Sync Plan·In-transit·GR은 'Inbound' 화면에서 올린다."""
    return [s for s in config.sources() if s.get("enabled") and s.get("root") in ("samples", "shared")]


def generic(src: dict) -> bool:
    """이름만으로는 어느 원천인지 모르는 패턴 (예: RR 파일 '*.xlsx'). 따로 올린다."""
    return src["pattern"].startswith("*")


def match(name: str) -> list[str]:
    """파일 이름 → 맞는 원천 id (이름 패턴이 정해진 원천만)."""
    return [s["id"] for s in sources() if not generic(s) and files.name_matches(name, s["pattern"])]


def folder(source_id: str) -> Path:
    src = config.source(source_id)
    return root(src["root"]) / src.get("folder", ".")


def save(source_id: str, name: str, data: bytes) -> tuple[Path | None, str]:
    """올린 파일을 그 원천 폴더에 둔다. 잠긴 파일(DRM)은 두지 않는다.
    원천마다 가장 최근 파일 하나만 쓰므로, 같은 원천의 이전 파일은 지운다 (브라우저 저장 공간 절약)."""
    if data[:5] == files.DRM_MAGIC:
        return None, "DRM 잠김 (Decrypt 후 다시 업로드)"
    if data[:2] != files.ZIP_MAGIC:
        return None, "엑셀 파일 아님"
    src = config.source(source_id)
    d = folder(source_id)
    d.mkdir(parents=True, exist_ok=True)
    for old in d.iterdir():
        if old.is_file() and files.name_matches(old.name, src["pattern"]):
            old.unlink()
    path = d / Path(name).name
    path.write_bytes(data)
    return path, "저장"


def stored(source_id: str) -> Path | None:
    src = config.source(source_id)
    path, _ = files.pick_latest(folder(source_id), src)
    return path


def clear() -> None:
    """브라우저에 둔 원천 파일·계산 결과를 지운다. 사람 입력(/data/inputs)은 남긴다."""
    for p in (files_dir(), config.data_dir()):
        if p and p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
