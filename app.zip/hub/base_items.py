"""Base Item: DP의 기준 아이템 목록 (사용자 2026-11-06, docs/dp-target.md).

지금 쓰는 목록 = Base Item 파일(samples/Base Item.xlsx, Base Item 시트) + 툴에서 넣은 아이템 − 툴에서 뺀 아이템.
툴에서 넣은 내용은 사람 입력(hub/inputs.py, 항목 base_item)으로 사람별 파일에 쌓인다 → 누가 언제 넣었는지 남고 팀에 공유된다.
  value 1 = 넣음 (파일에 있는 아이템이면 이름·Group만 고침), 값 없음 = 뺌
  info = {"group": 'CAMERA'} 담당은 Group으로 정해진다 (settings.yaml owners)
"""

import hashlib

import pandas as pd

from . import inputs, store

FILE, TOOL = "파일", "대시보드"
COLUMNS = ["item", "item_name", "source", "group", "memo", "by", "at"]


def seed() -> pd.DataFrame:
    """Base Item 파일의 아이템."""
    e = store.latest_entry("base_item")
    df = store.load_table("base_item", "items", e) if e else None
    return df if df is not None else pd.DataFrame(columns=["item", "item_name"])


def _changes() -> pd.DataFrame:
    """툴에서 넣거나 뺀 기록, 아이템마다 가장 최근 줄."""
    df, _ = inputs.load()
    if df.empty:
        return df
    return df[df["field"] == "base_item"].drop_duplicates("item", keep="last")


def active() -> pd.DataFrame:
    """지금 쓰는 아이템 목록 (아이템 순)."""
    base = seed().assign(source=FILE, group=None, memo=None, by=None, at=None).set_index("item", drop=False)
    base = base.astype({c: object for c in ("group", "memo", "by", "at")})
    for r in _changes().itertuples(index=False):
        if pd.isna(r.value):
            base = base.drop(index=r.item, errors="ignore")
            continue
        info = r.info if isinstance(r.info, dict) else {}
        if r.item in base.index:
            if r.text:
                base.at[r.item, "item_name"] = r.text
            base.at[r.item, "group"] = info.get("group")
            base.at[r.item, "by"], base.at[r.item, "at"] = r.by, r.at
        else:
            row = {"item": r.item, "item_name": r.text or r.item, "source": TOOL, "group": info.get("group"),
                   "memo": r.memo, "by": r.by, "at": r.at}
            base = pd.concat([base, pd.DataFrame([row]).set_index("item", drop=False)])
    return base[COLUMNS].reset_index(drop=True).sort_values("item", ignore_index=True)


def signature() -> str:
    """목록이 바뀌었는지 보는 값 (다른 사람이 아이템을 넣으면 Item Master·계산을 다시 만든다)."""
    a = active()
    text = "|".join(f"{i}:{n}:{g}" for i, n, g in zip(a["item"], a["item_name"], a["group"]))
    return hashlib.sha1(text.encode("utf-8")).hexdigest()
