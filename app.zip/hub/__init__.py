"""HVA SCM Hub 데이터 계층. 화면(app.py)과 Claude 연결(mcp_server.py)이 같이 쓴다."""
