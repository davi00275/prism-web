"""Item Master: 여러 원천의 아이템 정보를 한 표로 합친다.

기준 = Product List. DP list에만 있는 아이템도 넣는다.
  + POS 매핑 파일: Local 여부(Local List), BOM 구성(BOM List), POS SKU 별칭(DP Material 매핑)
  + DP 파일 DP list: Series, ASP, 판매 평균, 현행/제안 RR, EOH Target, PriceList 상태
  + Base Item (hub/base_items.py): DP의 기준 아이템 (in_base). 툴에서 새로 넣은 아이템은 여기서 줄이 생긴다
결과는 cache/item_master.parquet, item_aliases.parquet, bom.parquet
"""

from datetime import datetime

import pandas as pd

from . import base_items, codes, config, store

# 만드는 방식(코드)을 바꾸면 올린다. 캐시의 버전과 다르면 파일이 그대로여도 다시 만든다
# 4: PriceList Limited·EOL, DP 제외 이유 / 5: EOL 날짜는 PriceList 이후만 (2026-10-26) / 6: Base Item (2026-11-06)
VERSION = 6
NAME = "Item Master"
CACHE = "item_master"

# Product List 열 → Item Master 열
PRODUCT_COLUMNS = {
    "Item": "item", "Item Name": "item_name", "Product Group": "product_group", "Product": "product",
    "Model Group": "model_group", "Model Name": "model_name", "PLC Status": "plc_status",
    "BOM Status": "bom_status", "SCM Type": "scm_type", "From Site Name": "from_site",
    "Product Type": "product_type", "SRA": "sra", "EOL": "eol", "EOP": "eop", "EOP Start": "eop_start",
    "EOP Qty": "eop_qty", "Attb01": "type", "Attb02": "sub_type", "Attb03": "pl_series",
    "Attb05": "resolution", "Attb06": "feature", "Attb13": "ai_target", "Attb14": "moq_lt",
    "GROUP Constraints": "group_constraints", "Site Constraints": "site_constraints",
}
# DP list 열 → Item Master 열 (dp_ 접두어)
DP_COLUMNS = ["to_site", "series", "asp", "sales_prev_year", "sales_recent6", "sales_recent3",
              "rr_current", "rr_proposed", "rr_rule", "rr_flag", "eoh_target", "pl_status", "pl_notes",
              "rr_risk_flag", "rr_risk_reason", "prev_model"]


def rebuild() -> str:
    """최신 스냅샷으로 Item Master를 다시 만들고 요약 문장을 돌려준다."""
    products = store.load_table("product_list", "items")
    if products is None:
        raise RuntimeError("Product List 스냅샷이 없습니다. Product List 파일을 먼저 불러오세요.")
    local = store.load_table("pos_mapping", "local_list")
    bom = store.load_table("pos_mapping", "bom_list")
    pos = store.load_table("pos_mapping", "pos_map")
    dp = store.load_table("dp_file", "dp_list")
    dp_table = store.load_table("dp_file", "dp_table")
    kv_models = store.load_table("dp_file", "kv_models")
    kv_ratio = store.load_table("dp_file", "kv_ratio")
    pl_limited = store.load_table("dp_file", "pl_limited")
    pl_eol = store.load_table("dp_file", "pl_eol")
    pl_date = (store.latest_entry("dp_file") or {}).get("pricelist_date")

    base = base_items.active()
    master = build(products, local, bom, pos, dp, config.settings(), dp_table, kv_models, base)
    master = add_dp_exclusions(master, pl_limited, pl_eol, pl_date)
    aliases = build_aliases(pos)
    bom_table = bom if bom is not None else pd.DataFrame(columns=["header", "component", "qty"])

    store.write_cache("item_master", master)
    store.write_cache("item_aliases", aliases)
    store.write_cache("bom", bom_table)
    # DP 파일 계산 결과는 그대로 넘긴다 (F8 1단계: 툴이 다시 계산하지 않고 읽어서 보여준다)
    for name, df in (("dp_table", dp_table), ("kv_models", kv_models), ("kv_ratio", kv_ratio)):
        if df is not None:
            store.write_cache(name, df)
        elif store.cache_path(name).exists():
            store.cache_path(name).unlink()

    inputs = {}
    for sid in ("product_list", "pos_mapping", "dp_file", "base_item"):
        e = store.latest_entry(sid)
        if e:
            inputs[sid] = {k: e.get(k) for k in ("file", "file_date", "loaded_at", "snapshot", "dp_week", "rr_base_month")}
    counts = {
        "items": int(len(master)),
        "active_planned": int(master["plc_status"].isin(["ACTIVE", "PLANNED"]).sum()),
        "dp_targets": int(master["in_base"].sum()),
        "local": int(master["is_local"].sum()),
        "bom_headers": int(master["is_bom_header"].sum()),
        "pos_aliases": int(len(aliases)),
    }
    store.write_cache_meta({"version": VERSION, "built_at": datetime.now().isoformat(timespec="seconds"),
                            "settings_mtime": config.config_mtime(), "inputs": inputs, "counts": counts,
                            "base_signature": base_items.signature()})
    return (f"아이템 {counts['items']:,} · ACTIVE/PLANNED {counts['active_planned']:,} · DP 대상 {counts['dp_targets']:,}"
            f" · Local {counts['local']:,} · BOM 헤더 {counts['bom_headers']:,}")


def stale(meta: dict) -> bool:
    """툴에서 아이템을 넣거나 빼면 (다른 사람이 넣은 것이 동기화돼도) 다시 만든다."""
    return meta.get("base_signature") != base_items.signature()


def add_dp_exclusions(m: pd.DataFrame, pl_limited, pl_eol, pl_date: str | None) -> pd.DataFrame:
    """예전 DP 제외 이유 (2026-11-06부터 DP 대상은 Base Item으로 정한다. 참고 정보·주의 신호로만 쓴다).
    위에서부터 처음 걸리는 이유 하나.

    BOM 헤더 → Local → PriceList EOL → PriceList Limited Stock → PriceList 이후 EOL 날짜가 지남
    PriceList 아이템에 '/'가 있으면 그 아이템만, 없으면 그 모델의 모든 suffix에 적용한다
    (Limited는 TAA용 K 코드만 Limited인 경우가 있어서 모델 전체로 넓히면 안 된다).
    PriceList는 매월 1일 기준이라, 그 뒤에 EOL 날짜가 지난 아이템은 Product List EOL 날짜로 뺀다 (사용자).
    그 전에 EOL 날짜가 지났는데 PriceList에 없는 아이템은 아직 팔고 있는 경우가 많아서 빼지 않는다.
    """
    m = m.copy()
    m["pl_limited"] = _pricelist_hit(m, pl_limited)
    m["pl_eol"] = _pricelist_hit(m, pl_eol)
    eol_info = _pricelist_lookup(m, pl_eol, ["eol_date", "replacement"])
    m["pl_eol_date"], m["pl_replacement"] = eol_info["eol_date"], eol_info["replacement"]
    eol = pd.to_datetime(m["eol"], errors="coerce")
    today = pd.Timestamp(datetime.now().date())
    since = pd.Timestamp(pl_date) if pl_date else today.replace(day=1)
    m["eol_passed"] = eol < today
    m["eol_new"] = (eol >= since) & (eol < today)

    reasons = [
        (m["is_bom_header"], "BOM 헤더 (구성품으로 DP)"),
        (m["is_local"], "Local"),
        (m["pl_eol"], "PriceList EOL"),
        (m["pl_limited"], "PriceList Limited Stock"),
        (m["eol_new"], f"PriceList({since:%m/%d}) 이후 EOL (" + eol.dt.strftime("%Y-%m-%d").fillna("") + ")"),
    ]
    reason = pd.Series(None, index=m.index, dtype=object)
    for hit, text in reversed(reasons):  # 뒤에서부터 덮어써서 위의 이유가 남게
        reason = reason.where(~hit.fillna(False).astype(bool), text)
    m["dp_exclude_reason"] = reason
    return m


def _pricelist_hit(m: pd.DataFrame, pl) -> pd.Series:
    if pl is None or pl.empty:
        return pd.Series(False, index=m.index)
    names = pl["item_no"].astype(str).str.strip()
    exact = set(names[names.str.contains("/")])
    model = set(names[~names.str.contains("/")])
    return m["item"].isin(exact) | m["base"].isin(model) | m["item"].isin(model)


def _pricelist_lookup(m: pd.DataFrame, pl, cols: list[str]) -> pd.DataFrame:
    out = pd.DataFrame(index=m.index, columns=cols, dtype=object)
    if pl is None or pl.empty:
        return out
    pl = pl.assign(item_no=pl["item_no"].astype(str).str.strip()).set_index("item_no")
    for c in cols:
        exact = m["item"].map(pl[c])
        by_model = m["base"].map(pl[c])
        out[c] = exact.where(exact.notna(), by_model)
    return out


def build(products, local, bom, pos, dp, settings, dp_table=None, kv_models=None, base=None) -> pd.DataFrame:
    m = products[[c for c in PRODUCT_COLUMNS if c in products.columns]].rename(columns=PRODUCT_COLUMNS)
    m["in_product_list"] = True

    if dp is not None and len(dp):
        d = dp.rename(columns={c: f"dp_{c}" for c in DP_COLUMNS})
        only_dp = d[~d["item"].isin(m["item"])]
        if len(only_dp):
            # Product List에 없는 DP 아이템: DP list 정보로 기본 칸을 채운다
            extra = pd.DataFrame({
                "item": only_dp["item"], "item_name": only_dp["item_name"],
                "product_group": only_dp["product_group"], "model_group": only_dp["model_group"],
                "sra": only_dp["sra"], "eol": only_dp["eol"], "eop": only_dp["eop"],
                "from_site": only_dp["from_site"], "product_type": only_dp["product_type"],
                "in_product_list": False,
            })
            m = pd.concat([m, extra], ignore_index=True)
        keep = ["item"] + [f"dp_{c}" for c in DP_COLUMNS]
        m = m.merge(d[keep], on="item", how="left")
        m["in_dp_list"] = m["item"].isin(d["item"])
    else:
        for c in DP_COLUMNS:
            m[f"dp_{c}"] = None
        m["in_dp_list"] = False

    # Local List에만 있는 아이템 (HVA가 직접 들여오는 Local 제품. 본사 Product List에는 없다)
    if local is not None and len(local):
        only_local = local[~local["Item"].isin(m["item"])]
        if len(only_local):
            m = pd.concat([m, pd.DataFrame({"item": only_local["Item"], "in_product_list": False,
                                            "in_dp_list": False})], ignore_index=True)
    # BOM List 헤더에만 있는 아이템 (HDD를 끼운 Recorder 세트 등)
    if bom is not None and len(bom):
        only_bom = pd.Series(bom["header"].unique())
        only_bom = only_bom[~only_bom.isin(m["item"])]
        if len(only_bom):
            m = pd.concat([m, pd.DataFrame({"item": only_bom, "in_product_list": False,
                                            "in_dp_list": False})], ignore_index=True)
    # Base Item: Product List에 없는 아이템(툴에서 새로 넣은 아이템)은 줄을 만들고, 사람이 정한 이름·Group을 쓴다
    if base is not None and len(base):
        only_base = base[~base["item"].isin(m["item"])]
        if len(only_base):
            m = pd.concat([m, pd.DataFrame({"item": only_base["item"], "item_name": only_base["item_name"],
                                            "in_product_list": False, "in_dp_list": False})], ignore_index=True)
        chosen = base.dropna(subset=["group"]).set_index("item")["group"]
        m["product_group"] = m["item"].map(chosen).fillna(m["product_group"])
        m["in_base"] = m["item"].isin(base["item"])
    else:
        m["in_base"] = False
    m["in_product_list"] = m["in_product_list"].fillna(False).astype(bool)
    m["in_dp_list"] = m["in_dp_list"].fillna(False).astype(bool)

    # 아이템 코드 규칙
    site_letters = settings.get("site_letters", {})
    split = m["item"].map(codes.split)
    m["base"] = split.str[0]
    m["suffix"] = split.str[1]
    sd = m["suffix"].map(lambda s: codes.parse_suffix(s, site_letters))
    m["site"] = sd.str[0]
    m["dest"] = sd.str[1]
    fv = m["base"].map(codes.family)
    m["family_key"] = fv.str[0]
    m["version"] = pd.to_numeric(fv.str[1], errors="coerce").astype("Int64")

    owners = settings.get("owners", {})
    m["owner"] = m["product_group"].map(lambda g: owners.get(g) if isinstance(g, str) else None)

    local_items = set(local["Item"]) if local is not None else set()
    m["is_local"] = m["item"].isin(local_items)
    headers = set(bom["header"]) if bom is not None else set()
    components = set(bom["component"]) if bom is not None else set()
    m["is_bom_header"] = m["item"].isin(headers)
    m["is_bom_component"] = m["item"].isin(components)

    # DP Table의 RR Review (TAA·대형프로젝트 수동입력, 검토, 신규 등)
    if dp_table is not None and len(dp_table):
        review = dp_table.set_index("item")[["rr_review", "review_reason"]]
        m["dp_review"] = m["item"].map(review["rr_review"])
        m["dp_review_reason"] = m["item"].map(review["review_reason"])
    else:
        m["dp_review"] = None
        m["dp_review_reason"] = None
    m["is_manual_input"] = m["dp_review"].fillna("").str.contains("수동입력")
    kv_items = set(kv_models["k_sku"]) | set(kv_models["v_sku"]) if kv_models is not None else set()
    m["is_kv_switch"] = m["item"].isin(kv_items)

    # 검색 키: 아이템, 모델명, 품명 (특수문자 없이). POS SKU는 item_aliases에서 따로 찾는다
    m["search_key"] = (m["item"].map(codes.norm) + "|" + m["model_name"].map(codes.norm)
                       + "|" + m["item_name"].map(codes.norm))
    return m.sort_values("item").reset_index(drop=True)


def build_aliases(pos: pd.DataFrame | None) -> pd.DataFrame:
    """POS SKU → DP 아이템. Sell-out(POS)에서 쓰는 이름으로도 검색되게 한다."""
    cols = ["alias", "alias_norm", "item", "kind", "po_sku", "qty", "stage"]
    if pos is None or not len(pos):
        return pd.DataFrame(columns=cols)
    a = pos[pos["dp_item"].notna()].copy()
    out = pd.DataFrame({
        "alias": a["pos_sku"], "alias_norm": a["pos_sku"].map(codes.norm), "item": a["dp_item"],
        "kind": "POS SKU", "po_sku": a["po_sku"], "qty": a["qty"], "stage": a["stage"],
    })
    return out.drop_duplicates(["alias", "item"]).reset_index(drop=True)
