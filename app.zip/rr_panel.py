"""RR 리뷰 오른쪽 패널: SKU 하나 (views/run_rate.py 왼쪽 목록에서 누르면). RR 담당자 화면 시안 2026-11-10.

위에서 아래로: SKU · ◀ n/N ▶ 한 줄 → 배지·제품 정보 한 줄 → 현행 / 제안 / 재고 → 12개월 차트 (누르자마자 보이게)
→ 플래그 근거 한 상자 (실제 + 작은 글씨 기준) → 제안 공식 한 줄
→ RR 결정 (제안값 적용 · 현행 유지 · 직접 입력, 사유, 보류 · 저장 후 다음 SKU) → 자세히 (계산 해부 · 트렌드 · 기본정보 · 출처).
RR 파일에 없는 Base Item(📝, 사용자 2026-11-11)은 차트·공식이 없다: 숫자 → 플래그 근거 → RR 결정(현행 유지·직접 입력) → 기본정보·리뷰 이력.
패널은 st.fragment라서 고르거나 ◀ ▶로 넘길 때 패널만 다시 그린다. 저장하면 화면 전체를 다시 그린다 (목록 '최종'·진행 숫자).
수량은 정수로 보인다 (계산은 소수, 사용자 2026-11-10). 계수·비율·개월 수만 소수.
"""

import html

import altair as alt
import numpy as np
import pandas as pd
import streamlit as st

import ui
from hub import rr_engine as E, rr_review as R, service

FLAG_COLOR = {"red": "red", "manual": "red", "norr": "red", "yellow": "orange", "delta": "orange", "project": "violet", "new": "blue",
              "early": "green", "surge": "orange", "drop": "orange", "pl": "gray", "eop": "gray", "kv": "gray"}
PRIORITY_COLOR = {E.HIGH: "red", E.MID: "orange", E.LOW: "gray"}
STATUS_COLOR = {R.NOT_YET: "gray", R.CHECKED: "green", R.ADJUSTED: "blue", R.HOLD: "violet"}
BAR, BAR_EX, BAR_CAP, SO_LINE, NOW, NEW = "#F8B98A", "#D2D2D7", "#F37321", "#3A4556", "#6E6E73", "#F37321"
PROPOSE, KEEP, OWN = "제안", "현행", "직접"
NO_RR_REASON = "RR 파일 미포함 (수동 입력)"


def n(v) -> str:
    """수량: 정수."""
    return "–" if ui.blank(v) else f"{E.xround(float(v)):,.0f}"


def f2(v) -> str:
    return "–" if ui.blank(v) else f"{float(v):.2f}"


def md(text) -> str:
    """markdown에서 $·~가 수식·취소선으로 바뀌지 않게."""
    return str(text or "").replace("$", "\\$").replace("~", "\\~")


def esc(text) -> str:
    """HTML을 섞어 쓰는 markdown 안의 글자 (<, &, $, ~, *, _, [, ] 그대로 보이게)."""
    out = html.escape(str(text or ""), quote=False)
    for ch in "\\`*_[]$~":
        out = out.replace(ch, "\\" + ch)
    return out


def months_of(inv, rr) -> str:
    """재고 ÷ RR (개월, 소수 1자리)."""
    if ui.blank(inv) or ui.blank(rr) or float(rr) <= 0:
        return "–"
    return f"{float(inv) / float(rr):.1f}"


def flag_badges(o: dict) -> str:
    return " ".join(ui.badge(f"{E.FLAG[c][0]} {E.FLAG[c][1]}", FLAG_COLOR[c]) for c in o["flags"])


def _go(item: str) -> None:
    st.session_state.rr_pick = item


@st.fragment
def panel(view: pd.DataFrame, p: dict, per: dict, height: int = 860) -> None:
    """view = 왼쪽 목록 (그 순서로 ◀ ▶). 보는 SKU는 st.session_state.rr_pick.
    스크롤 칸은 SKU마다 새로 만든다 (다음 SKU로 넘어가면 맨 위부터 보이게)."""
    pick = st.session_state.get("rr_pick")
    with st.container(height=height, border=True, key=f"rr_box_{abs(hash(str(pick))) % 10 ** 9}"):
        _body(view, p, per)


def _body(view: pd.DataFrame, p: dict, per: dict) -> None:
    ids = view["item"].tolist()
    pick = st.session_state.get("rr_pick")
    if pick not in ids:
        st.info("좌측 목록에서 SKU 선택 시 상세 표시.", icon=":material/left_click:")
        return
    i = ids.index(pick)
    o = view.iloc[i].to_dict()
    o["flags"] = list(o["flags"])
    o["flag_reasons"] = list(o["flag_reasons"]) if o.get("flag_reasons") is not None else []

    # 머리글 한 줄: SKU · ◀ n/N ▶
    c = st.columns([2.8, 0.55, 0.95, 0.55], vertical_alignment="center", gap="small")
    c[0].markdown(f"<div class='rr-title'>{html.escape(o['item'])}</div>", unsafe_allow_html=True)
    c[1].button("◀", key="rr_prev", width="stretch", disabled=i == 0, help="목록의 이전 SKU",
                on_click=_go, args=(ids[max(i - 1, 0)],))
    c[2].markdown(f"<div class='rr-count'>{i + 1:,} / {len(ids):,}</div>", unsafe_allow_html=True)
    c[3].button("▶", key="rr_next", width="stretch", disabled=i == len(ids) - 1, help="목록의 다음 SKU",
                on_click=_go, args=(ids[min(i + 1, len(ids) - 1)],))

    tags = []
    if o.get("priority"):
        tags.append(ui.badge(f"우선순위 {o['priority']}", PRIORITY_COLOR[o["priority"]]))
    tags.append(ui.badge(o.get("status") or R.NOT_YET, STATUS_COLOR.get(o.get("status"), "gray")))
    if not o["review"]:
        tags.append(ui.badge("자동 확정", "green"))
    sub = [o.get("product_group"), o.get("series"), o.get("model_group"), o.get("plc"),
           None if ui.blank(o.get("owner")) else f"담당 {o['owner']}"]
    sub = " · ".join(str(x) for x in sub if not ui.blank(x) and str(x).strip() not in ("-", "–"))
    if not ui.blank(o.get("item_name")) and o["item_name"] != o["item"]:
        sub += f" · {o['item_name']}"
    with st.container(key="rr_head"):
        st.markdown(" ".join(tags) + f" <span class='rr-sub'>{esc(sub)}</span>", unsafe_allow_html=True)
    _previous(o)
    if o.get("no_rr"):
        _no_rr(o, p, ids, i)
        return

    k = st.columns(3, gap="small")
    with k[0].container(key="rrsum_now"):
        st.metric("현행 RR", n(o["rr_current"]), help="DP list V열 (확정 값)")
    with k[1].container(key="rrsum_new"):
        pct = (None if ui.blank(o["delta"]) else "NEW" if o["rr_current"] == 0 and o["proposed_rr"] > 0
               else f"{E.xround(o['delta']):+,.0f}" if ui.blank(o["delta_pct"]) else f"{o['delta_pct']:+.1%}")
        st.metric("제안 RR", n(o["proposed_rr"]), delta=pct, delta_color="blue", delta_arrow="off",
                  help=f"제안 RR {p.get('version')} · {o['rule']}. 현행 대비 "
                  + ("–" if ui.blank(o["delta"]) else f"{E.xround(o['delta']):+,.0f}대"))
    with k[2].container(key="rrsum_inv"):
        st.metric("OH", n(o.get("inv")), delta=f"{months_of(o.get('inv'), o['final_rr'])}개월", delta_color="off",
                  delta_arrow="off", help="OH = 최신 재고 파일 CFC5 + SCA3. 재고개월 = OH ÷ 최종 RR (보정 RR 없으면 제안 RR)")

    # 차트를 숫자 바로 밑에 (누르자마자 보이게, 사용자 2026-11-10)
    with st.container(key="rr_chart"):
        st.markdown("<div class='rr-h'>12개월 Sell-in · Sell-out</div>", unsafe_allow_html=True)
        st.altair_chart(trend_chart(o, p, per, months=12, compact=True), width="stretch")
    _flag_reasons(o, p)
    with st.container(key="rr_formula"):
        st.caption(md(f"제안 공식 · {E.explain(o, p)} EOH: 현행 {n(o['eoh_current'])} → 제안 {n(o['proposed_eoh'])} "
                      f"({o['eoh_rule']})."))
    _decide(o, p, ids, i)

    st.markdown("**상세**")
    tabs = st.tabs(["계산 해부", "트렌드 24개월", "기본정보", "출처·비교"])
    with tabs[0]:
        _anatomy(o, p, per)
    with tabs[1]:
        st.altair_chart(trend_chart(o, p, per), width="stretch")
        st.caption(f"막대 = Sell-in, 선 = Sell-out ({per['pos_lag']}개월 지연 반영, Sell-in 월 기준으로 정렬). "
                   "회색 막대 = 사재기 제외월, 진한 주황 막대 = 캡 초과월 (평균에는 캡 값 반영). "
                   "가로선: 현행 R/R(회색 점선)·제안 RR(주황).")
        _compare_box(o)
    with tabs[2]:
        _basic(o)
    with tabs[3]:
        _sources(o, p, per, view)


def _no_rr(o: dict, p: dict, ids: list[str], i: int) -> None:
    """RR 파일에 없는 Base Item: 판매·계산 근거가 없어 RR을 직접 넣는다 (사용자 2026-11-11)."""
    k = st.columns(3, gap="small")
    with k[0].container(key="rrsum_now"):
        st.metric("현행 RR", n(o["rr_current"]), help="DP list V열 (허브 DP 파일). – = DP list에 없음")
    with k[1].container(key="rrsum_new"):
        st.metric("제안 RR", "–", help="RR 파일에 없어 제안 RR 미계산")
    with k[2].container(key="rrsum_inv"):
        st.metric("OH", n(o.get("inv")), delta=f"{months_of(o.get('inv'), o['final_rr'])}개월", delta_color="off",
                  delta_arrow="off", help="OH = 최신 재고 파일 CFC5 + SCA3. 재고개월 = OH ÷ 최종 RR")
    _flag_reasons(o, p)
    _decide(o, p, ids, i)
    st.markdown("**상세**")
    tabs = st.tabs(["기본정보", "리뷰 이력"])
    with tabs[0]:
        _basic(o)
    with tabs[1]:
        _history(o)


def _previous(o: dict) -> None:
    """지난 리뷰 한 줄 (지난 기준월의 마지막 결정, 사용자 2026-11-11): '2026-11 · 현행 30 · 제안 40 → 보정 25 · 사유 … · 작성자 날짜'.
    현행·제안은 2026-11-11부터 저장한 줄에만 있다."""
    status = o.get("prev_status")
    if ui.blank(status):
        return
    nums = [f"{label} {n(o.get(k))}" for label, k in (("현행", "prev_rr_current"), ("제안", "prev_proposed_rr"))
            if not ui.blank(o.get(k))]
    result = (f"보정 <b>{n(o.get('prev_adj_rr'))}</b>" if status == R.ADJUSTED and not ui.blank(o.get("prev_adj_rr"))
              else "확인 (제안값 적용)" if status == R.CHECKED else esc(status))
    tail = [f"사유 {esc(o['prev_reason'])}" if not ui.blank(o.get("prev_reason")) else None,
            f"{esc(o.get('prev_by') or '')} {str(o.get('prev_at') or '')[:10]}".strip() or None]
    line = (" · ".join(nums) + " → " if nums else "") + result + "".join(f" · {t}" for t in tail if t)
    with st.container(key="rr_lastrev"):
        st.markdown(f"<span class='rr-prev-h'>지난 리뷰 {esc(o.get('prev_basis'))}</span> {line}", unsafe_allow_html=True)


def _flag_reasons(o: dict, p: dict) -> None:
    """플래그 근거 (한 상자, 컴팩트): 리뷰 플래그마다 배지 + 실제(이 SKU 숫자), 그 밑에 작은 회색 글씨로 기준(규칙).
    참고 플래그는 작은 회색 한 줄씩."""
    pairs = list(zip(o["flags"], o["flag_reasons"]))
    need = [(c, why) for c, why in pairs if E.FLAG[c][2]]
    ref = [(c, why) for c, why in pairs if not E.FLAG[c][2]]
    head = f"<div class='rr-h'>플래그 근거 · 걸린 기준 {len(need)}개" + (f" · 참고 {len(ref)}개" if ref else "") + "</div>"
    rows = [f"{ui.badge(f'{E.FLAG[c][0]} {E.FLAG[c][1]}', FLAG_COLOR[c])} {esc(why)}"
            f"<br><span class='rr-rule'>기준 · {esc(E.flag_rule(c, p))}</span>" for c, why in need]
    if not need:
        rows.append("<span class='rr-rule'>리뷰 플래그 없음 · 제안 RR 자동 확정.</span>")
    rows += [f"<span class='rr-rule'>참고 · {esc(f'{E.FLAG[c][0]} {E.FLAG[c][1]}: {why}')}</span>" for c, why in ref]
    with st.container(key="rr_fbox" if need else "rr_fbox_none"):
        st.markdown(head + "\n\n" + "\n\n".join(rows), unsafe_allow_html=True)


def _decide(o: dict, p: dict, ids: list[str], i: int) -> None:
    """RR 결정: 제안값 적용(확인) · 현행 유지(보정) · 직접 입력(보정). 보정은 사유가 있어야 저장. 보류 = 상태만."""
    nonce = st.session_state.get("rr_form_nonce", 0)
    key = f"{o['item']}_{nonce}"
    has_now = not ui.blank(o["rr_current"])
    has_new = not ui.blank(o.get("proposed_rr"))     # RR 파일에 없는 Base Item은 제안이 없다 → 현행 유지·직접 입력만
    adj0 = None if ui.blank(o.get("adj_rr")) else float(o["adj_rr"])
    if adj0 is None:
        dec0 = PROPOSE if has_new else OWN
    elif has_now and E.xround(adj0) == E.xround(float(o["rr_current"])):
        dec0 = KEEP
    else:
        dec0 = OWN
    opts = ([PROPOSE] if has_new else []) + ([KEEP] if has_now else []) + [OWN]
    label = {PROPOSE: f"공식 제안값 적용 — {n(o['proposed_rr'])}", KEEP: f"현행 유지 — {n(o['rr_current'])}", OWN: "직접 입력"}
    with st.container(key="rr_decide"):
        st.markdown("**RR 결정**")
        dec = st.radio("RR 결정", opts, index=opts.index(dec0), key=f"rr_dec_{key}", format_func=label.get,
                       label_visibility="collapsed")
        adj = None
        if dec == OWN:
            adj = st.number_input("직접 입력 RR", value=int(E.xround(adj0)) if dec0 == OWN and adj0 is not None else None, min_value=0, step=1,
                                  key=f"rr_adj_{key}", placeholder="RR (대/월)")
        elif dec == KEEP:
            adj = float(o["rr_current"])
        reasons = list(p.get("review_reasons") or [])
        r0 = None if ui.blank(o.get("reason")) else str(o["reason"])
        if r0 is None and not has_new:
            r0 = NO_RR_REASON
        if r0 and r0 not in reasons:
            reasons.append(r0)
        reason = st.selectbox("사유 (보정 시 필수)", reasons, index=reasons.index(r0) if r0 else None, key=f"rr_reason_{key}",
                              placeholder="사유 선택 (목록에 없으면 직접 입력)", accept_new_options=True)
        applied = o["proposed_rr"] if dec == PROPOSE else adj
        inv = o.get("inv")
        inv_line = (f"재고개월 {months_of(inv, o['rr_current'])} → {months_of(inv, applied)}개월" if has_now
                    else f"재고개월 {months_of(inv, applied)}개월")
        st.markdown(f"적용 RR **{n(applied)}** · {inv_line}")
        need_value = dec == OWN and adj is None
        need_reason = dec != PROPOSE and ui.blank(reason)
        if need_value:
            st.caption("직접 입력 RR을 입력하십시오.")
        elif need_reason:
            st.caption("현행 유지·직접 입력은 사유 선택 후 저장 가능.")
        b = st.columns([1, 2])
        hold = b[0].button("보류", key=f"rr_hold_{key}", width="stretch", help="미결정: 상태만 '보류' (보정 RR 유지)")
        last = i == len(ids) - 1
        save = b[1].button("저장" if last else "저장 후 다음 SKU", type="primary", key=f"rr_save_{key}", width="stretch",
                           disabled=need_reason or need_value,
                           help="제안값 적용 = '확인', 현행 유지·직접 입력 = '보정'. 팀 공유 폴더 저장, 팀원 화면에 동기화")
        if not ui.blank(o.get("review_by")):
            st.caption(f"최종 저장: {o['review_by']} · {str(o['review_at'])[:16].replace('T', ' ')}")
    if not (save or hold):
        return
    before = [{"item": o["item"], "adj_rr": o.get("adj_rr"), "reason": o.get("reason"), "status": o.get("status")}]
    if save:
        after = [{"item": o["item"], "adj_rr": None if dec == PROPOSE else adj, "reason": reason,
                  "status": R.CHECKED if dec == PROPOSE else R.ADJUSTED}]
    else:
        after = [{"item": o["item"], "adj_rr": o.get("adj_rr"), "reason": reason, "status": R.HOLD}]
    after[0] |= {"rr_current": o.get("rr_current"), "proposed_rr": o.get("proposed_rr")}    # 그때 숫자도 기록 (다음 달 '지난 리뷰')
    if R.changes("", before, after):
        st.session_state.rr_done = service.save_rr_reviews(before, after)
    st.session_state.rr_form_nonce = nonce + 1
    if save and not last:
        st.session_state.rr_pick = ids[i + 1]
    st.rerun()


def trend_chart(o: dict, p: dict, per: dict, months: int = 24, compact: bool = False) -> alt.LayerChart:
    """Sell-in 막대 + Sell-out 선 + 현행·제안 가로선. compact = 패널 위 작은 차트 (6M·3M 평균 선, 프로젝트 점 없음)."""
    m = service.rr_months(o["item"])
    si = m[m["kind"] == "si"].sort_values("month").tail(months)
    months_ = si["month"].tolist()
    hoard = set((p.get("hoarding_months") or {}).get(o.get("product_group") or "", []))
    cap = o["si_cap_base"] * p["cap_blend"]
    si = si.assign(qty=si["qty"].clip(lower=0))
    si["표시"] = np.where(si["month"].isin(hoard), "사재기 제외월",
                        np.where(si["month"].isin(per["si12"]) & (si["qty"] > cap), "캡 넘음", "Sell-in"))
    si["값"] = si["qty"].map(lambda v: f"{E.xround(v):,.0f}")
    lag = per["pos_lag"]
    so = m[m["kind"] == "so"].copy()
    so["실제 달"] = so["month"]
    so["month"] = so["month"].map(lambda x: E.mshift(x, lag))
    so = so[so["month"].isin(months_)]
    so["값"] = so["qty"].map(lambda v: f"{E.xround(v):,.0f}")
    x = alt.X("month:O", sort=months_, title=None, axis=alt.Axis(labelAngle=-45 if not compact else 0,
                                                                 labelExpr="slice(datum.value, 2)" if compact else "datum.value"))
    bars = alt.Chart(si).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
        x=x, y=alt.Y("qty:Q", title=None if compact else "대/월"),
        color=alt.Color("표시:N", scale=alt.Scale(domain=["Sell-in", "캡 넘음", "사재기 제외월"], range=[BAR, BAR_CAP, BAR_EX]),
                        legend=alt.Legend(orient="top", title=None)),
        tooltip=[alt.Tooltip("month:N", title="Sell-in 달"), alt.Tooltip("값:N", title="Sell-in"), alt.Tooltip("표시:N", title="")])
    layers = [bars]
    if o["has_so"] and len(so):
        layers.append(alt.Chart(so).mark_line(point=True, color=SO_LINE, strokeWidth=2).encode(
            x=x, y="qty:Q", tooltip=[alt.Tooltip("실제 달:N", title="Sell-out 달"), alt.Tooltip("값:N", title="Sell-out")]))
    lines = []
    if not ui.blank(o["rr_current"]):
        lines.append({"선": f"현행 R/R {n(o['rr_current'])}", "y": o["rr_current"], "kind": "now"})
    lines.append({"선": f"제안 RR {n(o['proposed_rr'])}", "y": o["proposed_rr"], "kind": "new"})
    rules = pd.DataFrame(lines)
    layers.append(alt.Chart(rules).mark_rule(strokeWidth=2).encode(
        y="y:Q", strokeDash=alt.condition(alt.datum.kind == "now", alt.value([6, 4]), alt.value([1, 0])),
        color=alt.condition(alt.datum.kind == "now", alt.value(NOW), alt.value(NEW)), tooltip=["선:N"]))
    if compact:
        return alt.layer(*layers).properties(height=190)
    # 6M·3M 평균 (캡 후): 그 기간에만 짧은 선
    seg = []
    for label, months__, v in ((f"SI6 {n(o['si6'])}", per["si6"], o["si6"]), (f"SI3 {n(o['si3'])}", per["si3"], o["si3"])):
        seg += [{"month": mm, "y": v, "평균": label} for mm in months__ if mm in months_]
    if o["has_so"]:
        seg += [{"month": E.mshift(mm, lag), "y": o["so6"], "평균": f"SO6 {n(o['so6'])}"} for mm in per["so6"]
                if E.mshift(mm, lag) in months_]
    if seg:
        layers.append(alt.Chart(pd.DataFrame(seg)).mark_line(strokeDash=[2, 2], strokeWidth=1.5, color=SO_LINE).encode(
            x=x, y="y:Q", detail="평균:N", tooltip=["평균:N"]))
    proj = m[m["after_project"].notna() & (m["after_project"] != m["qty"])]
    if len(proj):
        layers.append(alt.Chart(proj.assign(차감후=proj["after_project"])).mark_point(shape="diamond", size=60, color="#7C3AED").encode(
            x=x, y="차감후:Q", tooltip=["month:N", "kind:N", "차감후:Q"]))
    return alt.layer(*layers).properties(height=300)


def _compare_box(o: dict) -> None:
    c = st.columns(2)
    with c[0].container(border=True):
        st.markdown("**현행 (확정)**")
        st.markdown(f"R/R **{n(o['rr_current'])}** · EOH **{n(o['eoh_current'])}**")
        st.caption("DP list V열·BS열 값. 현행 R/R 산출 근거는 파일에 없음.")
    with c[1].container(border=True):
        st.markdown("**제안**")
        st.markdown(f"RR **{n(o['proposed_rr'])}** · EOH **{n(o['proposed_eoh'])}**"
                    + ("" if ui.blank(o["delta"]) else f" · Δ **{E.xround(o['delta']):+,.0f}**"))
        st.caption(E.WHY.get(o["rule"], o["rule"]) + f". EOH: {o['eoh_rule']}")


def _anatomy(o: dict, p: dict, per: dict) -> None:
    st.markdown("**판정 순서** (상단부터 먼저 해당되는 규칙으로 확정. 조건 숫자는 판정값 그대로 소수 1자리)")
    rows = E.steps(o, p)
    st.dataframe(pd.DataFrame({
        "규칙": [r["rule"] for r in rows], "조건": [r["condition"] for r in rows],
        "조건 맞음": ["예" if r["hit"] else "아니오" for r in rows],
        "확정": ["● 확정" if r["applied"] else "" for r in rows], "RR 계산": [r["how"] for r in rows]}),
        hide_index=True, width="stretch")
    m = service.rr_months(o["item"])
    si = m[m["kind"] == "si"].set_index("month")["qty"]
    hoard = set((p.get("hoarding_months") or {}).get(o.get("product_group") or "", []))
    raw6 = np.mean([max(si.get(mm, 0), 0) for mm in per["si6"] if mm not in hoard])
    so = m[m["kind"] == "so"].set_index("month")["qty"]
    raw_so6 = np.mean([max(so.get(mm, 0), 0) for mm in per["so6"]]) if o["has_so"] else np.nan
    r_so = o["so3"] / o["so6"] if o["has_so"] and o["so6"] else None
    r_si = o["si3"] / o["si6"] if o["si6"] else None
    chain = [
        ("SI 12M 캡 기준 (중앙값)", n(o["si_cap_base"]), f"사재기 제외월 제외, 0이면 평균. 캡 = ×{p['cap_blend']} (⑤는 ×{p['cap_si_only']})"),
        ("SI6 캡 전 → 캡 후", f"{n(raw6)} → {n(o['si6'])}", f"{per['si6'][0]} – {per['si6'][-1]}, 음수 0"),
        ("SI6 (⑤ Sell-in만용)", n(o["si6_only"]), f"캡 ×{p['cap_si_only']}"),
        ("SI3", n(o["si3"]), f"{per['si3'][0]} – {per['si3'][-1]}"),
        ("SO 12M 캡 기준 (중앙값)", n(o["so_cap_base"]) if o["has_so"] else "Sell-out 없음", ""),
        ("SO6 캡 전 → 캡 후", f"{n(raw_so6)} → {n(o['so6'])}" if o["has_so"] else "–", f"{per['so6'][0]} – {per['so6'][-1]}"),
        ("SO3", n(o["so3"]), f"{per['so3'][0]} – {per['so3'][-1]}"),
        ("블렌드", n(o["blend"]), f"{p['blend_so_weight']}×SO6 + {1 - p['blend_so_weight']}×SI6"),
        ("× 추세계수", f2(o["trend"]), f"SO3/SO6 {f2(r_so)} · SI3/SI6 {f2(r_si)} 평균, α {p['trend_alpha']}, 1±{p['trend_cap']}"),
        ("× SRA 나이계수", f2(o["age_factor"]), "SRA 없음" if ui.blank(o["sra_years"]) else f"SRA {o['sra_years']:.1f}년"),
        ("× EOP 계수", f2(o["eop_factor"]), "EOP 없음" if ui.blank(o["eop_months"]) else f"EOP까지 {o['eop_months']:.1f}개월"),
        ("= 공식값 v4.1", n(o["formula_v41"]), o["formula"]),
        ("프로젝트 보정 → v4.2", n(o["formula_v42"]),
         f"프로젝트 차감 {n(o['proj_qty'])}대" if not ui.blank(o.get("proj_qty")) and o["proj_qty"] > 0 else "차감 없음 (v4.2 = v4.1)"),
        ("적용 규칙 → 최종 제안 RR", n(o["proposed_rr"]), o["rule"]),
        ("EOH Target", n(o["proposed_eoh"]), f"× {o['eoh_multiple']} ({o['eoh_rule']})"),
    ]
    st.markdown("**계산 순서** (수량은 정수 표시, 계산은 소수 기준)")
    st.dataframe(pd.DataFrame(chain, columns=["단계", "값", "설명"]), hide_index=True, width="stretch")
    if o["has_so"]:
        so_p = p["so_only"]
        st.caption(f"⑨ SO만 검토: SO CV {f2(o['so_cv'])} (≤ {so_p['so_cv_max']}), SI CV {f2(o['si_cv'])} (≥ {so_p['si_cv_min']}), "
                   f"CV 비율 {f2(o['cv_ratio'])} (≥ {so_p['cv_ratio_min']}), 유효월 {o['valid_months']:.0f} (< {so_p['min_valid_months']}), "
                   f"SI/SO 총량비 {f2(o['si_so_ratio'])} ({so_p['ratio_low']} 이상 {so_p['ratio_high']} 미만)"
                   + (f" → {o['v41_judgement']}" if o.get("v41_judgement") else ""))


def _basic(o: dict) -> None:
    def d(v):
        return "–" if ui.blank(v) else pd.Timestamp(v).strftime("%Y-%m-%d")
    pos = service.rr_pos_master(o["item"])
    pos_text = ", ".join(f"{r.pos_sku}" + (f" ({r.kind}, ×{r.qty:g})" if r.kind == "BOM" and not ui.blank(r.qty) else "")
                         for r in pos.itertuples()) or "–"
    facts = [
        ("SKU", o["item"]), ("설명", o.get("item_name")), ("담당", o.get("owner")), ("Product Group", o.get("product_group")),
        ("Series", o.get("series")), ("Model Group", o.get("model_group")), ("Product Type", o.get("product_type")),
        ("SoC", o.get("soc")), ("해상도", o.get("resolution")), ("K/V 그룹", o.get("kv_group") or "–"),
        ("TAA (한국산)", "예" if o.get("taa") else "아니오"), ("PL 상태", o.get("pl_status") or "–"), ("PL Notes", o.get("pl_notes") or "–"),
        ("SRA · EOP · EOL", f"{d(o.get('sra'))} · {d(o.get('eop'))} · {d(o.get('eol'))}"),
        ("ASP", f"${o['asp']:,.2f}" if not ui.blank(o.get("asp")) else "–"),
        ("MSRP", f"${o['msrp']:,.0f}" if not ui.blank(o.get("msrp")) else "–"),
        ("후속 모델 (PriceList EOL)", o.get("replacement") or "–"), ("대체 구모델 (DP list BZ)", o.get("old_model") or "–"),
        ("MOQ / LT", o.get("moq_lt") or "–"), ("PLC", o.get("plc") or "–"),
        ("OH (CFC5 + SCA3)", n(o.get("inv"))), ("POS SKU (POS master)", pos_text),
    ]
    st.dataframe(pd.DataFrame(facts, columns=["항목", "값"]).fillna("–").astype(str), hide_index=True, width="stretch",
                 height=38 + 35 * len(facts))


def _sources(o: dict, p: dict, per: dict, view: pd.DataFrame) -> None:
    hoard = (p.get("hoarding_months") or {}).get(o.get("product_group") or "", [])
    st.markdown(
        f"- Sell-in 12M **{per['si12'][0]} – {per['si12'][-1]}** (SI6 {per['si6'][0]}부터, SI3 {per['si3'][0]}부터), 마지막 Sell-in 달 {per['si_end']}\n"
        f"- Sell-out 12M **{per['so12'][0]} – {per['so12'][-1]}** (POS가 {per['pos_lag']}개월 늦음), 마지막 Sell-out 달 {per['so_end']}"
        + ("" if o["has_so"] else " — **이 SKU는 Sell-out 없음**") + "\n"
        f"- 제외 월: " + (", ".join(hoard) + f" ({o.get('product_group')} 사재기, Sell-in 평균·중앙값에서만 뺌)" if hoard else "없음") + "\n"
        f"- RR 기준일 {per['base_date']} (SRA 나이·EOP 개월 계산)\n"
        f"- 담당·PLC = Item Master, OH = 최신 재고 파일 CFC5 + SCA3 (RR 파일 밖, 허브 데이터)\n"
        f"- 데이터 미연결: ADI 채널재고 보정 · 수동 RR(⑧) · 프로젝트 원천 라인 (값 미생성)")
    if o.get("kv"):
        g = service.rr_table()
        grp = g[g["kv_group"] == o["kv_group"]]
        t = pd.DataFrame({"SKU": grp["item"], "현행 RR": grp["rr_current"].map(n), "제안 RR": grp["proposed_rr"].map(n),
                          "SI6": grp["si6"].map(n), "SO6": grp["so6"].map(n), "규칙": grp["rule"]})
        st.markdown(f"**K/V 그룹 {o['kv_group']}** (TAA로 상호 대체 불가 → SKU별 관리. 합계는 참고용)")
        st.dataframe(t, hide_index=True, width="stretch")
        st.caption(f"그룹 합계 (참고): 현행 {n(grp['rr_current'].sum())} · 제안 {n(grp['proposed_rr'].sum())}")
    related = [x for x in (o.get("old_model"), o.get("replacement")) if isinstance(x, str) and x.strip()]
    if related:
        g = service.rr_table()
        rel = g[g["item"].isin(related) | g["item"].str.split("/").str[0].isin([r.split("/")[0] for r in related])]
        if len(rel):
            st.markdown("**대체·후속 모델**")
            st.dataframe(pd.DataFrame({"SKU": rel["item"], "현행 RR": rel["rr_current"].map(n), "제안 RR": rel["proposed_rr"].map(n),
                                       "규칙": rel["rule"]}), hide_index=True, width="stretch")
    _history(o)


def _history(o: dict) -> None:
    h = service.rr_review_history(o["item"])
    if not len(h):
        if o.get("no_rr"):
            st.caption("리뷰 이력 없음.")
        return
    st.markdown("**리뷰 이력**")
    st.dataframe(pd.DataFrame({"일시": h["at"].str[:16].str.replace("T", " "), "작성자": h["by"], "기준월": h["basis"],
                               "현행": h["rr_current"].map(n), "제안": h["proposed_rr"].map(n),
                               "보정 RR": h["adj_rr"].map(n), "사유": h["reason"], "상태": h["status"]}),
                 hide_index=True, width="stretch")
    st.caption("현행·제안 = 저장 시점 값 (2026-11-11부터 기록). 모든 기준월, 최신순.")
