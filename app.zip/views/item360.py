"""Item 360: 아이템 하나의 정보를 한 화면에. 위쪽 = 검색·◀ ▶, 아래 상세는 item_panel.detail ('내 아이템' 나눠 보기 오른쪽과 같다)."""

import streamlit as st

import item_panel
import ui
from hub import service

if service.master() is None:
    st.title("Item 360")
    st.error("Item Master가 없습니다. '데이터 현황'에서 파일 상태를 확인하십시오.")
    st.stop()

# 다른 화면(내 아이템, Item Master, 최근 본 아이템)에서 아이템을 골라 넘어온 경우
preset = st.session_state.pop("open_item", None)
if preset:
    st.session_state.q = preset


def _go(item: str) -> None:
    st.session_state.q = item


# ---- 맨 위: 목록에서 왔으면 ◀ ▶ 로 넘겨 보기 --------------------------------
nav = st.session_state.get("nav_list") or []
current = st.session_state.get("q")
top = st.columns([3, 1, 0.8, 1, 1.4], vertical_alignment="center")
top[0].title("Item 360")
if current in nav and len(nav) > 1:
    i = nav.index(current)
    top[1].button("◀ 이전", disabled=i == 0, on_click=_go, args=(nav[max(i - 1, 0)],), width="stretch")
    top[2].markdown(f"<div style='text-align:center'>{i + 1} / {len(nav)}</div>", unsafe_allow_html=True)
    top[3].button("다음 ▶", disabled=i == len(nav) - 1, on_click=_go, args=(nav[min(i + 1, len(nav) - 1)],),
                  width="stretch")
    top[4].page_link("views/worklist.py", label="담당 아이템 목록", icon=":material/arrow_back:")

c1, c2 = st.columns([4, 1], vertical_alignment="bottom")
query = c1.text_input("Item·모델명·품명·POS SKU 검색", key="q", placeholder="예: PNM-9085RQZ1, ace6020, WAVE-PRO-04")
active_only = c2.toggle("ACTIVE·PLANNED만", value=False)

if not query:
    st.caption("대소문자·기호('-', '/') 무시 검색. 담당 Item 전체 조회는 '담당 아이템' 화면.")
    st.stop()

results = service.search(query, limit=30, active_only=active_only)
if results.empty:
    st.info("검색 결과가 없습니다.")
    st.stop()

selected = results.iloc[0]["item"]  # 기본: 가장 잘 맞는 아이템
exact = results.iloc[0]["match"] == "아이템 일치"
with st.expander(f"찾은 아이템 {len(results)}개" + (" — 다른 Item 검색" if exact else ""), expanded=not exact):
    event = st.dataframe(
        ui.table(results, ["item", "item_name", "product_group", "plc_status", "in_dp_list", "is_local", "match"]),
        hide_index=True, on_select="rerun", selection_mode=ui.CLICK_MODES, key="results",
        height=min(38 + 35 * len(results), 280),
    )
    row = ui.clicked_row(event, ui.ITEM)
    if row is not None and row < len(results):
        selected = results.iloc[row]["item"]

item_panel.detail(selected)
