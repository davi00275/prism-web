"""내 아이템: 담당 아이템을 주의 신호로 거르고 하나씩 본다.

보는 방식 (2026-11-09, docs/ui-design.md 3장 ④):
  나눠 보기 (기본)  왼쪽 목록(아이템·주의 신호·재고·커버·R/R) + 오른쪽 Item 360 (item_panel.detail). 누르면 오른쪽에,
                    ◀ ▶로 목록 순서대로 넘긴다 (메일 앱처럼)
  표               전처럼 넓은 표 (보여줄 열·자세히). 행을 누르면 Item 360 화면으로
열·주의 신호는 hub/metrics.py의 METRICS·ALERTS에서 온다. 새 데이터를 붙이면 여기 자동으로 나온다.
"""

import streamlit as st

import item_panel
import ui
from hub import metrics as M, service

SPLIT = ["item", "alerts", "inv_unrestricted", "cover_months", "rr"]   # 나눠 보기 왼쪽 목록 열

top = st.columns([3, 1.3, 0.9], vertical_alignment="bottom")
top[0].title("담당 아이템")
how = top[1].segmented_control("보는 방식", ["나눠 보기", "표"], default="나눠 보기", key="wl_view", required=True,
                               label_visibility="collapsed")
csv_slot = top[2].empty()   # CSV로 받기: 거른 목록이 정해진 뒤에 채운다

if service.metrics() is None:
    st.error("Item 지표가 없습니다. '데이터 현황'에서 파일 상태를 확인하십시오.")
    st.stop()

options = ["전체"] + service.owners()
if "wl_owner" not in st.session_state:
    st.session_state.wl_owner = service.current_owner() or "전체"
c = st.columns([2, 3], vertical_alignment="bottom")
owner = c[0].selectbox("담당", options, key="wl_owner", help="PC의 Windows 사용자 이름이 담당자 목록에 있으면 자동 선택")
text = c[1].text_input("아이템·모델로 좁히기", key="wl_text", placeholder="예: PNM, XNV-6, ace60")

# DP 판정: 기본은 'DP 대상'. 제외된 아이템도 이유와 함께 볼 수 있다
everyone = service.worklist(None if owner == "전체" else owner, None, text)
status_counts = everyone["dp_status"].value_counts()
status = st.segmented_control(
    "DP 판정", M.DP_STATUSES + ["전체"], key="wl_status", default=M.DP_TARGET,
    format_func=lambda s: f"{s} {len(everyone) if s == '전체' else int(status_counts.get(s, 0)):,}",
    help="DP 대상 = Base Item 등록 Item. 신규 Item은 'Base Item' 화면에서 등록",
)
base = everyone if status in (None, "전체") else everyone[everyone["dp_status"] == status]
counts = {a.key: int(base[f"alert_{a.key}"].sum()) for a in M.ALERTS}
selected = st.pills(
    "주의 신호 필터 (복수 선택 시 하나 이상 해당 Item)",
    [a.key for a in M.ALERTS], selection_mode="multi", key="wl_alerts",
    format_func=lambda k: f"{M.ALERT_BY_KEY[k].label} {counts[k]}",
)
view = base if not selected else base[base[[f"alert_{k}" for k in selected]].any(axis=1)]
if selected:
    st.caption(" · ".join(f"**{M.ALERT_BY_KEY[k].label}**: {M.ALERT_BY_KEY[k].help}" for k in selected))

k = st.columns(5)
k[0].metric("아이템", f"{len(view):,}")
k[1].metric("OH", ui.fmt(view["inv_unrestricted"].sum()))
k[2].metric("당월 GI", ui.fmt(view["gi_qty"].sum()))
k[3].metric("Open SO", ui.fmt(view["open_so_qty"].sum()))
k[4].metric("ADI 가용", ui.fmt(view["adi_available_qty"].sum()))

if how == "표":
    g = st.columns([5, 1], vertical_alignment="bottom")
    groups = g[0].pills("보여줄 열", M.GROUPS, selection_mode="multi", default=M.GROUPS, key="wl_groups")
    detail = g[1].toggle("상세", value=False, key="wl_detail", help="해제 시 그룹별 주요 열만 표시")
    columns = ["item", "alerts"] + [m.key for m in M.METRICS if m.group in (groups or []) and (detail or m.brief)]
else:
    columns = SPLIT


def _go(item: str) -> None:
    st.session_state.wl_item = item


if view.empty:
    st.info("조건에 맞는 Item이 없습니다.")
elif how == "표":
    ui.item_table(view, columns, key="wl")
    st.caption("아이템 칸 선택 시 Item 360 이동. Item 360에서 ◀ ▶로 목록 순서대로 조회. "
               "열 이름 클릭 시 정렬.")
else:
    # ---- 나눠 보기: 왼쪽 목록 + 오른쪽 Item 360 ------------------------------------------------
    nav = view["item"].tolist()
    left, right = st.columns([1.25, 1.75], gap="medium")
    with left:
        # 거르기가 바뀌면 표 key도 바뀌어 고른 칸이 풀린다. 고른 칸이 그대로면(◀ ▶로 넘긴 뒤) 오른쪽을 건드리지 않는다
        table_key = f"wl_split_{abs(hash((owner, text, status, tuple(selected or []))))}"
        shown = view[SPLIT].rename(columns={c: ui.label_of(c) for c in SPLIT})
        event = st.dataframe(shown, hide_index=True, width="stretch", height=760, on_select="rerun",
                             selection_mode=ui.CLICK_MODES, key=table_key, column_config=ui.column_config(SPLIT))
        row = ui.clicked_row(event, ui.ITEM)     # 아이템 칸을 눌렀을 때만 (사용자 2026-11-11)
        if row != st.session_state.get(f"{table_key}_last"):
            st.session_state[f"{table_key}_last"] = row
            if row is not None and row < len(nav):
                st.session_state.wl_item = nav[row]
        st.caption(f"{len(nav):,}개 · 아이템 칸 선택 시 우측 상세. 열 이름 클릭 시 정렬.")
    if st.session_state.get("wl_item") not in nav:
        st.session_state.wl_item = nav[0]
    item = st.session_state.wl_item
    with right, st.container(height=860, border=True):
        i = nav.index(item)
        c = st.columns([1, 1.1, 1, 2.4], vertical_alignment="center")
        c[0].button("◀", key="wl_prev", disabled=i == 0, width="stretch", help="목록의 이전 아이템",
                    on_click=_go, args=(nav[max(i - 1, 0)],))
        c[1].markdown(f"<div style='text-align:center'>{i + 1} / {len(nav)}</div>", unsafe_allow_html=True)
        c[2].button("▶", key="wl_next", disabled=i >= len(nav) - 1, width="stretch", help="목록의 다음 아이템",
                    on_click=_go, args=(nav[min(i + 1, len(nav) - 1)],))
        if c[3].button("Item 360에서 크게 보기", key="wl_open", icon=":material/open_in_new:", width="stretch"):
            ui.open_item(item, nav)
        item_panel.detail(item, compact=True)

if not view.empty:
    # 표 = 보이는 열 그대로. 나눠 보기 = 표의 기본 열 (왼쪽 목록 5개 열만으로는 쓸모가 적어서)
    out = columns if how == "표" else ["item", "alerts"] + [m.key for m in M.METRICS if m.brief]
    export = view[[c for c in out if c in view.columns]].copy()
    export["alerts"] = export["alerts"].map(lambda x: ", ".join(x))
    csv_slot.download_button("CSV 다운로드", export.rename(columns={c: ui.label_of(c) for c in export.columns})
                             .to_csv(index=False).encode("utf-8-sig"), file_name="my_items.csv", mime="text/csv",
                             icon=":material/download:", width="stretch")
