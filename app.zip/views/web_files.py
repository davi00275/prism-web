"""'웹 데이터': PC 앱과 웹 버전(링크)이 데이터를 주고받는 화면 (hub/bundle.py, hub/web.py, docs/web.md).

PC  : 웹용 PC 데이터 내보내기 (최신 숫자·아이템·입력/확정 기록 zip) · 웹에서 쓴 입력 가져오기 (공유 폴더에 합침)
웹  : PC 데이터 가져오기 (갈아끼우기) · 원천 엑셀 업로드 · 내 입력 내보내기
묶음에는 회사 데이터가 있어서 GitHub에 올리지 않는다. 팀 안에서 OneDrive로 주고받는다.
"""

import pandas as pd
import streamlit as st

from hub import bundle, config, service, store, web

st.title("웹 데이터")
n = st.session_state.get("web_up_n", 0)     # 업로드 칸을 비울 때 key 번호를 올린다


def _done(msgs: list[tuple[str, bool]], refresh: bool) -> None:
    if refresh:
        with st.spinner("반영 중…"):
            st.session_state.scan_results = service.refresh()
    st.session_state.web_up_result = msgs
    st.session_state.web_up_n = n + 1
    st.rerun()


def _merged_text(m: dict) -> str:
    parts = [f"추가 {len(m['added'])}", f"병합 {len(m['merged'])}", f"교체 {len(m['replaced'])}", f"동일 {m['same']}"]
    if m["skipped"]:
        parts.append(f"제외 {len(m['skipped'])} (타 담당자 기록)")
    return " · ".join(parts)


for text, ok in st.session_state.pop("web_up_result", []):
    (st.success if ok else st.error)(text, icon=":material/check:" if ok else ":material/error:")


# ==== PC 앱 ======================================================================
if not web.is_web():
    st.caption("- 웹 버전(링크)과 데이터 교환\n"
               "- 내보낸 파일에 회사 데이터 포함 → GitHub 업로드 금지, 팀 OneDrive로 전달")
    left, right = st.columns(2, gap="large")
    with left:
        st.subheader("웹용 PC 데이터 내보내기", anchor=False)
        st.caption("- 최신 계산 결과 · 원천별 최신 데이터 · 입력/확정 기록 (원천 엑셀 미포함)\n"
                   "- 웹 '웹 데이터' → 'PC 데이터 가져오기'에 업로드 시 이 PC와 같은 숫자로 교체")
        if st.button("내보내기 파일 생성", icon=":material/inventory:", key="web_export_pc"):
            data, meta = bundle.export_pc()
            st.session_state.web_export = (data, meta)
        got = st.session_state.get("web_export")
        if got and got[1]["kind"] == bundle.KIND_PC:
            data, meta = got
            st.download_button(f"다운로드 · {len(data) / 1024 / 1024:.1f} MB", data, file_name=bundle.file_name(meta),
                               mime="application/zip", type="primary", icon=":material/download:")
            st.dataframe(pd.DataFrame([{"원천": s["name"], "파일": s["file"], "날짜": (s["file_date"] or "")[:10]}
                                       for s in meta["sources"].values()]), hide_index=True, width="stretch")
            st.caption(f"계산 결과 {meta['cache']}개 · 입력/확정 기록 파일 {meta['inputs']}개 · {meta['made_at'][:16]}")
    with right:
        st.subheader("웹 입력 가져오기", anchor=False)
        st.caption("- 웹 '내 입력 내보내기' 파일 → 팀 공유 폴더 입력에 병합 (본인 기록만)\n"
                   "- 기존 기록 유지: 수정 기록은 합치고, DP 확정은 더 최근 확정으로")
        with st.form("web_merge"):
            f = st.file_uploader("웹 입력 파일 (zip)", type=["zip"], key=f"web_merge_{n}")
            if st.form_submit_button("가져오기", type="primary", icon=":material/upload:") and f:
                try:
                    r = bundle.merge_inputs(f.getvalue())
                    _done([(f"{f.name} → {_merged_text(r['merged'])}", True)], refresh=True)
                except ValueError as e:
                    _done([(f"{f.name} → {e}", False)], refresh=False)
    st.stop()


# ==== 웹 버전 =====================================================================
st.caption("- 웹 버전은 PC 폴더 조회 불가 → PC 데이터 가져오기 또는 원천 파일 직접 업로드\n"
           "- 데이터는 이 브라우저에만 저장 (서버·GitHub 전송 없음). 다른 PC·브라우저는 별도 업로드\n"
           "- 웹에서 수정·확정한 기록은 '내 입력 내보내기' → PC 앱에서 가져오기 시 팀 공유")

left, right = st.columns([1.3, 1], gap="large")
with left:
    st.subheader("PC 데이터 가져오기", anchor=False)
    st.caption("PC 앱 '데이터 → 웹 데이터'에서 내보낸 파일. 계산 결과·원천 데이터는 교체, 입력/확정 기록은 병합.")
    with st.form("web_import"):
        f = st.file_uploader("PC 데이터 파일 (zip)", type=["zip"], key=f"web_import_{n}")
        if st.form_submit_button("가져오기", type="primary", icon=":material/download:") and f:
            try:
                r = bundle.import_bundle(f.getvalue())
                note = "" if r["same_settings"] else " · 설정 차이로 재계산"
                _done([(f"{f.name} → PC 데이터 반영 ({r['by']}, {r['made_at'][:16].replace('T', ' ')}) · "
                        f"원천 {len(r['sources'])}개 · 입력 {_merged_text(r['merged'])}{note}", True)], refresh=True)
            except ValueError as e:
                _done([(f"{f.name} → {e}", False)], refresh=False)

    st.subheader("원천 파일 업로드", anchor=False)
    st.caption("PC 데이터 이후 새 원천 파일(재고·주문 등)만 업로드. 파일 이름으로 원천 자동 판별.")

    def _save(pairs: list) -> None:
        """(원천 id 또는 None, 올린 파일) → 저장 후 다시 읽기. None이면 파일 이름으로 원천을 찾는다."""
        out = []
        for sid, up in pairs:
            if sid is None:
                ids = web.match(up.name)
                if len(ids) != 1:
                    out.append((f"{up.name} → " + ("원천 판별 불가 · 파일 이름 확인" if not ids else "원천 중복"), False))
                    continue
                sid = ids[0]
            path, msg = web.save(sid, up.name, up.getvalue())
            out.append((f"{up.name} → {config.source(sid)['name']} · {msg}", path is not None))
        _done(out, refresh=any(ok for _, ok in out))

    with st.form("web_up"):
        ups = st.file_uploader("원천 파일 (복수 선택 가능)", type=web.EXCEL, accept_multiple_files=True,
                               key=f"web_up_{n}")
        if st.form_submit_button("업로드", icon=":material/upload_file:") and ups:
            _save([(None, u) for u in ups])
    # 이름 규칙이 '*.xlsx'인 원천은 이름으로 구분이 안 돼서 따로 올린다
    for s in [s for s in web.sources() if web.generic(s)]:
        with st.form(f"web_one_{s['id']}"):
            up = st.file_uploader(s["name"], type=web.EXCEL, key=f"web_one_{s['id']}_{n}", help=s["description"])
            if st.form_submit_button(f"{s['name']} 업로드", icon=":material/upload_file:") and up:
                _save([(s["id"], up)])
    st.page_link("views/inbound.py", label="Sync Plan · In-transit · GR은 Inbound 화면에서 업로드",
                 icon=":material/local_shipping:")

with right:
    st.subheader("사용 중인 데이터", anchor=False)
    rows = []
    for s in web.sources():
        e = store.latest_entry(s["id"]) or {}
        rows.append({"원천": s["name"], "파일": e.get("file") or "—", "날짜": (e.get("file_date") or "")[:10],
                     "출처": "업로드" if web.stored(s["id"]) else "PC 데이터" if e else "—"})
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")

    st.subheader("내 입력 내보내기", anchor=False)
    st.caption("웹에서 수정·확정한 본인 기록 → PC 앱 '웹 데이터 → 웹 입력 가져오기'에 업로드 시 팀 공유 폴더에 반영.")
    if st.button("내보내기 파일 생성", icon=":material/inventory:", key="web_export_inputs"):
        st.session_state.web_export = bundle.export_inputs()
    got = st.session_state.get("web_export")
    if got and got[1]["kind"] == bundle.KIND_INPUTS:
        data, meta = got
        if meta["files"]:
            st.download_button(f"다운로드 · 파일 {len(meta['files'])}개", data, file_name=bundle.file_name(meta),
                               mime="application/zip", type="primary", icon=":material/download:")
        else:
            st.info("내보낼 본인 기록이 없습니다.")

    with st.expander("브라우저 저장 데이터 삭제"):
        st.caption("업로드한 원천 파일과 계산 결과를 이 브라우저에서 삭제합니다. 입력·확정 기록은 유지됩니다.")
        if st.button("삭제", icon=":material/delete:", key="web_clear"):
            web.clear()
            _done([("브라우저 저장 데이터 삭제", True)], refresh=True)
