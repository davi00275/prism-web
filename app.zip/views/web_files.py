"""웹 버전 '원천 파일': 원천 엑셀을 브라우저에 업로드한다 (hub/web.py, docs/web.md).
PC 버전은 폴더(samples·팀 공유 폴더)에서 바로 읽어서 이 화면이 메뉴에 없다."""

import pandas as pd
import streamlit as st

from hub import config, service, web

st.title("원천 파일")
if not web.is_web():
    st.info("PC 버전은 원천 파일을 폴더(samples·팀 공유 폴더)에서 바로 읽습니다.")
    st.stop()

st.caption("- 웹 버전은 PC 폴더 조회 불가 → 원천 파일 직접 업로드\n"
           "- 파일은 이 브라우저에만 저장 (서버·GitHub 전송 없음). 다른 PC·브라우저는 별도 업로드\n"
           "- 원천별 최신 파일 1개만 사용. 새 파일 업로드 시 이전 파일 삭제\n"
           "- Decrypt된 파일만 업로드 가능 (DRM 잠긴 파일은 읽기 불가)")

n = st.session_state.get("web_up_n", 0)


def _save(pairs: list) -> None:
    """(원천 id 또는 None, 올린 파일) → 저장 후 다시 읽기. None이면 파일 이름으로 원천을 찾는다."""
    out = []
    for sid, f in pairs:
        if sid is None:
            ids = web.match(f.name)
            if len(ids) != 1:
                out.append((f.name, "원천 판별 불가 · 파일 이름 확인" if not ids else "원천 중복", False))
                continue
            sid = ids[0]
        path, msg = web.save(sid, f.name, f.getvalue())
        out.append((f.name, f"{config.source(sid)['name']} · {msg}", path is not None))
    if any(ok for *_, ok in out):
        with st.spinner("반영 중… (첫 반영은 1~2분 소요)"):
            st.session_state.scan_results = service.refresh()
    st.session_state.web_up_result = out
    st.session_state.web_up_n = n + 1      # 업로드 칸을 비운다 (새 key)
    st.rerun()


for name, msg, ok in st.session_state.pop("web_up_result", []):
    (st.success if ok else st.error)(f"{name} → {msg}", icon=":material/check:" if ok else ":material/error:")

left, right = st.columns([1.3, 1], gap="large")
with left:
    st.subheader("업로드", anchor=False)
    with st.form("web_up"):
        ups = st.file_uploader("원천 파일 (복수 선택 가능 · 파일 이름으로 원천 자동 판별)", type=web.EXCEL,
                               accept_multiple_files=True, key=f"web_up_{n}")
        if st.form_submit_button("업로드", type="primary", icon=":material/upload_file:") and ups:
            _save([(None, f) for f in ups])
    # 이름 규칙이 '*.xlsx'인 원천은 이름으로 구분이 안 돼서 따로 올린다
    for s in [s for s in web.sources() if web.generic(s)]:
        with st.form(f"web_one_{s['id']}"):
            f = st.file_uploader(s["name"], type=web.EXCEL, key=f"web_one_{s['id']}_{n}", help=s["description"])
            if st.form_submit_button(f"{s['name']} 업로드", icon=":material/upload_file:") and f:
                _save([(s["id"], f)])
    st.page_link("views/inbound.py", label="Sync Plan · In-transit · GR은 Inbound 화면에서 업로드",
                 icon=":material/local_shipping:")

with right:
    st.subheader("저장된 파일", anchor=False)
    rows = []
    for s in web.sources():
        p = web.stored(s["id"])
        rows.append({"원천": s["name"], "파일": p.name if p else "—", "파일 이름 규칙": s["pattern"]})
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    st.caption("입력·확정 기록도 이 브라우저에만 저장 (팀원 화면 미표시).")
    with st.expander("브라우저 저장 데이터 삭제"):
        st.caption("업로드한 원천 파일과 계산 결과를 이 브라우저에서 삭제합니다. 입력·확정 기록은 유지됩니다.")
        if st.button("삭제", icon=":material/delete:", key="web_clear"):
            web.clear()
            st.session_state.scan_results = service.refresh()
            st.rerun()
