"""Inbound: 주차별 입고 예정 (사용자 2026-11-06, docs/inbound.md).

화요일 Sync Plan이 베이스이고, 그 뒤 입고(GR)를 뺀 수량이다.
계산은 겹치지 않는 세 칸 (hub/inbound.py): In-transit = 선적 완료·운송 중, Air·Vessel 미선적 = 아직 안 떠난 계획.
In-transit은 실제 운송수단으로 다시 나눈다 (it_air·it_vessel).
보기 (사용자 2026-11-11):
  전체 = 합계   Air = Air 전체 (미선적 + In-transit)   Vessel = Vessel 전체 (미선적 + In-transit)
  In-transit = In-transit만, 주차(월) × Air·Vessel 두 줄 머리글 (사용자 시안)
이 화면의 월별 합계가 그대로 DP 계산의 입고다 ('월별'에서 같은지 보여준다).

구성 (사용자 2026-11-09 요청, SAP Fiori 분석 화면을 참고한 Claude 제안. docs/inbound.md 5장):
  제목 줄 = 제목 · 담당(전체가 기본, 아래 전부에 걸린다) · [파일 업로드] (자주 안 하는 일이라 작게)
  그 아래 한 줄 = 기준 파일 (오래되면 주황)
  KPI 4개 → 확인 필요 (있을 때만) → 상세 (주차별·월별·Sync 비교·GR 이력)
  Item 검색은 그 표 바로 위. 주차·월은 수량이 0이어도 칸이 있다 (In-transit 보기는 마지막 In-transit 주차까지).
파일 업로드:
  Sync Plan 업로드·In-transit 업로드 = 고르면 바로 그 파일이 기준이 된다
  GR 차감 = GR 파일을 고르면 SN No·SN Qty·차감 주차를 확인 창에 보여주고, [차감]을 눌러야 빠진다
화면 문구는 실무 대시보드 어투 (사용자 2026-11-11, docs/ui-design.md 6장).
"""

from datetime import datetime, timedelta
from html import escape

import altair as alt
import pandas as pd
import streamlit as st

import ui
from hub import codes, dp_engine as E, inbound as IB, service

VIEWS = ["전체", "Air", "Vessel", "In-transit"]
MODES = {"it_air": "Air", "it_vessel": "Vessel"}
# 차트 칸: Air·Vessel마다 In-transit(진하게)과 미선적(옅게). 밝기가 서로 달라서 색을 못 구분해도 칸이 나뉜다 (docs/ui-design.md 4장).
# 칸마다 고정 (거르기를 바꿔도 색이 안 바뀐다)
SEGMENTS = {"it_air": "Air · In-transit", "air": "Air · 미선적", "it_vessel": "Vessel · In-transit", "vessel": "Vessel · 미선적"}
COLORS = ["#F37321", "#F8B98A", "#3A4556", "#A9B4C2"]
wlabel = lambda w: f"W{w[-2:]}"
day = lambda d: pd.Timestamp(d).strftime("%m/%d")
BUTTON = {"sync": "Sync Plan 업로드", "transit": "In-transit 업로드", "gr": "GR 차감", "old": "이전 Sync Plan 선택"}

STYLE = """<style>
[data-testid="stMainBlockContainer"] {padding-top: 2.5rem;}
.ib-status {font-size: .85rem; opacity: .75; margin-top: -.6rem;}
.ib-status b {font-weight: 600;}
.ib-old {color: #8F5B00;}
.ib-head {font-size: 1.05rem; font-weight: 600; margin: .4rem 0 0;}
.ib-label {font-size: .8rem; opacity: .62;}
.ib-value {font-size: 1rem; font-weight: 600; font-variant-numeric: tabular-nums;}
.ib-note {font-size: .78rem; opacity: .62;}
/* 업로드 칸을 버튼 하나로 */
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzone"] {background: none; border: 0; padding: 0; min-height: 0; display: block;}
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzone"] > div:not(:has(button)),
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzoneInstructions"] {display: none;}
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzone"] button {width: 100%; font-size: 0; gap: 0; border-radius: 10px; white-space: nowrap;}
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzone"] button > * {display: none;}
[class*="st-key-ib_up_"] [data-testid="stFileUploaderDropzone"] button::after {font-size: .875rem; line-height: 1.6;}
""" + "".join(f'.st-key-ib_up_{k} [data-testid="stFileUploaderDropzone"] button::after {{content: "{v}";}}\n'
              for k, v in BUTTON.items()) + """
/* KPI */
[class*="st-key-ib_kpis"] [data-testid="stMetricValue"] {font-size: 1.9rem; font-weight: 600; font-variant-numeric: tabular-nums;}
[class*="st-key-ib_kpis"] [data-testid="stMetricLabel"] {opacity: .62;}
</style>"""


def picker_key(name: str) -> str:
    return f"ib_{name}_{st.session_state.get('ib_nonce', 0)}"


def clear_pickers() -> None:
    """고른 파일을 비운다 (번호가 바뀌면 새 칸이 된다)."""
    st.session_state.ib_nonce = st.session_state.get("ib_nonce", 0) + 1
    st.session_state.pop("ib_preview", None)


def uploaded(by, at) -> str:
    if not at:
        return "미업로드"
    t = datetime.fromisoformat(at)
    days = (today - t.date()).days
    return f"{'오늘' if days == 0 else '어제' if days == 1 else f'{t:%m/%d}'} {t:%H:%M} · {by}"


def update(file, action) -> None:
    """파일을 고르면 바로 적용한다 (Sync Plan·In-transit)."""
    with st.spinner(f"{file.name} 반영 중…"):
        try:
            st.session_state.ib_done = action(file.name, file.getvalue())
        except service.InboundFileError as e:
            st.session_state.ib_error = str(e)
    clear_pickers()
    st.rerun()


def picker(name: str, multiple: bool = False, disabled: bool = False):
    """버튼처럼 보이는 파일 고르기 (누르면 파일 선택 창)."""
    with st.container(key=f"ib_up_{name}"):
        return st.file_uploader(BUTTON[name], type=["xlsx"], key=picker_key(name), accept_multiple_files=multiple,
                                disabled=disabled, label_visibility="collapsed")


def search_box(key: str = "ib_text") -> str:
    return st.text_input("Item 검색", key=key, placeholder="Item 검색 (예: PNM, XNV-6)", label_visibility="collapsed",
                         icon=":material/search:")


def by_text(t: pd.DataFrame, text: str) -> pd.DataFrame:
    return t[t["item"].map(codes.norm).str.contains(codes.norm(text), regex=False)] if text.strip() else t


def amount(t: pd.DataFrame, show: str) -> pd.Series:
    """보기별 수량. Air·Vessel = 미선적 + In-transit (사용자 2026-11-11)."""
    return {"전체": lambda: t["total"], "Air": lambda: t["air"] + t["it_air"], "Vessel": lambda: t["vessel"] + t["it_vessel"],
            "In-transit": lambda: t["in_transit"]}[show]()


def totals(g: pd.DataFrame) -> pd.DataFrame:
    """주차(월)별 합계 줄: 전체 · Air · Vessel (In-transit 포함) · In-transit을 Air·Vessel로."""
    return pd.DataFrame({"전체": g["total"], "Air": g["air"] + g["it_air"], "Vessel": g["vessel"] + g["it_vessel"],
                         "In-transit · Air": g["it_air"], "In-transit · Vessel": g["it_vessel"]}).T


@st.dialog("GR 차감 확인", width="large", dismissible=False)
def confirm_gr(p: dict) -> None:
    lines, by_sn = p["lines"], p["by_sn"]
    st.caption(", ".join(p["files"]))
    if lines.empty:
        st.info("차감 대상이 없습니다.", icon=":material/info:")
    else:
        c = st.columns(3)
        c[0].metric("SN", f"{len(by_sn):,}건")
        c[1].metric("Item", f"{lines['item'].nunique():,}개")
        c[2].metric("SN Qty 합계", f"{lines['qty'].sum():,.0f}")
        table = by_sn.assign(gr_date=by_sn["gr_date"].dt.strftime("%m/%d")).fillna("–").rename(columns={
            "sn_no": "SN No", "gr_date": "GR Date", "bl_no": "BL", "container": "Container", "items": "Item 수",
            "qty": "SN Qty", "weeks": "차감 주차", "found": "주차 기준"})
        st.dataframe(table, hide_index=True, width="stretch",
                     column_config={"SN Qty": st.column_config.NumberColumn(format="localized")})
        st.caption("차감 주차 = 해당 컨테이너의 도착 예정 주차(SCM ETA). 매칭 순서: In-transit Item·BL·PO·수량 (기존 매크로 조건) "
                   "→ SN No·컨테이너 → GR Date 주차.")
        over = p["by_item"][p["by_item"]["over"] > 0]
        if len(over):
            st.warning("잔여 Sync Plan 초과 차감 Item: "
                       + ", ".join(f"{r.item} {r.over:,.0f}" for r in over.itertuples()), icon=":material/warning:")
        with st.expander(f"Item별 수량 ({len(p['by_item']):,}개)"):
            st.dataframe(p["by_item"][["item", "qty", "plan_left"]].rename(columns={
                "item": "Item", "qty": "차감 수량", "plan_left": "잔여 계획"}), hide_index=True, width="stretch")
    for key, text in (("already", "기차감 건 제외"), ("before_plan", f"{p['since']} 이전 입고 제외 (Sync Plan 기반영)"),
                      ("not_done", "GR Status ≠ C 제외")):
        if len(p[key]):
            st.caption(f":orange[{len(p[key])}줄 · {p[key]['qty'].sum():,.0f}: {text}]")
    c = st.columns(2)
    if c[0].button("차감", type="primary", width="stretch", disabled=lines.empty, icon=":material/remove:"):
        with st.spinner("GR 차감 및 재계산 중…"):
            st.session_state.ib_done = service.apply_gr(p)
        clear_pickers()
        st.rerun()
    if c[1].button("취소", width="stretch"):
        clear_pickers()
        st.rerun()


# ---- 제목 줄: 제목 · 담당 · 파일 업로드 ------------------------------------------
st.html(STYLE)
today = service.today()
this_week = IB.week_of(today)
next_week = IB.week_of(today + timedelta(days=7))
monday = IB.week_monday(this_week)
meta = service.inbound_meta()
has_plan = bool(meta.get("plan_version"))
status = service.inbound_status()

if "ib_owner" not in st.session_state:
    st.session_state.ib_owner = "전체"
head = st.columns([1, 1], vertical_alignment="bottom")
head[0].title("Inbound")
right = head[1].container(horizontal=True, horizontal_alignment="right", vertical_alignment="bottom")
owner = right.selectbox("담당", ["전체"] + service.owners(), key="ib_owner", width=190, label_visibility="collapsed",
                        format_func=lambda o: f"담당 · {o}")
picked = None
with right.popover("파일 업로드", icon=":material/upload_file:", width="content"):
    for s, name in zip(status, ("sync", "transit", "gr")):
        st.html(f'<div class="ib-label">{escape(s["name"])}</div>'
                f'<div class="ib-value">{escape(s["value"])} <span class="ib-note">{escape(s["note"])}</span></div>'
                f'<div class="ib-note">{escape(uploaded(s["by"], s["at"]))}</div>')
        if name == "sync":
            file = picker("sync")
            if file:
                update(file, service.update_sync_plan)
        elif name == "transit":
            file = picker("transit")
            if file:
                update(file, service.update_in_transit)
        else:
            picked = picker("gr", multiple=True, disabled=not has_plan)
            st.caption("GR 파일 선택 → SN No·SN Qty·차감 주차 확인 후 차감" if has_plan else "Sync Plan 업로드 후 사용 가능")
if picked:
    if "ib_preview" not in st.session_state:
        try:
            st.session_state.ib_preview = service.preview_gr([(f.name, f.getvalue()) for f in picked])
        except service.InboundFileError as e:
            st.session_state.ib_error = str(e)
            clear_pickers()
            st.rerun()
    confirm_gr(st.session_state.ib_preview)

parts = [f"금주 <b>{wlabel(this_week)}</b> ({day(monday)}~{day(monday + timedelta(days=6))})"]
parts += [f'<span class="{"ib-old" if s["old"] else ""}">{escape(s["name"])} <b>{escape(s["value"])}</b>'
          f'{" " + escape(s["note"]) if s["kind"] == "gr" else ""}{" · 업데이트 필요" if s["old"] else ""}</span>' for s in status]
st.html(f'<div class="ib-status">{" · ".join(parts)}</div>')

if done := st.session_state.pop("ib_done", None):
    st.toast(done, icon=":material/check_circle:")
if error := st.session_state.pop("ib_error", None):
    st.error(error, icon=":material/error:")

if not has_plan:
    st.info("Sync Plan이 없습니다. 우측 상단 '파일 업로드'에서 Sync Plan을 업로드하십시오. 업로드 전까지 DP 입고는 DP 파일 값을 사용합니다.",
            icon=":material/info:")
    st.stop()

cells = service.inbound_weekly()
view = cells if owner == "전체" else cells[cells["owner"] == owner]
items = set(view["item"])
if view.empty:
    st.info(f"{owner} 담당 입고 예정이 없습니다.")
    st.stop()
weeks = IB.week_range(this_week, max(view["week"].max(), next_week))    # 수량이 0인 주차도 칸이 있다

# ---- KPI ------------------------------------------------------------------------
overdue = service.inbound_overdue()
overdue = overdue[overdue["item"].isin(items)]
week_sum = view.groupby("week")["total"].sum()
with st.container(key="ib_kpis"):
    c = st.columns(4)
    c[0].metric("입고 예정 합계", f"{view['total'].sum():,.0f}", help="Sync Plan − GR. Air·Vessel, In-transit·미선적 전부")
    c[1].metric(f"금주 {wlabel(this_week)}", f"{week_sum.get(this_week, 0):,.0f}")
    c[2].metric(f"차주 {wlabel(next_week)}", f"{week_sum.get(next_week, 0):,.0f}")
    c[3].metric("ETA 경과", f"{overdue['qty'].sum():,.0f}", help=f"ETA가 지났으나 미입고된 In-transit 수량. 금주({wlabel(this_week)}) 도착으로 계산")

# ---- 확인 필요 (있을 때만) ------------------------------------------------------
notes = []    # (제목, 아이콘, 표 또는 None)
if not meta.get("transit_date"):
    notes.append(("In-transit 미업로드. 전 수량을 미선적(Air·Vessel)으로 표시 중", ":material/info:", None))
elif meta.get("gr_last") and meta["transit_date"] < meta["gr_last"]:
    notes.append((f"In-transit 파일({day(meta['transit_date'])})이 최종 GR({day(meta['gr_last'])})보다 이전 날짜 · 최신 파일 업로드 필요",
                  ":material/update:", None))
if len(overdue):
    t = overdue.assign(eta=overdue["eta"].dt.strftime("%m/%d"))[["item", "qty", "eta", "mode", "bl_no", "container", "status"]]
    notes.append((f"ETA 경과 미입고 {overdue['qty'].sum():,.0f} · 금주({wlabel(this_week)}) 도착으로 계산",
                  ":material/schedule:", t.rename(columns={"item": "Item", "qty": "수량", "eta": "최초 ETA", "mode": "운송", "bl_no": "BL",
                                                            "container": "Container", "status": "상태"})))
late = view[(view["week"] <= this_week) & (view["air"] + view["vessel"] > 0)]
if len(late):
    t = late[["item", "air", "vessel"]]
    notes.append((f"금주까지 도착 예정이나 선적 기록 없음 {late['air'].sum() + late['vessel'].sum():,.0f} · 지난 주차 이월분 포함",
                  ":material/hourglass_top:", t.rename(columns={"item": "Item", "air": "Air 미선적", "vessel": "Vessel 미선적"})))
moved = service.inbound_moved()
moved = moved[moved["item"].isin(items)] if moved is not None and len(moved) else None
if moved is not None and len(moved):
    t = moved.assign(plan_week=moved["plan_week"].map(wlabel), week=moved["week"].map(wlabel))
    notes.append((f"Sync 대비 ETA·운송수단 변경 In-transit {moved['qty'].sum():,.0f} · 변경된 주차로 계산", ":material/swap_horiz:",
                  t[["item", "qty", "plan_week", "week", "plan_group", "group"]].rename(columns={
                      "item": "Item", "qty": "수량", "plan_week": "Sync 주차", "week": "현재 주차", "plan_group": "Sync 운송", "group": "현재 운송"})))
over = pd.DataFrame(meta.get("transit_over_items") or [], columns=["item", "week", "group", "qty"])
if len(over):
    notes.append((f"Sync Plan에 없는 In-transit {over['qty'].sum():,.0f} · 합계·DP 미반영", ":material/warning:",
                  over.assign(week=over["week"].map(wlabel)).rename(columns={"item": "Item", "week": "주차", "group": "운송", "qty": "수량"})))
gr_over = pd.DataFrame(meta.get("gr_over") or [], columns=["item", "qty"])
if len(gr_over):
    notes.append((f"Sync Plan 초과 입고 {gr_over['qty'].sum():,.0f}", ":material/warning:",
                  gr_over.rename(columns={"item": "Item", "qty": "수량"})))
not_base = service.inbound_not_in_base()
if len(not_base):
    notes.append((f"Base Item 미등록 · DP 제외 Item {len(not_base):,}개 · {not_base['qty'].sum():,.0f}", ":material/warning:",
                  not_base.rename(columns={"item": "Item", "qty": "수량"})))
if notes:
    st.html('<div class="ib-head">확인 필요</div>')
    for title, icon, table in notes:
        if table is None:
            st.caption(title)
            continue
        with st.expander(title, icon=icon):
            st.dataframe(table, hide_index=True, width="stretch", height=min(38 + 35 * len(table), 320))


# ---- 상세 ---------------------------------------------------------------------
def table_bar(view_key: str) -> tuple[str, str]:
    """표 바로 위: Item 검색 + 보기. (검색어, 보기)."""
    c = st.columns([3, 2], vertical_alignment="center")
    with c[0]:
        text = search_box()
    show = c[1].segmented_control("보기", VIEWS, default="전체", key=view_key, required=True, label_visibility="collapsed",
                                  help="Air·Vessel = In-transit 포함 전체. In-transit = 선적 완료·운송 중 수량을 Air·Vessel로 구분")
    return text, show


def week_chart(g: pd.DataFrame) -> alt.Chart:
    """주차별 쌓은 막대. 칸 색은 고정, 마우스를 올리면 수량이 나온다.
    칸 사이는 테두리가 아니라 실제 틈으로 띄운다 (밝은 화면·어두운 화면 어디서나 같다)."""
    t = g.reset_index().melt("week", value_vars=list(SEGMENTS), var_name="key", value_name="수량")
    t["순서"] = t["key"].map({k: i for i, k in enumerate(SEGMENTS)})
    t = t[t["수량"] > 0].sort_values(["week", "순서"])
    t["위"] = t.groupby("week")["수량"].cumsum()
    t["아래"] = t["위"] - t["수량"]
    gap = max(g["total"].max(), 1) * 0.008
    t["위"] = t["위"].where(t["수량"] <= gap * 2, t["위"] - gap)
    t = t.assign(주차=t["week"].map(wlabel), 구분=t["key"].map(SEGMENTS))
    return alt.Chart(t).mark_bar(cornerRadius=3).encode(
        x=alt.X("주차:N", sort=[wlabel(w) for w in g.index], scale=alt.Scale(domain=[wlabel(w) for w in g.index]), title=None,
                axis=alt.Axis(labelAngle=0, ticks=False, domain=False)),
        y=alt.Y("아래:Q", title=None, axis=alt.Axis(format="~s", ticks=False, domain=False, tickCount=4)),
        y2="위:Q",
        color=alt.Color("구분:N", scale=alt.Scale(domain=list(SEGMENTS.values()), range=COLORS),
                        legend=alt.Legend(title=None, orient="top", direction="horizontal", symbolType="circle")),
        tooltip=["주차:N", "구분:N", alt.Tooltip("수량:Q", format=",.0f")],
    ).properties(height=220)


# 두 줄 머리글 표에서 Streamlit은 아래 줄 이름을 열 이름으로 쓴다 (선택·column_config 모두, 2026-11-11 미리보기에서 확인).
# 그래서 아이템·가용재고는 아래 줄에 이름을 두고, 합계 Air·Vessel은 주차 Air·Vessel과 이름이 겹치지 않게 보이지 않는 글자를 붙인다.
AVAIL = "가용재고"
TOTAL_MODE = {m: m + chr(0x200B) for m in MODES.values()}    # 폭 0 공백 (화면에는 안 보임)


def clickable(table: pd.DataFrame, key: str, height: int) -> None:
    """두 줄 머리글 표 (아이템·가용재고·합계 고정 + 주차 × Air·Vessel). 아이템 칸을 누르면 Item 360 (ui.item_table과 같은 동작).
    아이템은 행 이름(index)이 아니라 열로 둔다 (index 칸은 Streamlit이 선택을 돌려주지 않는다)."""
    nonce = st.session_state.get(f"{key}_nonce", 0)
    items = table[("", ui.ITEM)].tolist()
    pin = {name: st.column_config.Column(pinned=True) for name in (ui.ITEM, AVAIL, *TOTAL_MODE.values())}
    event = st.dataframe(ui.blank_zero(table, keep_zero=(("", AVAIL),)), width="stretch", height=height, hide_index=True,
                         on_select="rerun", selection_mode=ui.CLICK_MODES, key=f"{key}_{nonce}", column_config=pin)
    row = ui.clicked_row(event, ui.ITEM)
    if row is not None and row < len(table):
        st.session_state[f"{key}_nonce"] = nonce + 1
        ui.open_item(items[row], items)


def mode_table(t: pd.DataFrame, by: str, keys: list[str], label, key: str) -> int:
    """In-transit 보기: 주차(또는 월) × Air·Vessel 두 줄 머리글 (사용자 2026-11-11 시안). 맨 앞은 합계. 마지막 In-transit 주차까지."""
    long = t.melt(id_vars=["item", by], value_vars=list(MODES), var_name="mode", value_name="qty")
    long = long[long["qty"] > 0].assign(mode=lambda d: d["mode"].map(MODES))
    if long.empty:
        st.caption("In-transit 수량이 없습니다.")
        return 0
    last = long[by].max()
    keys = [k for k in keys if k <= last] or keys[:1]
    wide = long.pivot_table(index="item", columns=[by, "mode"], values="qty", aggfunc="sum", fill_value=0)
    wide = wide.reindex(columns=pd.MultiIndex.from_product([keys, list(MODES.values())]), fill_value=0)
    wide = wide[wide.sum(axis=1) > 0]
    total = wide.T.groupby(level=1).sum().T.reindex(columns=list(MODES.values()), fill_value=0)
    total.columns = pd.MultiIndex.from_tuples([("합계", TOTAL_MODE[m]) for m in total.columns])
    wide.columns = pd.MultiIndex.from_tuples([(label(k), m) for k, m in wide.columns])
    table = pd.concat([total, wide], axis=1).astype(int)
    table.insert(0, ("", AVAIL), table.index.map(available()).fillna(0).astype(int))
    table.insert(0, ("", ui.ITEM), table.index)
    clickable(table.reset_index(drop=True), key, height=min(73 + 35 * max(len(table), 1), 555))
    return len(table)


def available() -> pd.Series:
    """아이템별 가용재고 (OH − S/O − D/O, CFC5 + SCA3. hub/metrics.py inv_available). Item 표 둘째 열 (사용자 2026-11-11)."""
    m = service.metrics()
    return m.set_index("item")["inv_available"] if m is not None and "inv_available" in m else pd.Series(dtype=float)


def item_rows(t: pd.DataFrame, by: str, keys: list[str], label, show: str, key: str) -> int:
    """Item 표. 전체·Air·Vessel = 한 줄 머리글, In-transit = 주차(월) × Air·Vessel."""
    if show == "In-transit":
        return mode_table(t, by, keys, label, key)
    wide = t.assign(v=amount(t, show)).pivot_table(index="item", columns=by, values="v", aggfunc="sum").reindex(columns=keys).fillna(0)
    wide = wide[wide.sum(axis=1) > 0]
    wide.columns = [label(k) for k in wide.columns]
    wide.insert(0, "합계", wide.sum(axis=1))
    table = wide.reset_index().astype({c: int for c in wide.columns})
    table.insert(1, "inv_available", table["item"].map(available()).fillna(0).astype(int))
    ui.item_table(table, list(table.columns), key=key, height=min(38 + 35 * max(len(table), 1), 520), hide_zero=True,
                  pinned=("inv_available", "합계"), keep_zero=("inv_available",))
    return len(table)


def weekly_tab() -> None:
    g = view.groupby("week")[IB.BUCKETS + IB.SPLIT + ["total"]].sum().reindex(weeks, fill_value=0)
    st.altair_chart(week_chart(g), width="stretch")
    summary = totals(g)
    summary.columns = [wlabel(w) for w in summary.columns]
    summary.insert(0, "합계", summary.sum(axis=1))
    st.dataframe(ui.blank_zero(summary), width="stretch")
    st.caption("Air·Vessel = In-transit 포함 전체 (미선적 + In-transit). In-transit · Air/Vessel = 선적 완료·운송 중 수량 (In-transit 파일 TP Mode 기준).")
    text, show = table_bar("ib_show")
    n = item_rows(by_text(view, text), "week", weeks, wlabel, show, key=f"ib_table_{show}")
    st.caption(f"Item {n:,}개 · {show}. 아이템 칸 선택 시 Item 360 이동. 아이템·가용재고·합계 열 고정.")


def monthly_tab() -> None:
    t = service.inbound_by_month(sorted(items))
    t["월"] = [f"M{int(m)} {E.month_label(k)}" if pd.notna(m) else E.month_label(k) for k, m in zip(t["month"], t["m"])]
    t = t.assign(air_all=t["air"] + t["it_air"], vessel_all=t["vessel"] + t["it_vessel"])
    shown = t.set_index("월")[["air_all", "vessel_all", "it_air", "it_vessel", "qty", "dp"]].rename(columns={
        "air_all": "Air", "vessel_all": "Vessel", "it_air": "In-transit · Air", "it_vessel": "In-transit · Vessel",
        "qty": "합계", "dp": "DP 입고"})
    shown.index.name = None
    st.dataframe(ui.blank_zero(shown.fillna(0)), width="stretch")     # DP 기간 밖의 달은 DP 입고 칸이 빈칸
    dp = t[t["m"].notna()]
    gap = dp["qty"] - dp["dp"]
    if (gap.abs() < 0.5).all():
        st.caption(f":green[:material/check_circle:] M1~M{len(dp)} 합계 = DP 입고 (일치). 이후 월은 DP 기간 외.")
    else:
        st.warning("DP 입고와 차이: " + ", ".join(f"{r['월']} {g:+,.0f}" for (_, r), g in zip(dp.iterrows(), gap) if abs(g) >= 0.5)
                   + ". 상단 '확인 필요' 항목을 확인하십시오.", icon=":material/warning:")
    text, show = table_bar("ib_show_m")
    months = service.inbound_monthly()
    months = by_text(months if owner == "전체" else months[months["owner"] == owner], text).rename(columns={"qty": "total"})
    keys = [str(p) for p in pd.period_range(t["month"].min(), t["month"].max(), freq="M")]     # 0인 달도 칸이 있다
    n = item_rows(months, "month", keys, E.month_label, show, key=f"ib_mtable_{show}")
    st.caption(f"Item {n:,}개 · {show}. 아이템 칸 선택 시 Item 360 이동. 아이템·가용재고·합계 열 고정.")


def sync_tab() -> None:
    cmp = service.sync_compare()
    if cmp is None:
        st.info("다음 Sync Plan 업로드 시 이전 Sync 대비 변경 내역이 표시됩니다. 지금 비교하려면 이전 주 MP_PSI 파일을 선택하십시오 (기준 파일은 변경되지 않음).",
                icon=":material/compare_arrows:")
        c = st.columns([1, 2])
        with c[0]:
            f = picker("old")
        if f:
            update(f, service.add_old_sync_plan)
        return
    mine = lambda t: t if owner == "전체" else t[t["owner"] == owner]
    changed, months = mine(cmp["items"]), mine(cmp["months"])
    st.markdown(f"**{cmp['old_version']} → {cmp['new_version']}**")
    with st.container(key="ib_kpis_sync"):
        c = st.columns(4)
        c[0].metric("입고 예정 증감", f"{months['delta'].sum():+,.0f}")
        c[1].metric("변경 Item", f"{len(changed):,}")
        c[2].metric("증가 · 신규", f"{changed['kind'].isin([IB.GREW, IB.NEW]).sum():,}")
        c[3].metric("감소 · 삭제", f"{changed['kind'].isin([IB.SHRANK, IB.GONE]).sum():,}")
    m = months.groupby("month")[["old", "new", "delta"]].sum()
    m = m[(m["old"] != 0) | (m["new"] != 0)]
    table = m.rename(columns={"old": "이전 Sync", "new": "금번 Sync", "delta": "증감"}).T
    table.columns = [E.month_label(k) for k in table.columns]
    st.dataframe(table.style.format(lambda v: f"{v:,.0f}").format(lambda v: f"{v:+,.0f}" if v else "", subset=pd.IndexSlice[["증감"], :]),
                 width="stretch")
    st.caption(f"동일 시점 기준 비교: 이전 Sync에서 이후 입고 {cmp['gr']:,.0f} 차감, 지난 주차 잔량은 금주로 이월.")
    counts = changed["kind"].value_counts()
    kinds = ["전체"] + [k for k in IB.KINDS if counts.get(k)]
    c = st.columns([3, 4], vertical_alignment="center")
    with c[0]:
        text = search_box()
    pick = c[1].segmented_control("구분", kinds, default="전체", key="ib_kind", required=True, label_visibility="collapsed",
                                  format_func=lambda k: f"{k} {len(changed) if k == '전체' else counts.get(k, 0):,}")
    shown = by_text(changed if pick == "전체" else changed[changed["kind"] == pick], text)
    if shown.empty:
        st.caption("변경된 Item이 없습니다.")
        return
    table = shown.rename(columns={"old": "이전 Sync", "new": "금번 Sync", "delta": "증감", "kind": "구분", "change": "변경 내용"})
    table = table.astype({c: int for c in ("이전 Sync", "금번 Sync", "증감")})
    ui.item_table(table, ["item", "구분", "이전 Sync", "금번 Sync", "증감", "변경 내용"], key=f"ib_sync_{pick}",
                  height=min(38 + 35 * len(table), 520), hide_zero=True, signed=("증감",))


def gr_tab() -> None:
    st.caption(f"GR 차감 범위: {meta['gr_since']} 이후 입고 (이전 입고는 Sync Plan 기반영). 차감 주차 = 컨테이너 도착 예정 주차.")
    batches = meta.get("gr_batches") or []
    if not batches:
        st.info("GR 차감 이력이 없습니다. 우측 상단 '파일 업로드' → 'GR 차감'에서 진행합니다.", icon=":material/inventory:")
        return
    for b in batches:
        r = st.columns([4, 1.3], vertical_alignment="center")
        dates = ", ".join(day(d) for d in b["gr_dates"] or [])
        where = f" · {', '.join(wlabel(w) for w in b['weeks'])} 차감" if b.get("weeks") else ""
        r[0].markdown(f"**{b['qty']:,.0f}** · GR {dates}{where} · SN {', '.join(b['sn'] or ['–'])}")
        r[0].caption(uploaded(b["by"], b["at"]))
        if r[1].button("차감 취소", key=f"ib_undo_{b['path']}", width="stretch"):
            with st.spinner("차감 취소 및 재계산 중…"):
                service.cancel_gr(b["path"])
            st.session_state.ib_done = f"GR 차감 취소: {b['qty']:,.0f}"
            st.rerun()


TABS = {"주차별": weekly_tab, "월별": monthly_tab, "Sync 비교": sync_tab, "GR 이력": gr_tab}
st.write("")
TABS[st.segmented_control("보기", list(TABS), default="주차별", key="ib_tab", required=True, label_visibility="collapsed")]()
