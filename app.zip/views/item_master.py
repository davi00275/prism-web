"""Item Master: 전체 아이템 표, 필터, 유사 아이템(버전) 후보."""

import pandas as pd
import streamlit as st

import ui
from hub import codes, config, service

st.title("Item Master")

m = service.master()
if m is None:
    st.error("Item Master가 없습니다. '데이터 현황'에서 파일 상태를 확인하십시오.")
    st.stop()

meta = service.meta()
counts = meta.get("counts", {})
st.caption(f"{meta.get('built_at', '')[:16].replace('T', ' ')} 에 만듦 · 아이템 {counts.get('items', 0):,}개 "
           f"(Product List + DP list + Local List + BOM 세트)")

# ---- 필터 -----------------------------------------------------------------
owners = sorted({v for v in config.settings().get("owners", {}).values()})
groups = ["CAMERA", "PERIPHERAL", "RECORDER", "ETC"]
f = st.columns([2, 2, 2, 3])
sel_owner = f[0].selectbox("담당", ["전체"] + owners)
sel_group = f[1].multiselect("Product Group", groups)
sel_plc = f[2].multiselect("PLC", ["ACTIVE", "PLANNED", "INACTIVE", "DELETED", "(없음)"],
                           default=["ACTIVE", "PLANNED", "(없음)"],
                           help="(없음) = Product List에 없는 아이템 (HVA Local 세트 등)")
text = f[3].text_input("아이템·모델 포함", placeholder="예: PNM, XNV-6")
g = st.columns(6)
only_dp = g[0].toggle("DP list에 있는 것만", value=True, help="DP 판정(대상·제외)은 '담당 아이템'에서 조회")
only_local = g[1].toggle("Local만")
only_bom = g[2].toggle("BOM 세트만")
only_manual = g[3].toggle("수동입력만", help="DP Table RR Review가 수동입력 (TAA, 대형프로젝트, 🔴)")
only_kv = g[4].toggle("K↔V 전환만")
not_in_pl = g[5].toggle("Product List에 없는 것만")

v = m
if sel_owner != "전체":
    v = v[v["owner"] == sel_owner]
if sel_group:
    v = v[v["product_group"].isin(sel_group)]
if sel_plc:
    keep = v["plc_status"].isin([p for p in sel_plc if p != "(없음)"])
    if "(없음)" in sel_plc:
        keep |= v["plc_status"].isna()
    v = v[keep]
if text:
    v = v[v["search_key"].str.contains(codes.norm(text), regex=False, na=False)]
if only_dp:
    v = v[v["in_dp_list"]]
if only_local:
    v = v[v["is_local"]]
if only_bom:
    v = v[v["is_bom_header"]]
if only_manual:
    v = v[v["is_manual_input"]]
if only_kv:
    v = v[v["is_kv_switch"]]
if not_in_pl:
    v = v[~v["in_product_list"]]

tab_list, tab_versions = st.tabs([f"아이템 ({len(v):,})", "버전 후보"])

with tab_list:
    columns = ["item", "item_name", "product_group", "owner", "dp_series", "plc_status", "sra", "eol", "eop",
               "site", "dest", "in_dp_list", "is_local", "is_bom_header", "dp_rr_current", "dp_rr_proposed",
               "dp_eoh_target", "dp_pl_status", "dp_review", "dp_exclude_reason"]
    ui.item_table(v, columns, key="im")
    c1, c2 = st.columns([4, 1])
    c1.caption("아이템 칸 선택 시 Item 360 이동.")
    c2.download_button("CSV 다운로드", ui.table(v, columns).to_csv(index=False).encode("utf-8-sig"),
                       file_name="item_master.csv", mime="text/csv", icon=":material/download:")

with tab_versions:
    st.caption("숫자 마지막 자리만 다른 Item 그룹 (예: SBV-120WCW → 121 → 122). 현재 필터 기준. "
               "'SRA 순서 일치'가 아니면 버전이 아닌 사양 차이일 수 있음. 확정 기능은 추후 추가 예정.")
    fam = v[v["family_key"].notna()]
    groups_ = (fam.groupby("family_key")
               .agg(bases=("base", "nunique"), items=("item", lambda s: ", ".join(sorted(s))),
                    product_group=("product_group", "first"))
               .query("bases > 1"))
    if groups_.empty:
        st.info("현재 필터 기준 버전 후보가 없습니다.")
    else:
        # 버전 숫자 순서와 SRA 순서가 같은지
        def sra_in_order(key: str) -> bool:
            x = m[m["family_key"] == key].dropna(subset=["sra"]).groupby("version")["sra"].min().sort_index()
            return bool(x.is_monotonic_increasing) if len(x) > 1 else True
        groups_["sra_order"] = [sra_in_order(k) for k in groups_.index]
        out = groups_.reset_index().rename(columns={"family_key": "버전 묶음 키", "bases": "모델 수", "items": "아이템",
                                                    "product_group": "Product Group", "sra_order": "SRA 순서 일치"})
        st.dataframe(out, hide_index=True, width="stretch", height=480)
        st.caption(f"{len(out):,}개 묶음 · SRA 순서 일치 {int(out['SRA 순서 일치'].sum()):,}개")
