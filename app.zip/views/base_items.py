"""Base Item: DP의 기준 아이템 목록을 보고, 새 아이템을 넣는다 (사용자 2026-11-06).

여기 있는 아이템이 DP 대상이다. 파일(samples/Base Item.xlsx) + 이 화면에서 넣은 아이템.
넣은 내용은 공유 폴더 사람 입력에 쌓여서 (hub/base_items.py) 누가 언제 넣었는지 남고 팀에 공유된다.
"""

import pandas as pd
import streamlit as st

import ui
from hub import base_items, codes, service

st.title("Base Item")
items = service.base_item_list()
groups = service.item_groups()
GROUP_LABEL = lambda g: f"{g} ({groups[g]})" if g in groups else g

if items.empty:
    st.error("Base Item 파일이 없습니다. '홈' 화면에서 파일 상태를 확인하십시오.")
    st.stop()

added = items[items["source"] == base_items.TOOL]
no_owner = items[items["owner"].isna()]
st.caption(f"DP 대상 **{len(items):,}개** = 파일 {len(items) - len(added):,}개 + 화면 등록 {len(added):,}개. "
           "등록 Item은 M1~M3이 모두 0이어도 전부 계산.")

saved = st.session_state.pop("base_saved", None)
if saved:
    st.toast(saved, icon=":material/check_circle:")

# ---- 새 아이템 넣기 -------------------------------------------------------------
n = st.session_state.get("base_nonce", 0)   # 넣은 뒤 칸을 비우려고 칸 이름을 바꾼다
with st.expander("신규 Item 등록", icon=":material/add:", expanded=False):
    code = st.text_input("아이템 코드", key=f"base_new_item_{n}", placeholder="예: XNV-9083R/VEX").strip()
    known = None
    if code:
        m = service.master()
        rows = m[m["item"].map(codes.norm) == codes.norm(code)]
        known = rows.iloc[0] if len(rows) else None
        if code in set(items["item"]):
            st.warning("이미 Base Item에 등록된 Item입니다.", icon=":material/warning:")
        elif known is not None:
            st.caption(f"Product List 등록 Item: {known.get('item_name')} · {known.get('product_group')} · "
                       f"담당 {known.get('owner')}. 이름·Group 입력 불필요.")
        else:
            st.caption("Product List 미등록 신규 Item. 이름·Group을 입력하십시오.")
    c = st.columns([2, 1.4, 1, 1])
    name = c[0].text_input("아이템 이름", value="" if known is None or pd.isna(known.get("item_name")) else known["item_name"],
                           key=f"base_new_name_{n}_{code}", placeholder="비우면 아이템 코드와 같게")
    options = list(groups)
    default = options.index(known["product_group"]) if known is not None and known.get("product_group") in options else None
    group = c[1].selectbox("Group (담당)", options, index=default, format_func=GROUP_LABEL, key=f"base_new_group_{n}_{code}",
                           placeholder="선택")
    rr = c[2].number_input("R/R (월)", min_value=0.0, step=1.0, format="%.0f", key=f"base_new_rr_{n}_{code}",
                           help="금번 RR 기준월 값으로 저장. 0이면 저장하지 않음")
    eoh = c[3].number_input("EOH", min_value=0.0, step=1.0, format="%.0f", key=f"base_new_eoh_{n}_{code}")
    memo = st.text_input("메모 (선택)", key=f"base_new_memo_{n}_{code}", placeholder="예: 11월 신규 출시")
    if st.button("등록", type="primary", icon=":material/add:", key="base_add",
                 disabled=not code or group is None or code in set(items["item"])):
        service.add_base_item(code, name, group, rr, eoh, memo)
        st.session_state.base_saved = f"등록 완료: {code} (DP 계산 반영)"
        st.session_state.base_nonce = n + 1
        st.rerun()

# ---- 담당 없는 아이템 -----------------------------------------------------------
if len(no_owner):
    with st.expander(f"⚠ 담당 미지정 Item {len(no_owner)}개 — Group 지정 필요", expanded=True):
        st.caption("담당 미지정 시 '금주 DP'에 표시되지 않습니다.")
        for r in no_owner.itertuples(index=False):
            c = st.columns([3, 3, 1], vertical_alignment="bottom")
            c[0].markdown(f"**{r.item}**")
            g = c[1].selectbox("Group", list(groups), index=None, format_func=GROUP_LABEL, key=f"base_group_{r.item}",
                               placeholder="선택", label_visibility="collapsed")
            if c[2].button("정하기", key=f"base_set_{r.item}", disabled=g is None, width="stretch"):
                service.set_item_group(r.item, g)
                st.session_state.base_saved = f"담당 지정 완료: {r.item}"
                st.rerun()

# ---- 목록 ---------------------------------------------------------------------
c = st.columns([2, 3], vertical_alignment="bottom")
owner = c[0].selectbox("담당", ["전체"] + service.owners(), key="base_owner")
text = c[1].text_input("아이템으로 좁히기", key="base_text", placeholder="예: PNM, XNV-6")
view = items
if owner != "전체":
    view = view[view["owner"] == owner]
if text.strip():
    q = codes.norm(text)
    view = view[view["item"].map(codes.norm).str.contains(q, regex=False)]
view = view.reset_index(drop=True)
table = pd.DataFrame({"item": view["item"], "아이템 이름": view["item_name"], "Group": view["product_group"].fillna(""),
                      "담당": view["owner"].fillna(""), "PLC": view["plc_status"].fillna(""), "등록 경로": view["source"],
                      "등록자": view["by"].fillna(""), "등록 일시": view["at"].fillna("").str[:16].str.replace("T", " "),
                      "메모": view["memo"].fillna("")})
ui.item_table(table, list(table.columns), key="base_table", height=min(38 + 35 * max(len(table), 1), 560))
st.caption(f"{len(view):,}개. 아이템 칸 선택 시 Item 360 이동.")

# ---- 넣은 아이템 빼기 -----------------------------------------------------------
if len(added):
    with st.expander(f"화면 등록 Item 삭제 ({len(added)}개)"):
        c = st.columns([4, 1], vertical_alignment="bottom")
        target = c[0].selectbox("아이템", added["item"].tolist(), key="base_remove_item")
        if c[1].button("삭제", key="base_remove", width="stretch"):
            service.remove_base_item(target)
            st.session_state.base_saved = f"삭제 완료: {target} (이력 보존)"
            st.rerun()
