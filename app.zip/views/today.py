"""오늘 ('홈' 메뉴): 앱을 열면 처음 보는 화면. 오늘 할 일을 한눈에 (사용자 2026-11-03: 매일·매주 실제로 쓰는 흐름).

배치 (2026-11-09, docs/ui-design.md 3장 ① 홈):
  위       이번 주 흐름  월 자원점검 업로드 → 화 Sync Plan → 목·금 M1~M3 정하기·확정 → 주말 본사 자원점검.
                         오늘 단계를 칠하고, 단계마다 그 일을 하는 화면으로 가는 링크
  왼쪽     할 일         여기저기 있던 경고를 한곳에: Decrypt 필요·오래된 파일·파일 경고, 확정 뒤 입고 바뀜(월~수),
                         R/R·EOH 원래 값 바뀜, 이번 주 확정 안 함(목·금)·확정 뒤 바뀐 아이템
  오른쪽   이번 주 DP    담당별 진행(아이템, M1~M3, 고친 아이템, 확정 여부)
           주의 신호     내 아이템(DP 대상)의 주의 신호 개수. 누르면 '내 아이템'이 그 신호로 걸러진다
  아래     데이터 준비   (전체 폭, 파일 이름이 길어서) 원천마다 쓰는 파일과 날짜. 잠긴 파일이 있으면 30초마다
                         저절로 다시 확인해서, Decrypt하면 알아서 읽는다
새로 계산하는 숫자는 없다. 모두 hub/service.py에 있는 값을 모아 보여 준다.
Decrypt 자체는 DRM 도구라 사람이 한다 (CLAUDE.md).
"""

from datetime import date, timedelta

import streamlit as st

import ui
from hub import config, dp_engine as E, metrics as M, service

WEEKDAY = "월화수목금토일"
STATE = {
    service.DECRYPT: ("Decrypt 필요", "red", ":material/lock:"),
    service.NEW: ("신규 파일 반영 중", "blue", ":material/sync:"),
    service.OLD: ("업데이트 필요", "orange", ":material/schedule:"),
    service.MISSING: ("파일 없음", "gray", ":material/help:"),
    service.OK: ("최신", "green", ":material/check_circle:"),
}

today = date.today()
cal = service.dp_calendar()
st.title(f"오늘 {today:%m/%d} ({WEEKDAY[today.weekday()]})")
thu, fri = (date.fromisoformat(d) for d in cal["dp_days"])
months = [E.month_label(k) for k in cal["month_keys"][:cal["months"]]]
st.caption(f"금주 DP **W{cal['dp_week']}** · DP 입력 {thu:%m/%d}(목)·{fri:%m/%d}(금) · 기간 {', '.join(months)}")

me = service.current_owner()
prog = service.week_progress()
mine = next((p for p in prog if p["owner"] == me), None)
week = prog[0]["week"] if prog else None                     # 이번 DP 주차 (예: 2026-W46)
wlabel = lambda w: w.split("-")[-1]
# 월요일에 올리는 것은 이번 주 전에 가장 최근 확정한 주차 ('자원점검 업로드' 화면의 기본과 같다)
last = next((w for w in service.confirmed_weeks() if week is None or w["week"] < week), None)
# 오늘이 한 주의 어느 단계인지: 월 = 업로드, 화·수 = Sync Plan, 목·금 = DP, 주말 = 본사 자원점검
step_now = {0: 0, 1: 1, 2: 1, 3: 2, 4: 2}.get(config.today().weekday(), 3)

# ---- 이번 주 흐름 -------------------------------------------------------------
sync = next((s for s in service.inbound_status() if s["name"] == "Sync Plan"), None)
done = sum(1 for p in prog if p["confirmed_at"])
monday = thu - timedelta(days=3)
steps = [   # (요일, 할 일, 지금 상태, 화면, 링크 글자)
    (f"월 {monday:%m/%d}", "자원점검 업로드",
     f"{wlabel(last['week'])} 확정 {len(last['owners'])}명 · AIR 분리 및 업로드 파일 생성" if last else "확정 주차 없음",
     "views/resource_check.py", "자원점검 업로드"),
    (f"화 {monday + timedelta(days=1):%m/%d}", "Sync Plan 업로드",
     (f"현재 기준 {sync['value']}" + (" · 업데이트 필요" if sync["old"] else "")) if sync else "",
     "views/inbound.py", "Inbound"),
    (f"목·금 {thu:%m/%d}–{fri:%d}", "M1~M3 수량 입력 · 확정", f"W{cal['dp_week']} 확정 {done} / {len(prog)}명",
     "views/dp_plan.py", "금주 DP"),
    ("주말", "본사 자원점검", "익주 월요일 업로드", None, None),
]
st.subheader("금주 일정", anchor=False)
with st.container(border=True):
    cols = st.columns(len(steps))
    for i, (day, what, sub, page, label) in enumerate(steps):
        # 오늘 단계는 key가 flow_now → ui.STYLE이 연한 주황 칸으로 칠한다
        with cols[i].container(key="flow_now" if i == step_now else f"flow_{i}"):
            st.markdown((ui.badge("진행 중", "blue") + " " if i == step_now else "") + f"**{day}**")
            st.markdown(f"**{what}**")
            if sub:
                st.caption(sub)
            if page:
                st.page_link(page, label=label, icon=":material/arrow_forward:")

# ---- 할 일: 여기저기 있던 경고를 한곳에 ------------------------------------------------
rows = service.data_today()
todos = []   # (아이콘, 색, 제목, 설명, 할 일) — 할 일 = ("folder", 원천 id) | ("page", 화면, 글자) | None
for r in rows:
    when = "" if r["business_days_old"] is None else "오늘" if r["business_days_old"] == 0 else f"영업일 {r['business_days_old']}일 전"
    act = ("page", r["page"], "업로드") if r.get("page") else ("folder", r["id"]) if r["folder"] else None
    if r["state"] == service.DECRYPT:
        todos.append((":material/lock:", "red", f"{r['waiting_file'] or r['name']} Decrypt 필요",
                      f"{r['name']} · Decrypt 후 30초 내 자동 반영" + (f" · 현재 사용 파일: {r['file']}" if r["file"] else ""), act))
    elif r["state"] == service.OLD:
        todos.append((":material/schedule:", "orange", f"{r['name']} 파일 업데이트 필요",
                      f"{r['file'] or ''} · {when}" + ("" if r.get("page") else " · 폴더 내 최신 파일 없음"), act))
    elif r["state"] == service.MISSING:
        todos.append((":material/help:", "gray", f"{r['name']} 파일 없음", "", act))
for w in service.flow_meta().get("warnings") or []:
    todos.append((":material/warning:", "orange", w, "", None))
if me and last and me in last["owners"] and step_now <= 1:
    moved = service.inbound_since_confirm(me, last["week"])
    if len(moved):
        todos.append((":material/local_shipping:", "orange", f"{wlabel(last['week'])} 확정 후 입고 변경 Item {len(moved):,}개",
                      f"차이 {moved['diff'].sum():+,.0f}대 · 업로드 전 '자원점검 ±'로 조정 필요",
                      ("page", "views/resource_check.py", "자원점검 업로드")))
plan, m = service.dp_plan(), service.metrics()
if plan is not None and m is not None:
    v = plan.merge(m[["item", "owner"]], on="item", how="left")
    v = v[v["owner"] == me] if me else v
    stale = int((v["rr_stale"] | v["eoh_stale"]).sum())
    if stale:
        todos.append((":material/sync_problem:", "orange", f"R/R·EOH 원본 값 변경 Item {stale}개",
                      "DP 파일 값 변경 · 수정값 유지 여부 결정 필요", ("page", "views/dp_plan.py", "금주 DP")))
if mine and step_now == 2 and not mine["confirmed_at"]:
    todos.append((":material/task_alt:", "blue", f"W{cal['dp_week']} 미확정",
                  f"{me} 담당 Item {mine['items']:,}개 · M1~M{cal['months']}", ("page", "views/dp_plan.py", "금주 DP")))
if mine and mine["changed_since"]:
    todos.append((":material/edit_note:", "orange", f"확정 후 변경 Item {len(mine['changed_since'])}개",
                  "재확정 시 변경 수량으로 기록", ("page", "views/dp_plan.py", "금주 DP")))

left, right = st.columns([1.35, 1], gap="large")

with left:
    st.subheader("할 일" + (f" {len(todos)}" if todos else ""), anchor=False)
    with st.container(border=True):
        if not todos:
            st.markdown(":green[:material/check_circle:] 처리할 항목이 없습니다. 데이터 모두 최신.")
        for n, (icon, color, title, sub, act) in enumerate(todos):
            c = st.columns([3.2, 1.8], vertical_alignment="center")
            c[0].markdown(f":{color}[{icon}] **{title}**")
            if sub:
                c[0].caption(sub)
            if act and act[0] == "page":
                c[1].page_link(act[1], label=act[2], icon=":material/arrow_forward:")
            elif act and act[0] == "folder" and c[1].button("폴더 열기", key=f"todo_open_{act[1]}_{n}",
                                                          icon=":material/folder_open:", width="stretch"):
                if not service.open_folder(act[1]):
                    st.toast("폴더를 찾을 수 없습니다.", icon=":material/error:")

with right:
    # ---- 이번 주 DP: 담당별 진행 ------------------------------------------------------
    st.subheader(f"금주 DP 진행 현황 · W{cal['dp_week']}", anchor=False)
    with st.container(border=True):
        for p in prog:
            c = st.columns([3, 1.4], vertical_alignment="center")
            c[0].markdown(f"**{p['owner']}**" + (" " + ui.badge("나", "blue") if p["owner"] == me else ""))
            c[0].caption(f"Item {p['items']:,} · 수정 {p['edited']}  \n" + " · ".join(
                f"M{i} {ui.fmt(v)}" for i, v in enumerate(p["dp"], start=1)))
            state = (ui.badge(f"확정 {p['confirmed_at'][5:16].replace('T', ' ')}", "green") if p["confirmed_at"]
                     else ui.badge("미확정", "gray"))
            if p["changed_since"]:
                state += " " + ui.badge(f"변경 {len(p['changed_since'])}", "orange")
            c[1].markdown(state)
        st.page_link("views/dp_plan.py", label="금주 DP 바로가기", icon=":material/calculate:")
    st.caption(f"M1~M{cal['months']} = {', '.join(months)}. 금요일 담당별 확정 → 주말 본사 자원점검 → 월요일 '자원점검 업로드'에서 "
               "AIR 분리 후 업로드. 타 담당자 확정 현황은 OneDrive 동기화 기준.")

    # ---- 내 아이템 주의 신호 ------------------------------------------------------------
    st.subheader("담당 Item 주의 신호" + (f" · {me}" if me else ""), anchor=False)
    items = service.worklist(me)
    if items.empty:
        st.caption("Item 지표가 없습니다.")
    else:
        counts = [(a, int(items[f"alert_{a.key}"].sum())) for a in M.ALERTS]
        counts = [(a, n) for a, n in counts if n]
        st.caption(f"DP 대상 {len(items):,}개 중 신호 발생 Item. 선택 시 '담당 아이템' 화면에 해당 신호로 필터 적용.")
        cols = st.columns(2)
        for i, (a, n) in enumerate(counts):
            if cols[i % 2].button(f"{a.label} **{n}**", key=f"today_alert_{a.key}", help=a.help, width="stretch"):
                st.session_state.wl_alerts = [a.key]
                st.session_state.wl_status = M.DP_TARGET
                if me:
                    st.session_state.wl_owner = me
                st.switch_page("views/worklist.py")

# ---- 데이터 준비 (화면 전체 폭: 파일 이름이 길어서) ------------------------------------------
waiting = any(r["state"] in (service.DECRYPT, service.NEW) for r in rows)


@st.fragment(run_every=30 if waiting else None)
def data_ready() -> None:
    rows = service.data_today()
    if any(r["state"] == service.NEW for r in rows):
        # Decrypt된 새 파일이 있으면 바로 읽는다
        with st.spinner("신규 파일 반영 중…"):
            results = service.refresh()
        st.session_state.scan_results = results
        loaded = [r["name"] for r in results if r["status"] == "loaded" and r["file"]]
        st.session_state.today_loaded = "신규 반영: " + ", ".join(loaded) if loaded else None
        st.rerun()
    st.subheader("데이터 준비", anchor=False)
    for r in rows:
        label, color, icon = STATE[r["state"]]
        c = st.columns([2, 3.4, 1.2, 1.6], vertical_alignment="center")
        c[0].markdown(f"{icon} **{r['name']}**")
        when = ("" if r["business_days_old"] is None else
                " · 오늘" if r["business_days_old"] == 0 else f" · 영업일 {r['business_days_old']}일 전")
        detail = f"{r['file'] or '파일 없음'}{when}"
        if r["state"] == service.DECRYPT:
            detail = f"**{r['waiting_file']}** DRM 잠김 → 현재 사용 파일: {r['file'] or '없음'}{when}"
        elif r["state"] == service.OLD and not r.get("page"):
            detail += " · 폴더 내 최신 파일 없음"
        c[1].markdown(detail)
        c[2].markdown(ui.badge(label, color))
        if r.get("page"):
            c[3].page_link(r["page"], label="업로드", icon=":material/upload_file:")
        elif r["folder"] and c[3].button("폴더 열기", key=f"today_open_{r['id']}", icon=":material/folder_open:",
                                         width="stretch", help=r["folder"]):
            if not service.open_folder(r["id"]):
                st.toast(f"폴더를 찾을 수 없습니다: {r['folder']}", icon=":material/error:")
    c = st.columns([3, 1])
    c[0].caption("Decrypt한 원천 파일은 Excel로 열지 마십시오 (열기만 해도 DRM 재적용). "
                 + ("잠긴 파일 30초 간격 재확인 중." if waiting else ""))
    if c[1].button("재확인", icon=":material/refresh:", width="stretch", key="today_refresh"):
        with st.spinner("새 파일 확인 중…"):
            st.session_state.scan_results = service.refresh()
        st.rerun(scope="app")


data_ready()
note = st.session_state.pop("today_loaded", None)
if note:
    st.toast(note, icon=":material/download_done:")
