"""데이터 현황: 원천 파일마다 마지막으로 불러온 파일, 지금 폴더 상태, 스냅샷 기록."""

import pandas as pd
import streamlit as st

from hub import config, ingest, service, store

st.title("데이터 현황")

c1, c2 = st.columns([1, 1])
if c1.button("새 파일 확인", icon=":material/refresh:"):
    with st.spinner("새 파일 확인 중…"):
        st.session_state.scan_results = service.refresh()
if c2.button("Item Master 재생성", icon=":material/build:", help="파일 변경 여부와 관계없이 재생성"):
    with st.spinner("다시 만드는 중…"):
        st.session_state.scan_results = service.refresh(force=True)

# ---- 마지막 확인 결과 -----------------------------------------------------
results = st.session_state.get("scan_results", [])
if results:
    st.subheader("마지막 확인 결과")
    rows = [(r["name"], ingest.STATUS_LABEL.get(r["status"], r["status"]), r["file"] or "", r["message"])
            for r in results if r["status"] != ingest.PLANNED]
    st.dataframe(pd.DataFrame(rows, columns=["데이터", "상태", "파일", "내용"]), hide_index=True, width="stretch")

# ---- 원천별 ---------------------------------------------------------------
st.subheader("원천 데이터")
status = service.data_status()
rows = []
for s in status:
    if not s["enabled"]:
        state = "연결 예정"
    elif s.get("current_locked"):
        state = "잠김 (Decrypt 필요)"
    elif s.get("new_file_waiting"):
        state = "신규 파일"
    elif s.get("last_file"):
        state = "최신"
    else:
        state = "파일 없음"
    rows.append({
        "데이터": s["name"], "상태": state, "설명": s["description"],
        "불러온 파일": s.get("last_file") or "", "파일 날짜": (s.get("last_file_date") or "")[:16].replace("T", " "),
        "불러온 시각": (s.get("loaded_at") or "")[:16].replace("T", " "),
        "스냅샷 수": s.get("snapshots") or 0,
        "위치": f"{s['root']} / {s['folder']} / {s['pattern']}",
    })
st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")

# ---- Item Master ----------------------------------------------------------
meta = service.meta()
if meta:
    st.subheader("Item Master")
    c = meta.get("counts", {})
    k = st.columns(5)
    k[0].metric("아이템", f"{c.get('items', 0):,}")
    k[1].metric("ACTIVE·PLANNED", f"{c.get('active_planned', 0):,}")
    k[2].metric("DP 대상", f"{c.get('dp_targets', 0):,}")
    k[3].metric("Local", f"{c.get('local', 0):,}")
    k[4].metric("BOM 세트", f"{c.get('bom_headers', 0):,}")
    st.caption(f"{meta.get('built_at', '')[:16].replace('T', ' ')} 에 만듦")
    dp = meta.get("inputs", {}).get("dp_file")
    if dp:
        st.caption(f"DP 파일 {dp['file']} · Setting 주차 W{dp.get('dp_week')} · RR 기준월 {dp.get('rr_base_month')}")

inv = service.inventory_meta()
if inv.get("key_date"):
    st.subheader("재고")
    st.caption(f"{', '.join(inv['locations'])} · {inv['key_date']} 기준 · 출처 {inv['source']} ({inv['file']}). "
               "공유 폴더 최신 재고 파일이 DRM 잠김이면 DP 파일 재고 사용.")

plan_meta = service.dp_plan_meta()
if plan_meta:
    st.subheader("DP 계산 (계산 엔진)")
    cal = service.dp_calendar()
    st.caption(f"이번 DP W{cal['dp_week']} (오늘 날짜로) · M1~M{cal['months']} "
               f"({', '.join(cal['month_keys'][:cal['months']])}) · R/R·EOH·입고는 {plan_meta['dp_file']} "
               f"(W{plan_meta['dp_week']}, 데이터 {plan_meta.get('dp_file_data_date')}, RR 기준월 {plan_meta['rr_base_month']}) · "
               f"{plan_meta['built_at'][:16].replace('T', ' ')} 에 만듦. 계산 방법은 docs/dp-engine.md")

# ---- 사람 입력 ------------------------------------------------------------
st.subheader("수동 입력 (대시보드 수정값)")
ins = service.input_status()
st.write(f"저장 폴더: `{ins['folder']}` ({ins['where']}) · 이 PC에서 저장하는 사람: **{ins['writer']}**")
if ins["files"]:
    st.dataframe(pd.DataFrame([{
        "사람": f["person"], "마지막 저장": (f["last_at"] or "").replace("T", " "), "줄 수": f["rows"],
        "읽지 못한 줄": f["bad_lines"], "파일 수정 시각 (이 PC에 받은 때)": f["modified"].replace("T", " "),
        "상태": "잠김 (DRM)" if f["locked"] else "정상"} for f in ins["files"]]), hide_index=True, width="stretch")
    st.caption("타 담당자 입력은 OneDrive 동기화 범위만 표시. '마지막 저장'이 실제보다 "
               "이르면 동기화 미완료.")
else:
    st.caption("저장된 입력이 없습니다. '금주 DP' 또는 Item 360에서 최초 저장 시 폴더가 생성됩니다.")

# ---- 폴더 -----------------------------------------------------------------
st.subheader("폴더")
root = service.shared_root()
st.write(f"팀 공유 폴더: `{root}`" if root else "팀 공유 폴더: 찾을 수 없음 (settings.yaml roots.shared에 직접 지정 가능)")
st.write(f"툴 데이터 (스냅샷·캐시): `{config.data_dir()}`")

with st.expander("스냅샷 기록"):
    for s in status:
        if not s["enabled"]:
            continue
        hist = store.entries(s["id"])
        st.markdown(f"**{s['name']}** ({len(hist)})")
        if hist:
            st.dataframe(pd.DataFrame([{"불러온 시각": e["loaded_at"].replace("T", " "), "파일": e["file"],
                                        "행": ", ".join(f"{k} {v:,}" for k, v in e["rows"].items())}
                                       for e in reversed(hist)]), hide_index=True, width="stretch")
