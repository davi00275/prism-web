"""RR 리뷰: 새로 계산한 제안 RR을 팀이 같이 보고 정하는 화면 (RR 담당자 프롬프트, docs/run-rate.md 7장).

배치는 RR 담당자 화면 시안 (2026-11-10): 플래그 SKU만 검토, 그 외는 제안 RR 자동 확정.
화면(숫자·목록·요약)에는 Base Item만, 그리고 Base Item은 전부 (사용자 2026-11-11). 계산·검증 탭은 RR 파일 전체 SKU 기준.
RR 파일에 없는 Base Item은 '📝 RR 파일 없음'(검토 필요): 제안 RR 없음, 패널에서 RR 직접 입력.
지난 리뷰 (지난 기준월의 마지막 결정): 목록 '지난 리뷰' 열·필터, 패널 위 한 줄 (사용자 2026-11-11).
  위    숫자 한 줄: 전체 · 자동 확정 · 검토 필요 · 검토 진행(확인·보정·보류) · 남은 검토
  리뷰  범위(검토 필요·내 담당·자동 확정·전체) → 거르기 → 왼쪽 SKU 목록 + 오른쪽 패널 (rr_panel.py)
        목록은 우선순위(상·중·하) → 금액 영향(|Δ| × ASP) 순. 아무 칸이나 누르면 오른쪽 패널, 체크칸으로 여러 개 골라 제안값 적용.
  탭    전체 그림 · 검증 · 기준값
현행(확정, DP list V열)과 제안(v4.2)을 늘 나란히 보여 준다.
수량은 정수로 보인다 (계산은 소수 그대로, 사용자 2026-11-10). 검증 탭만 엑셀처럼 소수.
이 화면은 DP 계산을 바꾸지 않는다.
"""

from collections import Counter

import altair as alt
import pandas as pd
import streamlit as st

import rr_panel
import ui
from hub import codes, rr_engine as E, rr_review as R, service

NOW_C, NEW_C = "#A1A1A6", "#F37321"
UP_C, DOWN_C, HIGH_C, MID_C, LOW_C = "#C2410C", "#1D4ED8", "#D70015", "#B25000", "#8E8E93"
ALL = "전체"

meta = service.rr_meta()
df = service.rr_table()
if not meta or meta.get("missing") or df is None:
    st.title("RR 리뷰")
    st.info("RR 파일이 없습니다. `samples/Run Rate` 폴더에 RR 파일을 저장한 뒤 사이드바 [새 파일 확인]을 실행하십시오.",
            icon=":material/info:")
    st.stop()
full_n = len(df)
df = df[df["in_base"]].reset_index(drop=True)     # 화면에는 Base Item만 (사용자 2026-11-11)
missing = service.rr_base_missing()
p = service.rr_params()
per = meta["periods"]
if done := st.session_state.pop("rr_done", None):
    st.toast(done, icon=":material/check_circle:")


def q(s: pd.Series) -> pd.Series:
    """수량 열 → 정수 (엑셀 반올림). 빈 값은 빈칸."""
    v = pd.to_numeric(s, errors="coerce")
    return pd.Series([pd.NA if pd.isna(x) else int(E.xround(float(x))) for x in v], index=s.index, dtype="Int64")


def total(v) -> str:
    return f"{E.xround(float(v)):,.0f}"


# ---- 위: 숫자 한 줄 ------------------------------------------------------------------
me = service.current_owner()
mine = (df["owner"] == me) if me else pd.Series(False, index=df.index)
need = df[df["review"]]
sc = need["status"].value_counts()
ok, adj, hold = (int(sc.get(s, 0)) for s in (R.CHECKED, R.ADJUSTED, R.HOLD))
left_n = len(need) - ok - adj
auto = int((~df["review"]).sum())
mine_left = int((df["review"] & mine & (df["status"] == R.NOT_YET)).sum())

head = st.columns([2.1, 0.8, 0.9, 0.85, 2.8, 0.85, 1.0], vertical_alignment="center", gap="small")
with head[0]:
    st.title("RR 리뷰", anchor=False)
    st.caption("플래그 SKU만 검토, 그 외는 제안 RR 자동 확정")
head[1].metric("Base Item", f"{len(df):,}",
               help=f"Base Item 전체 (계산·검증은 RR 파일 {full_n - len(missing):,} SKU 기준). K/V 그룹 SKU {int(df['kv'].sum())}개 포함"
               + (f". RR 파일에 없는 {len(missing)}개는 📝 RR 파일 없음 (제안 RR 없음, 직접 입력)" if missing else ""))
with head[2].container(key="rr_k_auto"):
    st.metric("자동 확정", f"{auto:,}", delta=f"{auto / max(len(df), 1):.0%}", delta_color="green", delta_arrow="off",
              help="리뷰 플래그가 없는 SKU. 최종 RR = 제안 RR")
with head[3].container(key="rr_k_need"):
    st.metric("검토 필요", f"{len(need):,}",
              help="리뷰 플래그 " + " ".join(f"{i}{nm}" for c, i, nm, r in E.FLAGS if r) + " 중 하나라도 있는 SKU")
tot = max(len(need), 1)
w = lambda x: f"{x / tot * 100:.2f}%"
head[4].markdown(
    f"<div class='rr-prog'>검토 진행 <b>{ok + adj:,}</b> / {len(need):,}"
    f"<div class='rr-bar'><span class='ok' style='width:{w(ok)}'></span><span class='adj' style='width:{w(adj)}'></span>"
    f"<span class='hold' style='width:{w(hold)}'></span></div>"
    f"<span class='rr-dot ok'></span>확인 {ok:,} &nbsp; <span class='rr-dot adj'></span>보정 {adj:,} &nbsp; "
    f"<span class='rr-dot hold'></span>보류 {hold:,}" + (f" &nbsp;·&nbsp; 내 담당 미검토 {mine_left:,}" if me else "") + "</div>",
    unsafe_allow_html=True)
head[5].metric("남은 검토", f"{left_n:,}", help="검토 필요 중 미확인·미보정 SKU (보류 포함)")
unit = head[6].segmented_control("단위", ["수량", "금액"], default="수량", key="rr_unit", required=True, label_visibility="collapsed")
money = unit == "금액"
asp = pd.to_numeric(df["asp"], errors="coerce").fillna(0)
st.caption(
    f"SI {per['si12'][0]} – {per['si12'][-1]} / SO {per['so12'][0]} – {per['so12'][-1]} / RR 기준일 {per['base_date']} / "
    f"제안 RR {meta.get('params_version')} (현행과 병행운영 중인 제안) / 현행 = DP list V열 · {meta.get('file')} · "
    f"Base Item {len(df):,} (RR 파일 없음 {len(missing):,}) / RR 파일 {full_n - len(missing):,} SKU")


def val(s: pd.Series) -> pd.Series:
    """단위가 금액이면 ASP × 수량."""
    s = pd.to_numeric(s, errors="coerce")
    return s * asp if money else s


def show(v) -> str:
    return f"${E.xround(float(v)):,.0f}" if money else total(v)


if meta.get("param_diff"):
    st.warning("config/rr.yaml 기준값이 RR 파일 'RR Formula' 탭과 다릅니다: "
               + ", ".join(f"{d['key']} {d['config']} ≠ {d['excel']}" for d in meta["param_diff"]), icon=":material/warning:")

tabs = st.tabs(["리뷰", "요약", "검증", "기준값"])

# ---- 리뷰: 왼쪽 목록 + 오른쪽 패널 -----------------------------------------------------
EXTRA = {   # '열' 버튼으로 더 볼 수 있는 열
    "리뷰 상태": lambda v: v["status"], "담당": lambda v: v["owner"].fillna(""), "설명": lambda v: v["item_name"].fillna(""),
    "적용 규칙": lambda v: v["rule"], "Δ": lambda v: q(v["delta"]), "SI6": lambda v: q(v["si6"]), "SI3": lambda v: q(v["si3"]),
    "SO3": lambda v: q(v["so3"]).where(v["has_so"]), "추세": lambda v: v["trend"].round(2),
    "현행 EOH": lambda v: q(v["eoh_current"]), "제안 EOH": lambda v: q(v["proposed_eoh"]), "재고": lambda v: q(v["inv"]),
    "보정 RR": lambda v: q(v["adj_rr"]), "보정 사유": lambda v: v["reason"].fillna(""),
    "Series": lambda v: v["series"].fillna(""), "Type": lambda v: v["product_type"].fillna(""),
    "K/V": lambda v: v["kv_group"].fillna(""), "PL": lambda v: v["pl_status"].fillna(""),
    "SRA 경과(년)": lambda v: v["sra_years"].round(1), "EOP까지(월)": lambda v: v["eop_months"].round(1),
    "SO 12M": lambda v: v["so12"].map(lambda a: [max(float(x), 0) for x in a]),
    "지난 사유": lambda v: v["prev_reason"].fillna(""),
}


def prev_text(v: pd.DataFrame) -> pd.Series:
    """지난 리뷰 한 칸: '11월 보정 25' · '11월 확인' · '11월 보류'. 없으면 빈칸."""
    def one(basis, status, adj):
        if pd.isna(status):
            return ""
        m = f"{int(str(basis)[5:7])}월" if len(str(basis)) >= 7 else str(basis)
        return f"{m} 보정 {E.xround(float(adj)):,.0f}" if status == R.ADJUSTED and pd.notna(adj) else f"{m} {status}"
    return pd.Series([one(b, s, a) for b, s, a in zip(v["prev_basis"], v["prev_status"], v["prev_adj_rr"])], index=v.index)
with tabs[0]:
    scopes = {"검토 필요": df["review"], "내 담당": df["review"] & mine, "자동 확정": ~df["review"],
              "전체": pd.Series(True, index=df.index)}
    if not me:
        scopes.pop("내 담당")
    c = st.columns([3, 1], vertical_alignment="center")
    scope = c[0].segmented_control("범위", list(scopes), default="검토 필요", key="rr_scope", required=True,
                                   format_func=lambda s: f"{s} {int(scopes[s].sum()):,}", label_visibility="collapsed")
    if scope == "내 담당":
        c[1].caption(f"담당 {me} (Windows 사용자 이름)")

    f = st.columns([2.4, 1.1, 1.1, 1.2, 0.9], vertical_alignment="center")
    text = f[0].text_input("검색", key="rr_text", placeholder="SKU · 설명 · 시리즈", icon=":material/search:", label_visibility="collapsed")
    group = f[1].selectbox("구분", [ALL] + sorted(df["product_group"].dropna().unique()), key="rr_group",
                           format_func=lambda v: f"구분: {v}", label_visibility="collapsed")
    plc = f[2].selectbox("PLC", [ALL] + sorted(df["plc"].dropna().unique()), key="rr_plc",
                         format_func=lambda v: f"PLC: {v}", label_visibility="collapsed", help="Item Master PLC (없으면 RR 파일 Sell-out 탭)")
    owner = f[3].selectbox("담당", [ALL] + service.owners() + ["(없음)"], key="rr_owner",
                           format_func=lambda v: f"담당: {v}", label_visibility="collapsed")
    with f[4].popover("추가 필터", width="stretch"):
        series = st.multiselect("시리즈", sorted(df["series"].dropna().unique()), key="rr_series")
        rules = st.multiselect("적용 규칙", [r for r in E.RULES if (df["rule"] == r).any()], key="rr_rule")
        states = st.multiselect("리뷰 상태", R.STATUSES, key="rr_state")
        kvsel = st.segmented_control("K/V", ["전체", "K/V만", "K/V 아님"], default="전체", key="rr_kv", required=True)
        n_prev = int((df["prev_status"] == R.ADJUSTED).sum())
        prev_only = st.toggle(f"지난 리뷰에서 보정한 SKU만 ({n_prev:,})", key="rr_prev_only", disabled=not n_prev,
                              help="지난 기준월에 보정(현행 유지·직접 입력)한 SKU")

    view = df[scopes[scope]]
    if group != ALL:
        view = view[view["product_group"] == group]
    if plc != ALL:
        view = view[view["plc"] == plc]
    if owner != ALL:
        view = view[view["owner"].isna()] if owner == "(없음)" else view[view["owner"] == owner]
    if series:
        view = view[view["series"].isin(series)]
    if rules:
        view = view[view["rule"].isin(rules)]
    if states:
        view = view[view["status"].isin(states)]
    if kvsel != "전체":
        view = view[view["kv"] == (kvsel == "K/V만")]
    if prev_only:
        view = view[view["prev_status"] == R.ADJUSTED]
    if text.strip():
        qn = codes.norm(text)
        hay = view[["item", "item_name", "series"]].fillna("").astype(str).agg(" ".join, axis=1).map(codes.norm)
        view = view[hay.str.contains(qn, regex=False)]
    # 버튼 목록은 그대로 두고(범위를 바꿔도 고른 것이 남게) 숫자만 지금 목록 기준
    counts = Counter(x for fl in view["flags"] for x in fl)
    every = Counter(x for fl in df["flags"] for x in fl)
    picked = st.pills("플래그", [code for code, *_ in E.FLAGS if every.get(code)], selection_mode="multi", key="rr_flags",
                      format_func=lambda code: f"{E.FLAG[code][0]} {E.FLAG[code][1]} {counts.get(code, 0)}", label_visibility="collapsed")
    if picked:
        view = view[view["flags"].map(lambda fl: any(x in fl for x in picked))]
    # 우선순위 → 금액 영향 (|Δ| × ASP) → |Δ|
    impact = (view["delta"].abs() * pd.to_numeric(view["asp"], errors="coerce").fillna(0)).fillna(0)
    view = view.assign(_t=view["priority"].map({p_: i for i, p_ in enumerate(E.PRIORITIES)}).fillna(len(E.PRIORITIES)),
                       _m=impact, _a=view["delta"].abs().fillna(-1))
    view = view.sort_values(["_t", "_m", "_a", "item"], ascending=[True, False, False, True]).drop(columns=["_t", "_m", "_a"])
    view = view.reset_index(drop=True)

    if view.empty:
        st.caption("이 조건에 맞는 SKU가 없습니다.")
    else:
        if st.session_state.get("rr_pick") not in set(view["item"]):
            st.session_state.rr_pick = view["item"].iloc[0]
        left, right = st.columns([1.75, 1], gap="medium")
        with left, st.container(border=True):
            bar = st.columns([2.3, 1.9, 0.75, 0.75], vertical_alignment="center")
            bar[0].markdown(f"**{scope} {len(view):,} SKU** · 우선순위 → 금액 영향 순")
            bulk_slot = bar[1].empty()
            with bar[2].popover("열", icon=":material/view_column:", width="stretch", help="추가 표시 열"):
                extra = st.multiselect("추가 열", list(EXTRA), default=["리뷰 상태"], key="rr_cols")
            # CSV (포털 Forecast Master 업로드 전 검토용): 현행 R/R처럼 정수
            csv = pd.DataFrame({"SKU": view["item"], "설명": view["item_name"], "담당": view["owner"], "우선순위": view["priority"],
                                "현행 RR": q(view["rr_current"]), "제안 RR": q(view["proposed_rr"]), "보정 RR": q(view["adj_rr"]),
                                "최종 RR": q(view["final_rr"]), "사유": view["reason"], "상태": view["status"],
                                "적용 규칙": view["rule"], "플래그": view["flag_icons"],
                                "지난 리뷰": prev_text(view), "지난 사유": view["prev_reason"]})
            bar[3].download_button("CSV", csv.to_csv(index=False).encode("utf-8-sig"), file_name=f"RR 리뷰 {service.rr_basis()}.csv",
                                   mime="text/csv", icon=":material/download:", width="stretch",
                                   help="현재 목록 기준. SKU, 담당, 현행·제안·보정·최종 RR, 사유, 상태 (정수)")

            # 현행 0인데 제안이 있으면 Δ%는 NEW (정렬은 가장 큰 쪽)
            dpct = pd.to_numeric(view["delta_pct"], errors="coerce").astype(float)
            dpct[(pd.to_numeric(view["rr_current"], errors="coerce") == 0) & (view["proposed_rr"] > 0)] = float("inf")
            table = pd.DataFrame({
                "SKU": view["item"], "우선": view["priority"],
                "구분 · PLC": view["product_group"].fillna("") + view["plc"].map(lambda x: "" if pd.isna(x) else f" · {x}"),
                "현행": q(view["rr_current"]), "제안": q(view["proposed_rr"]), "Δ%": dpct,
                "최종": q(view["final_rr"]).mask(view["open"]),
                "지난 리뷰": prev_text(view),
                "SI 12M": view["si12"].map(lambda a: [max(float(x), 0) for x in a]),
                "SO 6M": q(view["so6"]).where(view["has_so"]), "재고개월": view["inv_months"],
                "플래그": view["flags"].map(lambda fl: [f"{E.FLAG[x][0]} {E.FLAG[x][1]}" for x in fl])})
            if money:
                a = pd.to_numeric(view["asp"], errors="coerce").fillna(0)
                table.insert(table.columns.get_loc("Δ%") + 1, "Δ 금액", (pd.to_numeric(view["delta"]) * a).round(0))
            if not (table["지난 리뷰"] != "").any():
                table = table.drop(columns=["지난 리뷰"])     # 지난 리뷰가 하나도 없으면 (첫 달) 열을 숨긴다
            for name in extra:
                table[name] = EXTRA[name](view)

            delta_up = table["Δ%"] > 0
            delta_down = table["Δ%"] < 0

            def _style(t: pd.DataFrame) -> pd.DataFrame:
                css = pd.DataFrame("", index=t.index, columns=t.columns)
                css["우선"] = t["우선"].map({E.HIGH: f"color:{HIGH_C};font-weight:700", E.MID: f"color:{MID_C};font-weight:600",
                                           E.LOW: f"color:{LOW_C}"}).fillna("")
                css.loc[delta_up.to_numpy(), "Δ%"] = f"color:{UP_C}"
                css.loc[delta_down.to_numpy(), "Δ%"] = f"color:{DOWN_C}"
                css["제안"] = "font-weight:600"
                return css

            def fmt_of(c_):
                if c_ == "Δ%":
                    return lambda v: "NEW" if v == float("inf") else f"{v:+.1%}"
                if c_ in ("재고개월", "SRA 경과(년)", "EOP까지(월)"):
                    return lambda v: f"{v:.1f}"
                if c_ == "추세":
                    return lambda v: f"{v:.2f}"
                return (lambda v: f"{'-' if v < 0 else '+' if v > 0 else ''}${abs(v):,.0f}") if c_ == "Δ 금액" else (lambda v: f"{v:,.0f}")

            # 빈 칸이 있는 숫자 열은 글자로 ('–'). 숫자 열의 빈 값은 표에 'None'으로 보여서 (na_rep도 안 먹음)
            helps = {"현행": "현행 R/R (DP list V열)", "제안": f"제안 RR {p.get('version')}", "Δ%": "(제안 − 현행) ÷ 현행. NEW = 현행 0",
                     "최종": "확정 RR. 검토 필요 SKU가 미검토·보류이면 – (자동 확정은 제안 RR)",
                     "SO 6M": f"Sell-out 6개월 평균 (캡 후) {per['so6'][0]} – {per['so6'][-1]}. – = Sell-out 없음",
                     "재고개월": "OH(CFC5 + SCA3) ÷ 최종 RR (최신 재고 파일). – = RR 0 또는 재고 정보 없음",
                     "지난 리뷰": "지난 기준월의 마지막 결정 (보정이면 보정 RR). 상세는 SKU 선택 시 패널 상단"}
            cfg = {"SKU": st.column_config.TextColumn(pinned=True),
                   "우선": st.column_config.TextColumn(width=48, help="우선순위: 상 = 🔴✋, 중 = 🟡⚠🏗, 하 = 🔵🟢📈📉 (Claude 제안)"),
                   "SI 12M": st.column_config.BarChartColumn(y_min=0, width="small", help=f"Sell-in {per['si12'][0]} – {per['si12'][-1]}"),
                   "플래그": st.column_config.ListColumn(width="medium"),
                   "지난 리뷰": st.column_config.TextColumn(width="small", help="지난 기준월의 마지막 결정 (보정이면 보정 RR). 상세는 SKU 선택 시 패널 상단"),
                   "SO 12M": st.column_config.LineChartColumn(y_min=0, width="small")}
            fmt = {}
            for c_ in table.columns:
                if c_ in cfg or not (pd.api.types.is_numeric_dtype(table[c_]) or str(table[c_].dtype) == "Int64"):
                    continue
                col = pd.to_numeric(table[c_], errors="coerce").astype(float)
                if col.isna().any():
                    f_ = fmt_of(c_)
                    table[c_] = col.map(lambda v, f_=f_: "–" if pd.isna(v) else f_(v))
                    cfg[c_] = st.column_config.TextColumn(alignment="right", help=helps.get(c_))
                else:
                    table[c_] = col
                    fmt[c_] = fmt_of(c_)
                    cfg[c_] = st.column_config.NumberColumn(help=helps.get(c_))
            nonce = st.session_state.get("rr_list_nonce", 0)
            table_key = f"rr_list_{nonce}_{abs(hash((scope, group, plc, owner, text, tuple(series), tuple(rules), tuple(states), kvsel, prev_only, tuple(picked))))}"
            event = st.dataframe(
                table.style.apply(_style, axis=None).format(fmt), key=table_key, hide_index=True, width="stretch",
                height=min(38 + 35 * len(table), 740), on_select="rerun", selection_mode=["multi-row", "single-cell"],
                column_config=cfg)
            # SKU 칸을 누르면 오른쪽 패널 (다른 칸은 그대로, 사용자 2026-11-11). 누른 칸이 그대로면(◀ ▶로 넘긴 뒤) 건드리지 않는다
            clicked = ui.clicked_row(event, "SKU")
            if clicked != st.session_state.get(f"{table_key}_last"):
                st.session_state[f"{table_key}_last"] = clicked
                if clicked is not None and clicked < len(view):
                    st.session_state.rr_pick = view["item"].iloc[clicked]
            # 제안 RR이 없는 SKU(📝 RR 파일 없음)는 제안값 적용에서 뺀다
            rows = [r for r in event.selection.rows if r < len(view) and pd.notna(view["proposed_rr"].iloc[r])]
            if bulk_slot.button(f"선택 {len(rows)}개 제안값 적용" if rows else "선택 항목 제안값 적용", key="rr_bulk", width="stretch",
                                icon=":material/done_all:", disabled=not rows,
                                help="체크한 SKU를 '확인' 처리 (최종 RR = 제안 RR, 보정 RR 삭제). 📝 RR 파일 없음 SKU 제외"):
                sub = view.iloc[rows]
                recs = sub.to_dict("records")
                before = [{"item": r["item"], "adj_rr": r["adj_rr"], "reason": r["reason"], "status": r["status"]} for r in recs]
                after = [{**b, "adj_rr": None, "status": R.CHECKED, "rr_current": r["rr_current"], "proposed_rr": r["proposed_rr"]}
                         for b, r in zip(before, recs)]
                st.session_state.rr_done = service.save_rr_reviews(before, after)
                st.session_state.rr_list_nonce = nonce + 1
                st.rerun()
            st.caption(f"{len(view):,}개 · SKU 칸 선택 시 우측 상세 · 체크 후 [제안값 적용]으로 일괄 확인 · "
                       "'최종' – = 미결정")
        with right:
            rr_panel.panel(view, p, per)

# ---- 요약 (Base Item) ---------------------------------------------------------------------------
with tabs[1]:
    st.caption(("금액 = ASP(DP list G열) × RR. " if money else "") + "현행 = DP list V열, 제안 = v4.2 계산, 최종 = 보정 RR이 있으면 그 값.")
    k = st.columns(4)
    cur, new, fin = val(df["rr_current"]).sum(), val(df["proposed_rr"]).sum(), val(df["final_rr"]).sum()
    k[0].metric("제안 RR 합계", show(new), delta=f"{E.xround(new - cur):+,.0f} ({(new - cur) / cur:+.1%})" if cur else None,
                delta_color="off", help=f"현행 R/R 합계(DP list V열) {show(cur)} 대비")
    k[1].metric("최종 RR 합계", show(fin), help="보정 SKU는 보정 RR, 그 외 제안 RR")
    ce, ne = val(df["eoh_current"]).sum(), val(df["proposed_eoh"]).sum()
    k[2].metric("제안 EOH 합계", show(ne), delta=f"{E.xround(ne - ce):+,.0f} ({(ne - ce) / ce:+.1%})" if ce else None, delta_color="off",
                help=f"현행 EOH 합계(DP list BS열) {show(ce)} 대비")
    k[3].metric("제안 RR 0 SKU", f"{int((df['proposed_rr'] == 0).sum()):,}")
    st.caption(f"현행 RR {show(cur)} → 제안 {show(new)} · 현행 EOH {show(ce)} → 제안 {show(ne)}")
    g = pd.DataFrame({"제품군": df["product_group"].fillna("(없음)"), "현행": val(df["rr_current"]), "제안": val(df["proposed_rr"]),
                      "최종": val(df["final_rr"])}).groupby("제품군", as_index=False).sum()
    c = st.columns([3, 2])
    with c[0]:
        st.markdown("**제품군별 RR 합계**")
        long = g.melt(id_vars="제품군", value_vars=["현행", "제안"], var_name="구분", value_name="값")
        long["표시"] = long["값"].map(show)
        st.altair_chart(alt.Chart(long).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
            x=alt.X("제품군:N", title=None, axis=alt.Axis(labelAngle=0)), xOffset="구분:N",
            y=alt.Y("값:Q", title="$" if money else "대/월"),
            color=alt.Color("구분:N", scale=alt.Scale(domain=["현행", "제안"], range=[NOW_C, NEW_C]), legend=alt.Legend(orient="top", title=None)),
            tooltip=["제품군:N", "구분:N", alt.Tooltip("표시:N", title="합계")]).properties(height=260), width="stretch")
    with c[1]:
        st.markdown("**제품군 표**")
        gt = g.assign(Δ=g["제안"] - g["현행"])
        st.dataframe(gt.style.format(lambda v: show(v), subset=["현행", "제안", "최종", "Δ"]), hide_index=True, width="stretch")

    st.markdown("**적용 규칙별**")
    r = pd.DataFrame({"적용 규칙": df["rule"], "현행": val(df["rr_current"]), "제안": val(df["proposed_rr"])})
    rt = r.groupby("적용 규칙").agg(SKU=("제안", "size"), 현행=("현행", "sum"), 제안=("제안", "sum")).reindex(
        [x for x in E.RULES if (df["rule"] == x).any()]).reset_index()
    rt["설명"] = rt["적용 규칙"].map(E.WHY)
    st.dataframe(rt.style.format(lambda v: show(v), subset=["현행", "제안"]), hide_index=True, width="stretch")

    st.markdown("**현행 대비 변화**")
    d = q(df["delta"])
    k = st.columns(4)
    k[0].metric("증가", f"{int((d > 0).sum()):,}")
    k[1].metric("감소", f"{int((d < 0).sum()):,}")
    k[2].metric("유지", f"{int((d == 0).sum()):,}", help="반올림 Δ = 0")
    k[3].metric("현행 없음", f"{int(d.isna().sum()):,}")
    c = st.columns(2)
    for col, title, asc in ((c[0], "증가 상위 10", False), (c[1], "감소 상위 10", True)):
        t = df.dropna(subset=["delta"]).sort_values("delta", ascending=asc).head(10)
        t = t[t["delta"] > 0] if not asc else t[t["delta"] < 0]
        col.markdown(f"**{title}**")
        col.dataframe(pd.DataFrame({"SKU": t["item"], "현행": q(t["rr_current"]), "제안": q(t["proposed_rr"]), "Δ": q(t["delta"]),
                                    "적용 규칙": t["rule"]}), hide_index=True, width="stretch")

    st.markdown("**플래그별 SKU 수**")
    all_counts = Counter(x for fl in df["flags"] for x in fl)
    st.dataframe(pd.DataFrame([{"플래그": f"{i} {nm}", "SKU": all_counts.get(code, 0), "리뷰": "검토 필요" if rv else "참고",
                                "우선순위": E.PRIORITY.get(code, ""), "기준": E.flag_rule(code, p)}
                               for code, i, nm, rv in E.FLAGS]), hide_index=True, width="stretch")
    st.caption("'리뷰' 탭 플래그 버튼으로 해당 플래그 필터.")
    if missing:
        st.caption(f"RR 파일에 없는 Base Item {len(missing):,}개는 제안 RR이 없어 합계에서 제외, 직접 입력하면 최종 RR 합계에 포함 "
                   "('리뷰' 탭 📝 RR 파일 없음).")

# ---- 검증 ----------------------------------------------------------------------------
with tabs[2]:
    v = meta.get("validation")
    if not v:
        st.info("RR 파일에 '이전 RR 현행 RR' 탭이 없어 엑셀 결과 대조를 생략했습니다.", icon=":material/info:")
    else:
        st.caption("RR 파일 전체 SKU 기준 (Base Item 외 포함). "
                   "엑셀 '이전 RR 현행 RR' 탭 값(기준)과 원재료 재계산 값을 SKU별 비교. 차이 발생 시 엑셀 기준. "
                   "이 탭만 엑셀과 동일하게 소수 표시.")
        k = st.columns(3)
        k[0].metric("엑셀과 모든 값이 같은 SKU", f"{v['all_match']:,} / {v['items']:,}")
        k[1].metric("다른 SKU", f"{v['items'] - v['all_match']:,}")
        cols = pd.DataFrame(v["columns"])
        k[2].metric("비교한 열", f"{len(cols):,}", help="W:AT 12개월 값 + 엑셀 계산 열")
        if v.get("by_stage"):
            st.markdown("**처음 어긋나는 단계**")
            st.dataframe(pd.DataFrame([{"단계": s, "SKU": n_} for s, n_ in v["by_stage"].items()]), hide_index=True)
        cols["일치율"] = cols["match"] / cols["total"]
        cols["column"] = cols["column"].map(lambda c_: E.LABELS.get(c_, c_))
        st.markdown("**열별 일치**")
        st.dataframe(cols.rename(columns={"column": "열", "excel_col": "엑셀 열", "match": "일치", "total": "전체"})
                     .sort_values("일치율"), hide_index=True, width="stretch",
                     column_config={"일치율": st.column_config.ProgressColumn(format="percent", min_value=0, max_value=1)})
        chk = service.rr_check()
        if len(chk):
            st.markdown("**어긋난 SKU**")
            chk = chk.assign(column=chk["column"].map(lambda c_: E.LABELS.get(c_, c_)),
                             columns=chk["columns"].map(lambda t: ", ".join(E.LABELS.get(x, x) for x in str(t).split(", "))))
            st.dataframe(chk.rename(columns={"item": "SKU", "stage": "단계", "column": "처음 다른 열", "excel": "엑셀", "engine": "계산",
                                             "columns": "다른 열 전부"}), hide_index=True, width="stretch")
            st.caption("2026-11-10 샘플: RR 위험 플래그 5개는 엑셀 규칙 설명과 불일치, RR 담당자 확인 중 (docs/run-rate.md 5장).")

# ---- 기준값 ---------------------------------------------------------------------------
with tabs[3]:
    st.caption(f"계산 기준값은 `config/rr.yaml` (버전 {p.get('version')}, {p.get('updated')}). 버전 변경 시 이 파일만 수정. "
               "RR 파일 'RR Formula' 탭 값과 다르면 상단에 알림 표시.")
    formula = meta.get("formula") or {}

    def flat(d, pre=""):
        for kk, vv in d.items():
            if isinstance(vv, dict):
                yield from flat(vv, f"{pre}{kk}.")
            else:
                yield f"{pre}{kk}", vv
    rows = [{"항목": E.PARAM_LABELS.get(kk, kk), "키": kk, "값 (config)": str(vv), "RR Formula 탭": "" if kk not in formula else str(formula[kk]),
             "같음": "" if kk not in formula else ("예" if str(formula[kk]) == str(vv) or (
                 isinstance(vv, (int, float)) and isinstance(formula[kk], (int, float)) and abs(vv - formula[kk]) < 1e-9) else "다름")}
            for kk, vv in flat(p) if kk not in ("version", "updated")]
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=420)
    st.markdown(
        f"- 기간: SI 12M {per['si12'][0]} – {per['si12'][-1]}, SO 12M {per['so12'][0]} – {per['so12'][-1]} (POS {per['pos_lag']}개월 지연, 자동)\n"
        f"- RR 기준일 {per['base_date']} · 리뷰 기준월 {per['basis']}\n"
        f"- 아이템 마스터: {meta.get('master_source')}\n"
        f"- 프로젝트 보정 (v4.2): {meta.get('project_status') or (meta.get('formula') or {}).get('project_status') or '–'}\n"
        "- 담당·PLC = Item Master, OH = 최신 재고 파일 CFC5 + SCA3 (허브 데이터, RR 계산 미사용)\n"
        "- **데이터 미연결** (값을 만들지 않음): ADI 채널재고 보정 · 수동 RR(⑧, DP list CA열 비어 있음 → 현행 R/R 임시) · 프로젝트 원천 라인(Proj_Lines)")
