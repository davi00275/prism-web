"""프로젝트: 프로젝트 정보를 넣고 PO(S/O) 데이터와 맞춰 오더가 얼마나 들어왔는지 본다 (사용자 2026-11-10, docs/project-info.md).

1. 프로젝트 넣기: 표에 바로 쓴다 (여러 줄, 엑셀에서 붙여 넣기). [저장]을 눌러야 저장되고, 바꾼 줄만 저장한다.
2. 오더 확인: 숫자 카드 → 목록 (넣은 금액·오더 금액·오더율·남은 금액·상태) → 줄을 누르면 그 PO의 아이템별 수량·금액 (◀ ▶).
지금은 베이스(껍데기). 기능 디테일은 쓰면서 하나씩 더한다.
"""

import pandas as pd
import streamlit as st

import ui
from hub import codes, projects as P, service

STATUS_COLOR = {P.FULL: "green", P.PARTIAL: "blue", P.OVER: "orange", P.NO_ORDER: "gray", P.NO_PO: "gray"}
money = lambda v: "–" if v is None or pd.isna(v) else f"${v:,.0f}"
pct = lambda v: "–" if v is None or pd.isna(v) else f"{v:.0%}"

st.title("프로젝트")
info = service.project_po_info()
st.caption("프로젝트 PO#를 PO 데이터의 Customer PO와 매칭하여 오더 진행률 표시. "
           + (f"PO 데이터: {info['file']} ({info['file_date']} 파일)" if info["file"]
              else "PO 데이터가 없습니다 (데이터 → 데이터 현황)."))
if done := st.session_state.pop("pj_done", None):
    st.toast(done, icon=":material/check_circle:")

rows = service.projects()

# ---- 1. 프로젝트 넣기 ------------------------------------------------------------
with st.container(border=True, key="pj_input"):
    st.subheader("프로젝트 등록", anchor=False)
    base = rows[["id"] + P.FIELDS].copy()
    base["date"] = pd.to_datetime(base["date"], errors="coerce")
    base["amount"] = pd.to_numeric(base["amount"], errors="coerce")
    for c in ("project", "po", "distributor", "rsm"):
        base[c] = base[c].astype(object).where(base[c].notna(), "")     # 빈칸을 'None' 대신 빈칸으로
    base["id"] = base["id"].astype(object)
    nonce = st.session_state.get("pj_nonce", 0)
    edited = st.data_editor(
        base, key=f"pj_editor_{nonce}", num_rows="dynamic", hide_index=True, width="stretch", column_order=P.FIELDS,
        height=min(38 + 35 * (len(base) + 2), 420),
        column_config={
            "project": st.column_config.TextColumn("프로젝트", width="medium"),
            "po": st.column_config.TextColumn("PO#", help="PO 데이터 Customer PO와 매칭 (공백·대소문자 무시)"),
            "date": st.column_config.DateColumn("날짜", format="YYYY-MM-DD"),
            "distributor": st.column_config.TextColumn("Distributor"),
            "amount": st.column_config.NumberColumn("Amount ($)", format="dollar", min_value=0),
            "rsm": st.column_config.TextColumn("RSM/DSM"),
        })
    before, after = base.to_dict("records"), edited.to_dict("records")
    _, counts = P.diff(before, after)
    pending = sum(counts.values())
    c = st.columns([4, 1.2, 1], vertical_alignment="center")
    c[0].caption("하단 빈 행에 입력 시 행 추가. 엑셀 다중 행 붙여넣기 가능. "
                 "삭제: 행 좌측 칸 선택 후 휴지통 클릭."
                 + (f" **미저장 {pending}행**" if pending else ""))
    if c[1].button("저장", type="primary", icon=":material/save:", width="stretch", disabled=not pending, key="pj_save"):
        st.session_state.pj_done = service.save_projects(before, after)
        st.session_state.pj_nonce = nonce + 1
        st.rerun()
    if c[2].button("취소", width="stretch", disabled=not pending, key="pj_cancel"):
        st.session_state.pj_nonce = nonce + 1
        st.rerun()

# ---- 2. 오더 확인 ----------------------------------------------------------------
if rows.empty:
    st.info("상단 표에 프로젝트 입력 후 [저장] 시 PO 데이터 매칭 결과 표시.", icon=":material/info:")
    st.stop()

st.subheader("오더 확인", anchor=False)
with st.container(border=True, key="pj_summary"):
    k = st.columns(4)
    entered = pd.to_numeric(rows["amount"], errors="coerce")
    ordered = rows.loc[entered > 0, "so_amount"].sum()
    k[0].metric("프로젝트", f"{len(rows):,}", help=f"PO 데이터와 맞은 프로젝트 {int((rows['so_count'] > 0).sum())}개")
    k[1].metric("프로젝트 금액", money(entered.sum()))
    k[2].metric("오더 금액", money(rows["so_amount"].sum()))
    k[3].metric("오더율", pct(ordered / entered[entered > 0].sum()) if (entered > 0).any() else "–",
                help="프로젝트 금액 입력 건만: 오더 금액 ÷ 프로젝트 금액")

c = st.columns([2, 5], vertical_alignment="center")
text = c[0].text_input("검색", key="pj_text", placeholder="프로젝트·PO#·Distributor·RSM/DSM", icon=":material/search:",
                       label_visibility="collapsed")
counts = rows["status"].value_counts()
kinds = ["전체"] + [k_ for k_ in (P.PARTIAL, P.NO_ORDER, P.FULL, P.OVER, P.NO_PO) if counts.get(k_)]
pick = c[1].segmented_control("상태", kinds, default="전체", key="pj_status", required=True, label_visibility="collapsed",
                              format_func=lambda s: f"{s} {len(rows) if s == '전체' else counts.get(s, 0)}")
view = rows if pick == "전체" else rows[rows["status"] == pick]
if text.strip():
    q = codes.norm(text)
    hay = view[["project", "po", "distributor", "rsm"]].fillna("").astype(str).agg(" ".join, axis=1).map(codes.norm)
    view = view[hay.str.contains(q, regex=False)]
view = view.reset_index(drop=True)
if view.empty:
    st.caption("조건에 맞는 프로젝트가 없습니다.")
    st.stop()

table = pd.DataFrame({     # 자주 보는 것(상태·오더율·금액)을 앞에
    "프로젝트": view["project"], "PO#": view["po"], "상태": view["status"], "오더율": view["pct"],
    "프로젝트 금액": pd.to_numeric(view["amount"], errors="coerce"), "오더 금액": view["so_amount"], "남은 금액": view["left"],
    "Distributor": view["distributor"], "RSM/DSM": view["rsm"], "날짜": pd.to_datetime(view["date"], errors="coerce")})
MONEY = ["프로젝트 금액", "오더 금액", "남은 금액"]
nonce = st.session_state.get("pj_list_nonce", 0)
event = st.dataframe(
    table.style.format(lambda v: "" if pd.isna(v) else f"${v:,.0f}", subset=MONEY), hide_index=True, width="stretch", height=min(38 + 35 * len(table), 420), on_select="rerun",
    selection_mode=ui.CLICK_MODES, key=f"pj_list_{nonce}",
    column_config={
        "날짜": st.column_config.DateColumn(format="YYYY-MM-DD"),
        "남은 금액": st.column_config.NumberColumn(help="프로젝트 금액 − 오더 금액. 음수 = 프로젝트 금액 초과 오더"),
        "오더율": st.column_config.ProgressColumn(format="percent", min_value=0, max_value=1,
                                               help="오더 금액 ÷ 프로젝트 금액. 100% 초과 시 막대 최대, 수치로 표시"),
    })
row = ui.clicked_row(event)
if row is not None:
    st.session_state.pj_pick = view.iloc[row]["id"]
    st.session_state.pj_list_nonce = nonce + 1     # 표 선택을 비운다 (◀ ▶로 넘길 때 다시 잡히지 않게)
    st.rerun()
st.caption("행 선택 시 하단에 해당 PO Item 표시.")

# ---- 자세히: 그 PO의 아이템 ----------------------------------------------------------
ids = view["id"].tolist()
pick_id = st.session_state.get("pj_pick")
if pick_id not in ids:
    st.stop()
i = ids.index(pick_id)
r = view.iloc[i]
with st.container(border=True, key="pj_detail"):
    c = st.columns([6, 1, 1], vertical_alignment="center")
    c[0].markdown(f"### {r['project'] or '(이름 없음)'} · PO# {r['po'] or '–'} {ui.badge(r['status'], STATUS_COLOR[r['status']])}")
    if c[1].button("◀", key="pj_prev", width="stretch", disabled=i == 0):
        st.session_state.pj_pick = ids[i - 1]
        st.rerun()
    if c[2].button("▶", key="pj_next", width="stretch", disabled=i == len(ids) - 1):
        st.session_state.pj_pick = ids[i + 1]
        st.rerun()
    k = st.columns(4)
    k[0].metric("프로젝트 금액", money(pd.to_numeric(r["amount"], errors="coerce")))
    k[1].metric("오더 금액", money(r["so_amount"]))
    k[2].metric("오더율", pct(r["pct"]))
    k[3].metric("남은 금액", money(r["left"]))
    lines = service.project_detail(r["po"]) if r["po"] else pd.DataFrame()
    if lines.empty:
        st.info("PO# 입력 시 PO 데이터에서 조회합니다." if r["status"] == P.NO_PO else
                f"PO 데이터에 Customer PO '{r['po']}'가 없습니다. 오더 미접수 또는 PO# 불일치 가능.",
                icon=":material/info:")
        st.stop()
    sold_to = ", ".join(sorted(set(lines["sold_to"].dropna())))
    reps = ", ".join(sorted(set(lines["sales_rep"].dropna())))
    facts = [f"S/O {', '.join(sorted(set(lines['so_no'].dropna())))}",
             f"S/O 날짜 {lines['so_date'].min():%Y-%m-%d}" if lines["so_date"].notna().any() else None,
             f"Sold-to {sold_to}" + (f" (입력 Distributor: {r['distributor']})" if r["distributor"] else ""),
             f"Ship-to {', '.join(sorted(set(lines['ship_to'].dropna())))}",
             f"영업 담당 {reps}" + (f" (입력 RSM/DSM: {r['rsm']})" if r["rsm"] else "")]
    st.caption(" · ".join(f for f in facts if f))
    if (lines["currency"].dropna() != "USD").any():
        st.warning("USD 외 통화 행 포함 · 금액 단순 합산, 확인 필요.", icon=":material/warning:")
    if lines["rejected_qty"].sum() > 0:
        st.warning(f"거절 수량 포함 행 ({lines['rejected_qty'].sum():,.0f}개) · 금액은 파일 값 그대로 합산, 확인 필요.",
                   icon=":material/warning:")

    items = (lines.groupby(["item", "item_name"], dropna=False, as_index=False, sort=False)
             .agg(qty=("qty", "sum"), amount=("amount", "sum"), billed_qty=("billed_qty", "sum"),
                  billed_amount=("billed_amount", "sum"), rejected_qty=("rejected_qty", "sum"),
                  so=("so_no", lambda s: ", ".join(sorted(set(s.dropna()))))))
    items["price"] = (items["amount"] / items["qty"].where(items["qty"] != 0)).map(lambda v: "" if pd.isna(v) else f"${v:,.2f}")
    shown = items.rename(columns={"item_name": "품명", "qty": "수량", "price": "단가", "amount": "금액", "billed_qty": "청구 수량",
                                  "billed_amount": "청구 금액", "rejected_qty": "거절 수량", "so": "S/O No"})
    st.markdown(f"**아이템 {len(items):,}개 · 수량 {items['qty'].sum():,.0f} · 금액 {money(items['amount'].sum())}**")
    ui.item_table(shown, ["item", "품명", "수량", "단가", "금액", "청구 수량", "청구 금액", "거절 수량", "S/O No"],
                  key=f"pj_items_{pick_id}", height=min(54 + 35 * len(shown), 420), hide_zero=True)
    st.caption("Item 선택 시 Item 360 이동.")
    with st.expander(f"S/O 줄 {len(lines):,}개"):
        st.dataframe(lines.rename(columns={"so_no": "S/O No", "so_item": "줄", "item": "아이템", "item_name": "품명", "qty": "수량",
                                           "price": "단가", "amount": "금액", "billed_qty": "청구 수량", "rejected_qty": "거절 수량",
                                           "so_date": "S/O 날짜", "ship_to": "Ship-to"})
                     [["S/O No", "줄", "아이템", "품명", "수량", "단가", "금액", "청구 수량", "거절 수량", "S/O 날짜", "Ship-to"]],
                     hide_index=True, width="stretch",
                     column_config={"단가": st.column_config.NumberColumn(format="dollar"),
                                    "금액": st.column_config.NumberColumn(format="dollar"),
                                    "S/O 날짜": st.column_config.DateColumn(format="YYYY-MM-DD")})
