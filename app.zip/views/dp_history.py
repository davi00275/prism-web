"""DP 기록: 주차마다 각자 확정한 최종 DP를 나열해 본다 (사용자 2026-11-03: 지난주에 어떻게 최종 DP가 되었는지,
주차가 지날수록 쌓이는 것을 쭉 볼 수 있어야 한다).

  위     주차 목록 (최근부터): 확정한 사람, 업로드 행, 자원점검·AIR·VSL 합계
  아래   고른 주차의 확정 표 (아이템을 누르면 Item 360 → 'DP 이력' 탭에서 주차별로), 업로드 파일 다시 받기
기록은 hub/dp_history.py (공유 폴더 'HVA SCM 입력\\DP 확정\\<주차>\\<이름>.jsonl').
"""

import pandas as pd
import streamlit as st

import ui
from hub import dp_engine as E, service

st.title("DP 이력")

weeks = service.confirmed_weeks()
if not weeks:
    st.info("확정 이력이 없습니다. '금주 DP'에서 담당 선택 후 확정 시 기록됩니다.",
            icon=":material/history:")
    st.page_link("views/dp_plan.py", label="금주 DP 바로가기", icon=":material/calculate:")
    st.stop()

# ---- 주차 목록 ----------------------------------------------------------------
summary = []
for w in weeks:
    df = service.week_snapshot(w["week"])
    up = df[df["upload"].astype(bool)] if len(df) else df
    summary.append({"주차": w["week"], "확정 담당": ", ".join(w["owners"]), "Item": len(df), "업로드": len(up),
                    "자원점검": round(up["resource_check"].sum()) if len(up) else 0,
                    "AIR": round(up["air"].sum()) if len(up) else 0,
                    "VSL / TRK": round(up["vsl"].sum()) if len(up) else 0,
                    "수정 Item": int(df["edited"].astype(bool).sum()) if len(df) else 0})
st.dataframe(pd.DataFrame(summary), hide_index=True, width="stretch", column_config={
    c: st.column_config.NumberColumn(c, format="localized") for c in ("자원점검", "AIR", "VSL / TRK")})

# ---- 주차 하나 --------------------------------------------------------------------
c = st.columns([1.2, 1.5, 3], vertical_alignment="bottom")
week = c[0].selectbox("주차", [w["week"] for w in weeks], key="hist_week")
owners = next(w["owners"] for w in weeks if w["week"] == week)
me = service.current_owner()
pick = c[1].selectbox("담당", ["전체"] + owners, key="hist_owner",
                      index=(owners.index(me) + 1) if me in owners else 0)
only_upload = c[2].toggle("자원점검 대상 Item만", value=False, key="hist_upload")

snap = service.week_snapshot(week, None if pick == "전체" else pick)
if only_upload:
    snap = snap[snap["upload"].astype(bool)]
snap = snap.sort_values(["owner", "item"]).reset_index(drop=True)

first = service.week_snapshot(week).iloc[0]
dates = first.get("data_dates") or {}
st.caption(f"{week} · 기준 목요일 {first['base_date']} · M1 잔여 근무일 비율 {first['workday_ratio']:.2f} · "
           f"데이터: 재고 {dates.get('inventory', '–')}, 주문 {dates.get('orders', '–')}, 반품 {dates.get('returns', '–')}, "
           f"ADI {dates.get('adi', '–')}, 입고 {dates.get('sync_plan', '–')} − GR {dates.get('gr_total', 0) or 0:,.0f}, "
           f"R/R·EOH {dates.get('dp_file', '–')} (W{dates.get('dp_file_week', '–')})")
confirm = (snap.groupby("owner")[["confirmed_by", "confirmed_at", "memo"]].first() if len(snap) else pd.DataFrame())
if len(confirm):
    st.caption(" · ".join(f"{o}: {r.confirmed_at[5:16].replace('T', ' ')} 확정 ({r.confirmed_by})"
                          + (f" — {r.memo}" if r.memo else "") for o, r in confirm.iterrows()))

# 지난 주차 확정과 비교 (같은 아이템의 자원점검)
older = [w["week"] for w in weeks if w["week"] < week]
prev = service.week_snapshot(older[0]) if older else pd.DataFrame()

if snap.empty:
    st.info("조건에 맞는 Item이 없습니다.")
else:
    table = pd.DataFrame({"item": snap["item"], "담당": snap["owner"]})
    for i in range(1, E.MAX_MONTHS + 1):
        m = snap[f"month_m{i}"].dropna()
        if len(m):
            table[f"M{i} {E.month_label(m.iloc[0])}"] = snap[f"demand_m{i}"].round(0)
    table["자원점검"] = snap["resource_check"].round(0)
    if len(prev):
        table[f"{older[0].split('-')[-1]} 확정"] = snap["item"].map(prev.set_index("item")["resource_check"]).round(0)
    table["AIR"] = snap["air"]
    table["VSL / TRK"] = snap["vsl"]
    table["Remarks"] = snap["remarks"].fillna("")
    table["계산값"] = snap["calc_resource_check"].round(0)
    table["수정 내용"] = snap["edit_note"].fillna("")
    table["R/R"] = snap["rr"].round(0)
    table["EOH"] = snap["eoh"].round(0)
    ui.item_table(table, list(table.columns), key="hist_table", height=min(38 + 35 * len(table), 560))
    st.caption(f"{len(table):,}개 · 업로드 합계 AIR {ui.fmt(snap['air'].sum())} / VSL {ui.fmt(snap['vsl'].sum())}. "
               "계산값 = 수정 전 자원점검. Item 선택 시 Item 360 'DP 이력' 탭에서 주차별 조회.")

if pick != "전체":
    got = service.upload_file(pick, week)
    if got:
        st.download_button(f"{week} {pick} 업로드 파일 재다운로드", got[0], file_name=got[1], icon=":material/download:",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
