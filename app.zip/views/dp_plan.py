"""금주 DP: 금요일에 M1~M3 수량을 정해서 확정한다. Base Item 전부를 계산한다 (0이어도 계산).

흐름 (사용자 2026-10-28, 2026-11-03, 2026-11-06):
  금요일 여기서 M1~M3 확정 → 주말 본사 자원점검 → 월요일 '자원점검 업로드'에서 AIR를 나누고 업로드
  위       W45 · DP 목·금 · 기간, 거르기, 보기, 확정 줄 (담당 하나를 고르면: 진행 상태 · [확정하기] · [DP 표 받기])
  왼쪽     아이템 목록 (또는 팀 수정 기록). 아무 칸이나 누르면 오른쪽 패널에 그 아이템
  오른쪽   아이템 패널 (dp_panel.py): 결론 → 근거 → 고치기(미리보기) → 기록. ◀ ▶로 목록 순서대로 넘긴다
  '표에서 여러 개 고치기'   여러 아이템을 표 칸에서 바로 고친다 (패널 없이 넓게)
주차는 오늘 날짜로 (hub/dp_engine.py calendar), 고친 값은 hub/inputs.py, 확정 기록은 hub/dp_history.py.
각자 확정·각자 업로드 (사용자 2026-11-03).
"""

from datetime import date

import pandas as pd
import streamlit as st

import dp_panel
import ui
from hub import dp_engine as E, metrics as M, service

meta = service.dp_plan_meta()
if not meta or service.dp_plan() is None:
    st.title("금주 DP")
    st.error("DP 계산 입력이 없습니다. '데이터 현황'에서 DP 파일 상태를 확인하십시오.")
    st.stop()

# 데이터 기준: 기본은 최신 파일·오늘 날짜. 'DP 파일 데이터 그대로'(대조)는 '계산 기준' 안에서 고른다
mode = st.session_state.get("dpp_mode") or E.LATEST
plan = service.dp_plan(mode)
cal = plan.attrs["calendar"]
months = cal["months"]
keys = cal["month_keys"][:months]
labels = [E.month_label(k) for k in keys]
rr_month = meta.get("rr_base_month")
week = cal["week"]
ratio = cal["workday_ratio"]
status = service.input_status()

thu, fri = (date.fromisoformat(d) for d in cal["dp_days"])
top = st.columns([4, 1.3], vertical_alignment="bottom")
top[0].title(f"금주 DP · W{cal['dp_week']}")
with top[1].popover("계산 기준", icon=":material/info:", width="stretch"):
    st.segmented_control(
        "데이터 기준", [E.LATEST, E.DP_FILE], format_func=E.MODE_LABEL.get, default=E.LATEST, key="dpp_mode",
        help="최신 파일 = 공유 폴더의 최신 재고·주문·ADI, 주차·잔여 근무일은 오늘 기준. "
             "DP 파일 = DP 파일 내 해당 주차 데이터 기준 → 수정값이 없으면 DP Table과 "
             "동일 (대조용, 수정·확정 불가)")
    src = meta.get("sources", {})
    parts = []
    if src.get("inventory"):
        parts.append(f"재고 {src['inventory']['key_date']} ({src['inventory']['source']}, "
                     f"{' + '.join(src['inventory']['locations'])})")
    fm = service.flow_meta()
    for k, label in (("orders", "주문"), ("returns", "반품"), ("adi", "ADI")):
        if fm.get(k):
            skipped = " — GI 미사용" if fm[k].get("skipped") or fm[k].get("gi_skipped") else ""
            parts.append(f"{label} {fm[k]['file_date']} ({fm[k]['source']}){skipped}")
    st.markdown("**최신 파일**  \n" + "  \n".join(parts))
    im = service.inbound_meta()
    st.markdown(f"**입고** Sync Plan {im.get('plan_version')} − GR {im.get('gr_total', 0):,.0f}대 ('Inbound' 화면)  \n"
                f"**DP 파일** {meta['dp_file']} (W{meta['dp_week']}): R/R·EOH (RR 기준월 {rr_month}), 공휴일·ADI 보정 설정.  \n"
                "**수정 가능 항목**: R/R·EOH (RR 기준월 내), 월 DP 값 (금주만).")
    others = [f"{f['person']} {(f['last_at'] or '')[5:16].replace('T', ' ')}" + (" ⚠ 잠김" if f["locked"] else "")
              for f in status["files"]]
    st.markdown(f"**수정값·확정 저장 위치**  \n`{status['folder']}` ({status['where']})  \n"
                + (f"동기화된 입력: {', '.join(others)}" if others else "저장된 입력 없음"))
st.caption(f"DP {thu:%m/%d}(목)·{fri:%m/%d}(금) · 기간 M1~M{months} ({', '.join(labels)}) · RR 기준월 {rr_month} · "
           f"M1 잔여 근무일 비율 {ratio:.2f}" + (f" ({E.workday_text(meta)})" if mode == E.LATEST else " (DP 파일 값)")
           + f" · 저장자 **{status['writer']}**")

if mode == E.DP_FILE:
    st.info(f"대조 보기: DP 파일 W{meta['dp_week']}의 데이터·기간 기준 계산값 (DP Table과 동일해야 함). "
            "수정·확정은 '계산 기준'을 '최신 파일'로 변경 후 진행.", icon=":material/compare:")
else:
    if not meta.get("sync_inbound"):
        st.warning("Sync Plan 미반영으로 입고는 DP 파일 '3. Inbound' 기준으로 계산했습니다. 'Inbound' 화면을 확인하십시오.",
                   icon=":material/local_shipping:")
    if plan.attrs.get("inbound_missing"):
        st.warning(f"DP 파일 '3. Inbound'에 {', '.join(plan.attrs['inbound_missing'])} 입고가 없어 0으로 계산했습니다.",
                   icon=":material/local_shipping:")
    for w in service.flow_meta().get("warnings") or []:
        st.warning(w, icon=":material/lock:")

# ---- 거르기 -----------------------------------------------------------------
m = service.metrics()
info = m[["item", "owner", "product_group", "dp_status"]] if m is not None else pd.DataFrame(columns=["item"])
view = plan.merge(info, on="item", how="left")
view["edit_note"] = M.edit_notes(view)
review = view["rr_review"].fillna("")

options = ["전체"] + service.owners()
if "dpp_owner" not in st.session_state:
    st.session_state.dpp_owner = service.current_owner() or "전체"
c = st.columns([2, 3], vertical_alignment="bottom")
owner = c[0].selectbox("담당", options, key="dpp_owner")
text = c[1].text_input("Item·모델 검색", key="dpp_text", placeholder="예: PNM, XNV-6")
keep = pd.Series(True, index=view.index)
if owner != "전체":
    keep &= view["owner"] == owner
if text.strip():
    q = text.strip().upper().replace("-", "").replace("/", "")
    keep &= view["item"].str.upper().str.replace("-", "").str.replace("/", "").str.contains(q, regex=False)
view, review = view[keep], review[keep]

SHOW = {
    "전체": None,
    "RR Review": review != "",
    "수동입력": review.str.contains("수동입력"),
    "수정 Item": view["edited"],
    "자원점검 > 0": view["resource_check"] > 0,
    "원본 값 변경": view["rr_stale"] | view["eoh_stale"],
    "DP 파일과 다름": view["vs_dp_file"].abs() >= 1,
}
show = st.segmented_control(
    "보기", list(SHOW), default="전체", key="dpp_show",
    format_func=lambda s: s if SHOW[s] is None else f"{s} {int(SHOW[s].sum())}",
    help="RR Review = DP Table AC열 표시 Item (수동입력·검토·초기 RR·신규 PM). "
         "수동입력 = 그중 DP 값 수동 결정 대상 (TAA, 대형 프로젝트, 🔴)") or "전체"
if SHOW[show] is not None:
    view = view[SHOW[show]]
view = view.sort_values("item").reset_index(drop=True)

total, calc_total = view["resource_check"].sum(), view["calc_resource_check"].sum()
human = total - calc_total

# ---- 원래 값이 바뀐 R/R·EOH 수정 ------------------------------------------------
stale = view[view["rr_stale"] | view["eoh_stale"]]
if len(stale):
    with st.expander(f"⚠ R/R·EOH 수정 후 DP 파일 값이 변경된 Item {len(stale)}개 — 수정값 유지 여부 결정 필요",
                     expanded=True):
        rows = []
        for r in stale.itertuples(index=False):
            for f, label in (("rr", "R/R"), ("eoh", "EOH")):
                if getattr(r, f"{f}_stale"):
                    rows.append({"item": r.item, "field": f, "항목": label, "수정 시점 원본 값": getattr(r, f"{f}_original"),
                                 "현재 DP 파일 값": getattr(r, f"{f}_file"), "수정값": getattr(r, f),
                                 "작성자": getattr(r, f"{f}_by"), "메모": getattr(r, f"{f}_memo")})
        st.dataframe(pd.DataFrame(rows).drop(columns=["field"]).rename(columns={"item": "아이템"}),
                     hide_index=True, width="stretch")
        b = st.columns(2)
        if b[0].button("수정값 유지 (현재 DP 파일 값을 원본 값으로)", key="dpp_keep"):
            service.save_edits([{"item": r["item"], "field": r["field"], "period": rr_month, "value": r["수정값"],
                                 "original": r["현재 DP 파일 값"]} for r in rows], "원본 값 변경 확인 — 유지")
            st.rerun()
        if b[1].button("DP 파일 값으로 복원", key="dpp_revert"):
            service.save_edits([{"item": r["item"], "field": r["field"], "period": rr_month, "value": None,
                                 "original": r["현재 DP 파일 값"]} for r in rows], "원본 값 변경 확인 — 되돌림")
            st.rerun()


# ---- 금요일 DP 확정 (담당 하나를 골랐을 때) -----------------------------------------
@st.dialog(f"W{cal['dp_week']} DP 확정", width="large")
def confirm_dialog(who: str) -> None:
    rows = service.dp_scope(service.dp_plan(), who)
    st.markdown(f"**{who}** 담당 Item 전체의 M1~M{months} 수량을 **{week}** 확정으로 기록합니다. "
                "재확정 시 변경 수량으로 갱신됩니다. 주말 자원점검 결과는 '자원점검 업로드'에서 처리합니다.")
    k = st.columns(months + 2)
    k[0].metric("아이템", f"{len(rows):,}")
    for i, lab in enumerate(labels, start=1):
        k[i].metric(f"M{i} {lab}", ui.fmt(rows[f"demand_m{i}"].sum()))
    k[months + 1].metric("수정 Item", f"{int(rows['edited'].sum()):,}")
    zero = int((rows[[f"demand_m{i}" for i in range(1, months + 1)]].sum(axis=1) == 0).sum())
    st.caption(f"M1~M{months}이 모두 0인 Item {zero:,}개도 '수요 없음'으로 함께 확정합니다.")
    stale_n = int((rows["rr_stale"] | rows["eoh_stale"]).sum())
    if stale_n:
        st.warning(f"R/R·EOH 수정 후 DP 파일 값이 변경된 Item {stale_n}개. 확인 후 확정 권장.",
                   icon=":material/sync_problem:")
    changed = rows[rows["edited"]]
    if len(changed):
        table = pd.DataFrame({"아이템": changed["item"], "수정 내용": M.edit_notes(changed)})
        st.dataframe(table, hide_index=True, width="stretch", height=min(38 + 35 * len(table), 300))
    memo = st.text_input("메모 (선택)", placeholder="예: 11월 TJMAXX 물량 반영", key="dpp_confirm_memo")
    if st.button("확정", type="primary", icon=":material/task_alt:", width="stretch"):
        path = service.confirm_week(who, memo)
        st.session_state.dpp_saved = f"{week} 확정 완료 → {path.parent.name}\\{path.name}"
        st.rerun()


# ---- 합계 카드 + 확정 (docs/ui-design.md 3장 ②: 긴 설명 줄 → 숫자 카드, 그 옆에 확정) --------------------
# 숫자 = 지금 목록(거르기 반영). 확정 = 담당 아이템 전부 (week_progress). 둘 다 전과 같은 값이다
with st.container(border=True, key="dpp_summary"):
    left, right = st.columns([3.5, 1.1], vertical_alignment="center", gap="medium")
    k = left.columns(months + 3)
    k[0].metric("아이템", f"{len(view):,}")
    for i, lab in enumerate(labels, start=1):
        k[i].metric(f"M{i} {lab}", ui.fmt(view[f"demand_m{i}"].sum()))
    k[months + 1].metric("자원점검", ui.fmt(total),
                         help="자원점검(예상) = 수정값(R/R·EOH·월 DP 값) 반영 합계. 실제 자원점검은 주말 본사 실행. "
                              "수정 전 = DP 파일 R/R·EOH 기준 계산. DP 파일 = DP Table 값 (파일 작성 시점 데이터)")
    k[months + 2].metric("수정 Item", f"{int(view['edited'].sum()):,}")
    left.caption("현재 목록 기준 · 자원점검(예상)"
                 + (f" 수정 전 {ui.fmt(calc_total)} · 수동 수정 {human:+,.0f}" if abs(human) >= 0.5 else "")
                 + f" · DP 파일 {ui.fmt(view['dpf_resource_check'].sum())}")
    with right:
        if mode == E.LATEST and owner != "전체":
            prog = service.week_progress(owner)[0]
            if prog["confirmed_at"]:
                changed = prog["changed_since"]
                state = (ui.badge(f"확정 완료 {prog['confirmed_at'][5:16].replace('T', ' ')}", "green")
                         + (" " + ui.badge(f"확정 후 변경 Item {len(changed)}개", "orange") if changed else ""))
            else:
                state = ui.badge("미확정", "orange")
            st.markdown(state + f"  \n**W{cal['dp_week']} · {owner}** · Item {prog['items']:,}"
                        + (f" ({prog['confirmed_by']})" if prog["confirmed_at"] else ""))
            if st.button("재확정" if prog["confirmed_at"] else "확정", type="primary", icon=":material/task_alt:",
                         width="stretch", key="dpp_confirm",
                         help="해당 담당 Item의 M1~M3을 금주 확정으로 기록 (공유 폴더 'DP 확정'). 담당별 확정·업로드"):
                confirm_dialog(owner)
            got = service.dp_export(owner) if prog["confirmed_at"] else None
            if got:
                st.download_button("DP 표 다운로드", got[0], file_name=got[1], icon=":material/download:", width="stretch",
                                   mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                   help="확정 M1~M3 (임시 양식 · DP UI 업로드 양식 확정 시 변경 예정)")
            else:
                st.button("DP 표 다운로드", disabled=True, width="stretch", icon=":material/download:",
                          help="확정 후 다운로드 가능", key="dpp_dl_off")
        elif mode == E.LATEST:
            st.caption("담당 선택 시 금주 확정 메뉴 표시 (담당별 확정·업로드).")
        else:
            st.caption("대조 보기에서는 확정할 수 없습니다.")

work = st.segmented_control("작업", ["Item 목록", "수정 이력", "일괄 수정"], default="Item 목록",
                            key="dpp_work", label_visibility="collapsed") or "Item 목록"
filters = (mode, owner, text, show)


def _pick_from(event, table_key: str, items: list[str]) -> None:
    """표에서 아이템 칸을 새로 눌렀으면 그 아이템을 패널에. 누른 것이 그대로면(◀ ▶로 넘긴 뒤) 건드리지 않는다.
    다른 칸은 눌러도 패널이 바뀌지 않는다 (사용자 2026-11-11)."""
    row = ui.clicked_row(event, "아이템")
    if row != st.session_state.get(f"{table_key}_last"):
        st.session_state[f"{table_key}_last"] = row
        if row is not None and row < len(items):
            st.session_state.dpp_item = items[row]


# ---- 아이템 목록 + 패널 ---------------------------------------------------------
if work in ("Item 목록", "수정 이력"):
    left, right = st.columns([1.05, 1], gap="medium")
    with left:
        if work == "Item 목록":
            nav = view["item"].tolist()
            sig = []
            for r, rv in zip(view.itertuples(index=False), view["rr_review"].fillna("")):
                s = [rv] if rv else []
                if r.edited:
                    s.append("수정")
                if r.rr_stale or r.eoh_stale:
                    s.append("원본 값 변경")
                sig.append(s)
            shown = pd.DataFrame({"아이템": view["item"], "R/R": view["rr"].round(0)})
            if owner == "전체":
                shown.insert(1, "담당", view["owner"].fillna(""))
            edited_cols = {"R/R": view["rr_edit"]}
            for i, lab in enumerate(labels, start=1):
                shown[f"M{i} {lab}"] = view[f"demand_m{i}"].round(0)
                edited_cols[f"M{i} {lab}"] = view[f"manual_by_m{i}"].notna()
            shown["자원점검(예상)"] = view["resource_check"].round(0)
            edited_cols["자원점검(예상)"] = view["rc_adjust_by"].notna() | (
                (view["resource_check"] - view["calc_resource_check"]).abs() >= 0.5)
            # 지난 주 확정 (week-over-week): 금주 전 가장 최근에 확정한 주차
            before = [w["week"] for w in service.confirmed_weeks() if w["week"] < week]
            last_col = f"{before[0].split('-')[-1]} 확정" if before else "직전 확정"
            last = service.week_snapshot(before[0]) if before else pd.DataFrame()
            if len(last):   # 지난 주 확정이 없으면 열을 숨긴다 (빈 칸이 'None'으로 보여서)
                shown[last_col] = view["item"].map(last.set_index("item")["resource_check"]).round(0)
            shown["표시"] = sig

            def _style(df):
                css = pd.DataFrame("", index=df.index, columns=df.columns)
                for col, mask in edited_cols.items():
                    css.loc[mask.to_numpy(), col] = "background-color: #FDE6D4; color: #9C3F06; font-weight: 600"
                return css

            styled = shown.style.apply(_style, axis=None).format(
                {c: "{:,.0f}" for c in shown.columns if c not in ("표시", "아이템", "담당")},
                na_rep="")
            table_key = f"dpp_list_{abs(hash(filters))}"
            event = st.dataframe(
                styled, key=table_key, hide_index=True, width="stretch", height=640, on_select="rerun",
                selection_mode=ui.CLICK_MODES,
                column_config={"표시": st.column_config.ListColumn("표시", width="medium",
                                                                  help="RR Review (DP Table AC), 수정, 원본 값 변경"),
                               last_col: st.column_config.NumberColumn(
                                   help="직전 주차 확정 자원점검 ('DP 이력'). 금주 수량과 비교")})
            _pick_from(event, table_key, nav)
            st.caption("아이템 칸 선택 시 우측에 Item 상세 표시. 색 표시 칸 = 수정값.")
        else:
            log = service.change_log()
            log = log[log["item"].isin(set(view["item"]))]
            c = st.columns([1, 1], vertical_alignment="bottom")
            this_week = c[0].toggle(f"금주(W{cal['dp_week']}) 적용분만", value=True, key="dpp_log_week",
                                    help="R/R·EOH는 RR 기준월 내, 월 DP 값은 수정한 DP 주차에만 적용")
            people = ["전체"] + sorted(log["by"].dropna().unique().tolist())
            who = c[1].selectbox("작성자", people, key="dpp_log_who")
            if this_week:
                log = log[log["this_week"]]
            if who != "전체":
                log = log[log["by"] == who]
            log = log.reset_index(drop=True)
            nav = list(dict.fromkeys(log["item"]))
            if log.empty:
                st.info("수정 이력이 없습니다 (현재 필터 기준).")
            else:
                table_key = f"dpp_log_{abs(hash(filters + (this_week, who)))}"
                event = st.dataframe(dp_panel.history_table(log, with_item=True), key=table_key, hide_index=True,
                                     width="stretch", height=min(38 + 35 * len(log), 600), on_select="rerun",
                                     selection_mode=ui.CLICK_MODES)
                _pick_from(event, table_key, log["item"].tolist())
                st.caption(f"{len(log)}건 · 최신순 · 전체 담당. 아이템 칸 선택 시 우측에 Item 상세 표시. "
                           "'후' = 복원이면 계산값(R/R·EOH는 DP 파일 값)으로 복원.")
    if st.session_state.get("dpp_item") not in nav:
        st.session_state.dpp_item = nav[0] if nav else None
    with right:
        with st.container(height=760, border=True):
            dp_panel.panel(mode, nav, "dpp_item", "dpp")

# ---- 표에서 여러 개 고치기 ---------------------------------------------------------
elif mode == E.DP_FILE:
    st.info("대조 보기에서는 수정할 수 없습니다. '계산 기준'을 '최신 파일'로 변경하십시오.", icon=":material/compare:")
else:
    COLS = {"item": "아이템", "owner": "담당", "rr_review": "RR Review", "gi": "GI", "hva_inv": "HVA 재고",
            "open_so": "SO", "open_do": "DO", "adi_inv": "ADI", "rr": "R/R", "adi_adjust": "ADI 보정", "eoh": "EOH"}
    for i, lab in enumerate(labels, start=1):
        COLS[f"inbound_m{i}"] = f"입고 {lab}"
    for i, lab in enumerate(labels, start=1):
        COLS[f"demand_m{i}"] = f"M{i} {lab} DP"
    COLS.update({"resource_check": "자원점검(예상)", "calc_resource_check": "수정 전", "edit_note": "수정 내용"})
    EDITABLE = {"rr": ("rr", rr_month), "eoh": ("eoh", rr_month)}
    EDITABLE |= {f"demand_m{i}": ("manual", k) for i, k in enumerate(keys, start=1)}
    TEXT = {"owner", "rr_review", "edit_note"}

    shown = view.set_index("item", drop=False)[list(COLS)].rename(columns=COLS)
    for key in TEXT:
        shown[COLS[key]] = shown[COLS[key]].fillna("")
    config = {}
    for key, label in COLS.items():
        if key in TEXT or key == "item":
            config[label] = st.column_config.TextColumn(label, disabled=True,
                                                        width="medium" if key in ("rr_review", "edit_note") else None)
        elif key in ("rr", "adi_adjust"):
            config[label] = st.column_config.NumberColumn(label, format="localized", min_value=0,
                                                          disabled=key not in EDITABLE)
        else:
            config[label] = st.column_config.NumberColumn(label, format="localized", min_value=0,
                                                          disabled=key not in EDITABLE)

    nonce = st.session_state.get("dpp_nonce", 0)
    editor_key = f"dpp_editor_{nonce}_{abs(hash(filters))}"
    edited = st.data_editor(shown, key=editor_key, hide_index=True, width="stretch", height=520,
                            column_config=config, num_rows="fixed")
    st.caption("연필 표시 열(R/R, EOH, 월 DP 값)은 더블클릭하여 수정. "
               "계산값(R/R·EOH는 DP 파일 값) 재입력 또는 빈칸 시 복원. "
               "필터 변경 시 미저장 수정 내용은 삭제됩니다.")

    changes = []
    by_label = {COLS[k]: k for k in EDITABLE}
    rows_by_item = view.set_index("item")
    for item, label, old, new in ui.edited_cells(shown, edited, list(by_label)):
        key = by_label[label]
        field, period = EDITABLE[key]
        row = rows_by_item.loc[item]
        new = None if pd.isna(new) else float(new)
        if field in ("rr", "eoh"):
            original = float(row[f"{field}_file"])
        else:
            calc = row[f"calc_{key}"]
            original = None if pd.isna(calc) else float(calc)
        if new is not None and original is not None and abs(new - original) < 1e-6:
            new = None  # 원래 값을 다시 넣었으면 되돌림
        changes.append({"item": item, "field": field, "period": period, "value": new, "original": original,
                        "label": label, "before": ui.fmt(old), "after": "복원" if new is None else ui.fmt(new)})
    if changes:
        st.subheader(f"저장 전 확인 — 수정 칸 {len(changes)}개")
        after_plan = service.dp_plan(mode, service.edit_records(changes)).set_index("item")
        now = plan.set_index("item")
        rows = []
        for ch in changes:
            b, a = now.loc[ch["item"]], after_plan.loc[ch["item"]]
            rows.append({"아이템": ch["item"], "칸": ch["label"], "전": ch["before"], "후": ch["after"],
                         "자원점검 전": b["resource_check"], "자원점검 후": a["resource_check"],
                         "변화": a["resource_check"] - b["resource_check"]})
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", column_config={
            c: st.column_config.NumberColumn(c, format="localized") for c in ("자원점검 전", "자원점검 후", "변화")})
        items = sorted({ch["item"] for ch in changes})
        st.caption(f"자원점검 합계 {ui.fmt(now.loc[items, 'resource_check'].sum())} → "
                   f"{ui.fmt(after_plan.loc[items, 'resource_check'].sum())} (수정 Item {len(items)}개)")
        reason = st.pills("사유", service.edit_reasons(), key=f"dpp_reason_{nonce}")
        c = st.columns([4, 1, 1], vertical_alignment="bottom")
        memo = c[0].text_input("메모 (선택)", key=f"dpp_memo_{nonce}", placeholder="예: TJMAXX 프로젝트 11월 납품")
        if c[1].button("저장", type="primary", icon=":material/save:", width="stretch"):
            path = service.save_edits([{k: v for k, v in ch.items() if k not in ("label", "before", "after")}
                                       for ch in changes], memo, reason or "")
            st.session_state.dpp_nonce = nonce + 1
            st.session_state.dpp_saved = f"{len(changes)}칸 저장 완료 → {path}"
            st.rerun()
        if c[2].button("취소", width="stretch"):
            st.session_state.dpp_nonce = nonce + 1
            st.rerun()

saved = st.session_state.pop("dpp_saved", None)
if saved:
    st.toast(saved, icon=":material/check_circle:")
