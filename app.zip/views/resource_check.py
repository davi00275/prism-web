"""자원점검 업로드: 월요일에 쓴다 (사용자 2026-11-06).

금요일에 M1~M3 DP를 올리면 주말에 본사가 자원점검을 돌린다. 월요일에 그 내역을 보고 자원점검 수량을
DP Upload 양식으로 올리는데, 이때 AIR를 나눈다. 고친 값은 그 DP 주차로 저장한다 (월요일 W46에 W45 DP를 처리).
자원점검 수량은 지금은 확정할 때의 계산값이다. 본사 내역 파일을 받으면 그 숫자로 바꾼다 (docs/dp-history.md).
"""

import pandas as pd
import streamlit as st

import ui
from hub import dp_engine as E, service

st.title("자원점검 업로드")
st.caption("금요일 DP 확정 → 주말 본사 자원점검 → **월요일 AIR 분리 및 업로드 파일 생성.**")

options = service.owners()
if "rc_owner" not in st.session_state:
    me = service.current_owner()
    st.session_state.rc_owner = me if me in options else options[0]
c = st.columns([2, 2, 3], vertical_alignment="bottom")
owner = c[0].selectbox("담당", options, key="rc_owner")
weeks = [w["week"] for w in service.confirmed_weeks() if owner in w["owners"]]
if not weeks:
    st.info(f"{owner} 담당 확정 DP가 없습니다. 금요일 '금주 DP'에서 확정 후 표시됩니다.",
            icon=":material/event_note:")
    st.page_link("views/dp_plan.py", label="금주 DP 바로가기", icon=":material/calculate:")
    st.stop()
week = c[1].selectbox("DP 주차", weeks, key=f"rc_week_{owner}", help="기본값: 최근 확정 주차")
only = c[2].toggle("자원점검 대상 Item만", value=True, key="rc_only")

t = service.resource_table(owner, week)
first = t.iloc[0]
months = [first[f"month_m{i}"] for i in range(1, E.MAX_MONTHS + 1) if isinstance(first.get(f"month_m{i}"), str)]
view = t[t["upload"]] if only else t
up = t[t["upload"]]
# 합계 카드 + [업로드 파일 받기] (docs/ui-design.md 3장 ②). 받기 버튼은 아래 표에서 저장 안 한 칸이 있으면 잠기므로
# 자리(dl_slot)만 여기 잡아 두고 표를 읽은 뒤에 채운다
with st.container(border=True, key="rc_summary"):
    left, right = st.columns([3, 1.2], vertical_alignment="center", gap="medium")
    k = left.columns(4)
    k[0].metric("업로드 아이템", f"{len(up):,}")
    k[1].metric("자원점검", ui.fmt(up["resource_check"].sum()))
    k[2].metric("AIR", ui.fmt(up["air"].sum()))
    k[3].metric("VSL / TRK", ui.fmt(up["vsl"].sum()))
    right.markdown(f"**{week.split('-')[-1]} · {owner}**")
    dl_slot = right.empty()

moved = service.inbound_since_confirm(owner, week)
if len(moved):
    with st.expander(f"확정 후 입고 변경 Item {len(moved):,}개 · 차이 {moved['diff'].sum():+,.0f}대", icon=":material/warning:"):
        st.caption("하단 '자원점검 (계산)'은 확정 시점 입고 기준. 입고 증가 시 자원점검 감소분을 '자원점검 ±'로 조정 필요. "
                   "확정 후 GR 차감분은 재고로 이동한 수량이므로 제외.")
        st.dataframe(moved.rename(columns={"item": "아이템", "before": "확정 시 입고", "now": "현재 입고", "diff": "차이",
                                           "gr": "GR 차감분"}).style.format("{:,.0f}", subset=["확정 시 입고", "현재 입고", "차이", "GR 차감분"]),
                     hide_index=True, width="stretch", height=min(38 + 35 * len(moved), 300))

COLS = {"item": "아이템", "rc_formula": "자원점검 (계산)", "rc_adjust": "자원점검 ±", "resource_check": "자원점검",
        "air_input": "AIR", "vsl": "VSL / TRK", "remarks": "Remarks"}
shown = view.set_index("item", drop=False)[list(COLS)].rename(columns=COLS)
for i, m in enumerate(months, start=1):
    shown.insert(i, f"M{i} {E.month_label(m)}", view.set_index("item")[f"demand_m{i}"].round(0))
config = {c_: st.column_config.NumberColumn(c_, format="localized", disabled=True) for c_ in shown.columns
          if c_ not in ("아이템", "자원점검 ±", "AIR", "Remarks")}
config["아이템"] = st.column_config.TextColumn("아이템", disabled=True)
config["자원점검 ±"] = st.column_config.NumberColumn("자원점검 ±", format="%+d", help="계산 자원점검에 가감. 0 = 조정 없음")
config["AIR"] = st.column_config.NumberColumn("AIR", format="localized", min_value=0,
                                              help="자원점검 중 AIR 배정 수량. 잔량은 VSL / TRK")
config["Remarks"] = st.column_config.TextColumn("Remarks", width="medium", help="예: BACKORDER FULFILLMENT, WELLS FARGO PJT")

nonce = st.session_state.get("rc_nonce", 0)
edited = st.data_editor(shown, key=f"rc_editor_{nonce}_{owner}_{week}_{only}", hide_index=True, width="stretch",
                        height=min(38 + 35 * max(len(shown), 1), 520), column_config=config, num_rows="fixed")
st.caption("연필 표시 열(자원점검 ±, AIR, Remarks)은 더블클릭하여 수정. [저장] 후 업로드 파일에 반영.")

changes = []
for item, label, old, new in ui.edited_cells(shown, edited, ["자원점검 ±", "AIR"]):
    field = "rc_adjust" if label == "자원점검 ±" else "air"
    new = None if pd.isna(new) or not new else float(new)
    changes.append({"item": item, "field": field, "period": "", "value": new,
                    "original": float(view.set_index("item").loc[item, "rc_formula"])})
for item in shown.index:
    before, after = str(shown.at[item, "Remarks"] or ""), str(edited.at[item, "Remarks"] or "").strip()
    if before != after:
        changes.append({"item": item, "field": "remarks", "period": "", "value": after})

if changes:
    c = st.columns([1.4, 3, 1, 1], vertical_alignment="bottom")
    c[0].markdown(f"**수정 칸 {len(changes)}개**")
    memo = c[1].text_input("메모 (선택)", key=f"rc_memo_{nonce}", placeholder="예: Backorder 긴급분 AIR")
    if c[2].button("저장", type="primary", icon=":material/save:", width="stretch", key="rc_save"):
        service.save_edits(changes, memo, week=week)
        st.session_state.rc_nonce = nonce + 1
        st.session_state.rc_saved = f"저장 완료: {len(changes)}칸"
        st.rerun()
    if c[3].button("취소", width="stretch", key="rc_cancel"):
        st.session_state.rc_nonce = nonce + 1
        st.rerun()

got = service.upload_file(owner, week)
if got:
    dl_slot.download_button("업로드 파일 다운로드", got[0], file_name=got[1], icon=":material/download:", type="primary",
                            disabled=bool(changes), width="stretch",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            help="DP Upload 양식. 자원점검 > 0 또는 Remarks 입력 Item" + (" · 저장 후 다운로드 가능" if changes else ""))
st.caption("현재 자원점검 수량 = 금요일 확정 시 계산값. 본사 자원점검 내역 파일 연동 시 해당 수량으로 대체 예정.")

saved = st.session_state.pop("rc_saved", None)
if saved:
    st.toast(saved, icon=":material/check_circle:")
