"""화면 공통: 시작 비밀번호, 표시 형식, 열 이름, 아이템 표(누르면 Item 360으로)."""

import hashlib
import hmac
import os

import pandas as pd
import streamlit as st

from hub import config, metrics as M, web


def login_gate() -> None:
    """앱 시작 비밀번호 (사용자 2026-11-18). 맞히면 그 브라우저 탭에서는 다시 묻지 않는다 (새로 고침하면 다시 묻는다).
    비밀번호는 settings.yaml login.password_sha256 (해시만). 팀 내부용 잠금이고 보안 장치는 아니다.
    설정이 없으면 묻지 않는다. 화면 테스트는 hub/testing.app()이 통과한 상태로 연다.
    웹 버전은 Windows 사용자 이름이 없어서 이름도 고른다 → 담당자 자동 선택·저장하는 사람 이름 (USERNAME)."""
    if st.session_state.get("hub_authed"):
        return
    want = (config.settings().get("login") or {}).get("password_sha256")
    ask_name = web.is_web()
    if not want and not ask_name:
        return
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        st.title("HVA SCM Hub")
        st.caption("SCM · Demand Planning 팀 내부용")
        with st.form("login"):
            names = sorted(set((config.settings().get("owners") or {}).values()))
            name = st.selectbox("이름", names, index=None, placeholder="선택", key="login_name") if ask_name else None
            pw = st.text_input("비밀번호", type="password", key="login_pw") if want else ""
            sent = st.form_submit_button("로그인", type="primary", width="stretch")
        if sent:
            if ask_name and not name:
                st.error("이름을 선택하십시오.")
            elif want and not hmac.compare_digest(hashlib.sha256(pw.encode()).hexdigest(), str(want)):
                st.error("비밀번호가 일치하지 않습니다.")
            else:
                if name:   # 웹 버전: 이 탭의 파이썬은 이 사람 하나만 쓴다
                    os.environ["USERNAME"] = name
                st.session_state.hub_authed = True
                st.rerun()
    st.stop()


# Item Master 열 → 화면 이름
LABELS = {
    "item": "아이템", "item_name": "품명", "product_group": "Product Group", "product": "Product",
    "owner": "담당", "series": "Series", "dp_series": "Series", "model_group": "Model Group",
    "model_name": "Model Name", "plc_status": "PLC", "bom_status": "BOM Status", "scm_type": "SCM Type",
    "from_site": "From Site", "product_type": "Product Type", "sra": "SRA", "eol": "EOL", "eop": "EOP",
    "eop_start": "EOP Start", "eop_qty": "EOP Qty", "type": "형태", "sub_type": "세부 형태",
    "pl_series": "시리즈 (Attb03)", "resolution": "해상도", "feature": "특징", "ai_target": "AI 대상",
    "moq_lt": "MOQ / LT", "group_constraints": "GROUP 제약", "site_constraints": "Site 제약",
    "base": "모델 (/ 앞)", "suffix": "Suffix", "site": "생산지", "dest": "향지",
    "family_key": "버전 묶음 키", "version": "버전", "in_product_list": "Product List",
    "in_dp_list": "DP 대상", "is_local": "Local", "is_bom_header": "BOM 세트", "is_bom_component": "BOM 구성품",
    "dp_to_site": "To Site", "dp_asp": "ASP ($)", "dp_sales_prev_year": "월평균 판매 (전년)",
    "dp_sales_recent6": "월평균 판매 (최근 6M)", "dp_sales_recent3": "월평균 판매 (최근 3M)",
    "dp_rr_current": "현행 R/R", "dp_rr_proposed": "제안 RR v2", "dp_rr_rule": "RR 적용 규칙",
    "dp_rr_flag": "RR 검토 플래그", "dp_eoh_target": "EOH Target", "dp_pl_status": "PriceList 상태",
    "dp_pl_notes": "PriceList 메모", "dp_rr_risk_flag": "RR 위험", "dp_rr_risk_reason": "RR 위험 근거",
    "dp_prev_model": "대체 구모델", "match": "매칭 근거", "months_to_eop": "EOP까지 (개월)",
    "dp_review": "RR Review", "dp_review_reason": "Review 사유", "is_manual_input": "수동입력",
    "dp_exclude_reason": "DP 제외 사유", "pl_limited": "PriceList Limited", "pl_eol": "PriceList EOL",
    "is_kv_switch": "K↔V 전환",
}

PLC_COLOR = {"ACTIVE": "green", "PLANNED": "blue", "INACTIVE": "orange", "DELETED": "gray"}

# ---- 겉모습: 흰 바탕 Apple 스타일 + 한화 주황 (docs/ui-design.md 4장) ----------------
# 색·글꼴·모서리는 .streamlit/config.toml 테마에 있고, 테마로 안 되는 것만 여기서 바꾼다.
# 화면 배치·위젯 동작은 건드리지 않는다. Streamlit이 붙이는 data-testid로만 고른다.
STYLE = """<style>
h1, h2, h3, h4 {letter-spacing: -0.02em;}
[data-testid="stCaptionContainer"] {color: #6E6E73;}

/* 사이드바 메뉴 5개 (app.py MENU, st.page_link). 지금 화면이 속한 메뉴(key side_nav_on) = 연한 주황 + 주황 글자·아이콘 */
.st-key-side_menu [data-testid="stPageLink-NavLink"] {min-height: 2.5rem; border-radius: 10px; padding-left: 0.75rem; background: transparent;}
.st-key-side_menu [data-testid="stPageLink-NavLink"] p {font-size: 0.95rem; font-weight: 500;}
.st-key-side_nav_on [data-testid="stPageLink-NavLink"] {background: rgba(243, 115, 33, 0.12) !important;}
.st-key-side_nav_on [data-testid="stPageLink-NavLink"] span,
.st-key-side_nav_on [data-testid="stPageLink-NavLink"] p {color: #B84A08 !important; font-weight: 600;}
.st-key-side_nav_on [data-testid="stIconMaterial"] {color: #F37321 !important;}

/* 사이드바 '이번 주' 카드: 회색 사이드바 위 흰 카드 */
.st-key-side_week {background: #FFFFFF;}

/* 홈 '이번 주 흐름': 단계마다 칸, 오늘 단계(key flow_now) = 연한 주황 */
[class*="st-key-flow_"] {padding: 0.7rem 0.85rem; border-radius: 14px; gap: 0.3rem;}
.st-key-flow_now {background: #FFF4EC; box-shadow: inset 0 0 0 1px rgba(243,115,33,0.25);}

/* 주 버튼: 주황 + 진한 갈색 글자 (흰 글자는 주황 위에서 읽기 대비 2.9:1이라) */
[data-testid="stBaseButton-primary"] {
  background: linear-gradient(180deg, #FF8F45, #F37321); border-color: transparent; color: #2A1203; font-weight: 600;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.45), 0 1px 2px rgba(0,0,0,0.08), 0 8px 20px -8px rgba(243,115,33,0.7);}
[data-testid="stBaseButton-primary"]:hover, [data-testid="stBaseButton-primary"]:focus:not(:active) {
  background: linear-gradient(180deg, #FF9A57, #F57B2B); border-color: transparent; color: #2A1203;}
[data-testid="stBaseButton-primary"] p {color: inherit;}
/* 누를 수 없는 주 버튼은 회색 (주황이면 눌리는 것처럼 보인다, 2026-11-10) */
[data-testid="stBaseButton-primary"]:disabled {background: #E8E8ED; color: #A1A1A6; box-shadow: none; border-color: transparent;}

/* 보조 버튼·팝오버: 살짝 볼록한 흰 버튼. 마우스를 올리면 진한 주황 글자 */
[data-testid="stBaseButton-secondary"], [data-testid="stPopoverButton"] {
  background: linear-gradient(180deg, #FFFFFF, #F2F2F5); border-color: rgba(0,0,0,0.08);
  box-shadow: inset 0 1px 0 #FFFFFF, 0 1px 2px rgba(0,0,0,0.05), 0 6px 14px -8px rgba(0,0,0,0.18);}
[data-testid="stBaseButton-secondary"]:hover, [data-testid="stPopoverButton"]:hover {
  border-color: rgba(243,115,33,0.45); color: #B84A08;}
[data-testid="stBaseButton-secondary"]:focus:not(:active), [data-testid="stPopoverButton"]:focus:not(:active) {color: #B84A08;}

/* 세그먼트(segmented_control): 회색 판 위에 고른 칸만 흰색으로 */
[data-baseweb="button-group"]:has(> [data-testid^="stBaseButton-segmented_control"]) {
  background: #E8E8ED; padding: 3px; border-radius: 12px; gap: 2px; width: fit-content; max-width: 100%;}
[data-testid="stBaseButton-segmented_control"], [data-testid="stBaseButton-segmented_controlActive"] {
  border: 0 !important; border-radius: 9px !important; min-height: 2.125rem;}
[data-testid="stBaseButton-segmented_control"] {background: transparent; color: #3A3A3C;}
[data-testid="stBaseButton-segmented_control"]:hover {background: rgba(255,255,255,0.6); color: #1D1D1F;}
[data-testid="stBaseButton-segmented_controlActive"] {
  background: #FFFFFF !important; color: #1D1D1F !important; font-weight: 600;
  box-shadow: 0 1px 2px rgba(0,0,0,0.08), 0 3px 8px -2px rgba(0,0,0,0.12);}

/* 필(pills): 고른 것 = 연한 주황 + 진한 주황 글자 */
[data-testid="stBaseButton-pills"] {background: #FFFFFF; border-color: rgba(0,0,0,0.10);}
[data-testid="stBaseButton-pillsActive"] {
  background: #FDEBDD !important; color: #B84A08 !important; border-color: rgba(243,115,33,0.45) !important; font-weight: 600;}

/* 숫자 카드(st.metric): 글자만. 회색 칸은 넓이가 넉넉한 곳에만 (DP 패널 결론 2열, key dpsum_) */
[data-testid="stMetricLabel"] {color: #6E6E73;}
[class*="st-key-dpsum_"] [data-testid="stMetric"] {background: #F5F5F7; border-radius: 14px; padding: 0.6rem 0.85rem;}
[class*="st-key-dpsum_"] [data-testid="stColumn"] > div {gap: 0.6rem;}
[data-testid="stMetricValue"] {letter-spacing: -0.02em;}

/* RR 리뷰 (views/run_rate.py, rr_panel.py): 머리 숫자 색, 검토 진행 막대, 패널(머리글·숫자 칸·차트·플래그 근거·RR 결정) */
.st-key-rr_k_auto [data-testid="stMetricValue"] {color: #248A3D;}
.st-key-rr_k_need [data-testid="stMetricValue"] {color: #D70015;}
.rr-prog {font-size: 0.85rem; color: #6E6E73; line-height: 1.5;}
.rr-prog b {color: #1D1D1F; font-size: 1.05rem;}
.rr-bar {display: flex; height: 8px; border-radius: 4px; background: #E8E8ED; overflow: hidden; margin: 0.25rem 0;}
.rr-bar span.ok {background: #34C759;} .rr-bar span.adj {background: #F37321;} .rr-bar span.hold {background: #A1A1A6;}
.rr-dot {display: inline-block; width: 8px; height: 8px; border-radius: 2px; margin-right: 3px;}
.rr-dot.ok {background: #34C759;} .rr-dot.adj {background: #F37321;} .rr-dot.hold {background: #A1A1A6;}
[class*="st-key-rr_box_"] {gap: 0.6rem;}
.rr-title {font-size: 1.2rem; font-weight: 700; letter-spacing: -0.01em; line-height: 1.3; overflow-wrap: anywhere;}
.rr-count {text-align: center; font-size: 0.85rem; color: #6E6E73; white-space: nowrap;}
/* Streamlit은 글 상자 밑 여백을 -1rem으로 당긴다: 여백을 0으로 둔 곳은 그 당김도 없앤다 (안 그러면 다음 칸과 겹침) */
.st-key-rr_head [data-testid="stMarkdownContainer"], .st-key-rr_chart [data-testid="stMarkdownContainer"],
.st-key-rr_fbox [data-testid="stMarkdownContainer"], .st-key-rr_fbox_none [data-testid="stMarkdownContainer"] {margin-bottom: 0;}
.st-key-rr_head p {font-size: 0.86rem; line-height: 1.6; margin: 0;}
.rr-sub {color: #6E6E73;}
.rr-h {font-size: 0.9rem; font-weight: 600; color: #1D1D1F; margin-bottom: 0.15rem;}
[class*="st-key-rrsum"] [data-testid="stMetric"] {background: #F5F5F7; border-radius: 14px; padding: 0.4rem 0.7rem;
  min-height: 6.1rem;}
[class*="st-key-rrsum"] [data-testid="stMetricValue"] {font-size: 1.4rem;}
.st-key-rrsum_new [data-testid="stMetric"] {background: #FFF4EC; box-shadow: inset 0 0 0 1px rgba(243,115,33,0.35);}
.st-key-rrsum_new [data-testid="stMetricValue"] {color: #B84A08;}
.st-key-rr_chart {gap: 0;}
.st-key-rr_formula {background: #F5F5F7; border-radius: 10px; padding: 0.4rem 0.7rem;}
.st-key-rr_fbox, .st-key-rr_fbox_none {background: #FFF7F0; border-radius: 12px; padding: 0.5rem 0.75rem;
  box-shadow: inset 0 0 0 1px rgba(243,115,33,0.22);}
.st-key-rr_fbox_none {background: #F5F5F7; box-shadow: none;}
.st-key-rr_fbox p, .st-key-rr_fbox_none p {font-size: 0.84rem; line-height: 1.45; margin: 0 0 0.35rem 0;}
.st-key-rr_fbox p:last-child, .st-key-rr_fbox_none p:last-child {margin-bottom: 0;}
.rr-rule {font-size: 0.76rem; color: #6E6E73;}
.st-key-rr_lastrev {background: #F3EFFB; border-radius: 10px; padding: 0.35rem 0.7rem;}
.st-key-rr_lastrev [data-testid="stMarkdownContainer"] {margin-bottom: 0;}
.st-key-rr_lastrev p {font-size: 0.82rem; line-height: 1.5; margin: 0;}
.rr-prev-h {font-weight: 600; color: #5B3E96; margin-right: 0.3rem;}
.st-key-rr_decide {background: #FFFFFF; border-radius: 14px; padding: 0.7rem 0.85rem;
  box-shadow: inset 0 0 0 1.5px rgba(243,115,33,0.45);}

/* 접기 상자(expander) */
[data-testid="stExpander"] details {border-radius: 14px;}
[data-testid="stExpander"] summary:hover, [data-testid="stExpander"] summary:hover [data-testid="stIconMaterial"] {color: #B84A08;}
</style>"""


def apply_style() -> None:
    """앱 맨 위에서 한 번 부른다 (app.py)."""
    st.html(STYLE)


def blank(v) -> bool:
    return v is None or (not isinstance(v, (list, dict, str)) and pd.isna(v)) or v == ""


def fmt(v, digits: int = 0) -> str:
    """화면용 글자. 빈 값은 '–'."""
    if blank(v):
        return "–"
    if isinstance(v, bool):
        return "예" if v else "아니오"
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, (int, float)):
        return f"{v:,.{digits}f}"
    return str(v)


def badge(text: str, color: str = "gray") -> str:
    return f":{color}-badge[{text}]"


def table(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """보여줄 열만 골라 화면 이름으로 바꾼다."""
    cols = [c for c in columns if c in df.columns]
    return df[cols].rename(columns=LABELS)


def edited_cells(before: pd.DataFrame, after: pd.DataFrame, columns: list[str]) -> list[tuple]:
    """st.data_editor 전후 비교 → [(행 이름, 열, 전, 후)]. 숫자 열만. 둘 다 비어 있으면 같은 것으로 본다."""
    out = []
    for c in columns:
        b = pd.to_numeric(before[c], errors="coerce")
        a = pd.to_numeric(after[c], errors="coerce").reindex(b.index)
        moved = ((b - a).abs() > 1e-9) | (b.isna() != a.isna())
        out += [(i, c, b[i], a[i]) for i in b.index[moved]]
    return out


# ---- 아이템 표: 행을 누르면 Item 360으로 ------------------------------------

ALERT_COLOR = {a.label: a.color for a in M.ALERTS}


def label_of(key: str) -> str:
    m = M.METRIC_BY_KEY.get(key)
    if m:
        return m.label
    return {"alerts": "주의 신호", "relation": "관계"}.get(key, LABELS.get(key, key))


def column_config(keys: list[str], pinned: tuple = ()) -> dict:
    """열 이름·형식. pinned = 아이템 열 말고도 옆으로 넘겨도 고정할 열 (예: Inbound 가용재고·합계)."""
    cfg = {}
    for k in keys:
        label = label_of(k)
        if k == "item":    # 주차 열이 많아 옆으로 넘겨도 아이템이 보이게
            cfg[label] = st.column_config.TextColumn(label, pinned=True)
        m = M.METRIC_BY_KEY.get(k)
        fmt_ = m.fmt if m else ("date" if k in ("sra", "eol", "eop") else None)
        if k == "alerts":
            cfg[label] = st.column_config.ListColumn(label, width="medium")
        elif fmt_ == "int":
            cfg[label] = st.column_config.NumberColumn(label, format="localized", help=m.help or None)
        elif fmt_ == "float1":
            cfg[label] = st.column_config.NumberColumn(label, format="%.1f", help=m.help or None)
        elif fmt_ == "date":
            cfg[label] = st.column_config.DateColumn(label, format="YYYY-MM-DD")
        if k in pinned:
            cfg.setdefault(label, st.column_config.Column(label))["pinned"] = True
    return cfg


def open_item(item: str, nav: list[str] | None = None) -> None:
    """Item 360으로 이동. nav를 주면 Item 360에서 ◀ ▶로 그 목록을 넘겨 본다."""
    st.session_state.open_item = item
    if nav is not None:
        st.session_state.nav_list = nav
    st.switch_page("views/item360.py")


def clicked_row(event, column: str | None = None) -> int | None:
    """표에서 누른 칸의 행 번호. 화면에서 정렬해도 원래 표 기준 번호.
    column을 주면 그 열(아이템 열) 칸을 눌렀을 때만 (사용자 2026-11-11: 다른 칸은 눌러도 넘어가지 않게).
    행 이름(index) 칸은 Streamlit이 선택을 돌려주지 않는다. 그래서 아이템은 index가 아닌 열로 둔다."""
    cells = getattr(event.selection, "cells", None) or []
    if not cells:
        return None
    row, col = cells[0]
    return row if column is None or col == column else None


# 칸 하나를 눌러 고른다 (행 체크칸은 두지 않는다: 아이템 칸을 눌러야 넘어가므로)
CLICK_MODES = ["single-cell"]
ITEM = LABELS["item"]   # 아이템 열 이름 (표에서 이 칸을 누르면 상세로)


def blank_zero(frame: pd.DataFrame, signed: tuple = (), keep_zero: tuple = ()):
    """숫자 표에서 0을 비운다. 수량이 있는 칸만 눈에 들어오게. signed 열은 +·− 부호를 붙인다.
    keep_zero 열은 0도 보인다 (예: 가용재고 0)."""
    plain = [c for c in frame.select_dtypes("number").columns if c not in signed and c not in keep_zero]
    style = frame.style.format(lambda v: f"{v:,.0f}" if v else "", subset=plain)
    keep = [c for c in keep_zero if c in frame.columns]
    if keep:
        style = style.format(lambda v: "" if pd.isna(v) else f"{v:,.0f}", subset=keep)
    return style.format(lambda v: f"{v:+,.0f}" if v else "", subset=list(signed)) if signed else style


def item_table(df: pd.DataFrame, columns: list[str], key: str, height: int = 520, hide_zero: bool = False,
               signed: tuple = (), pinned: tuple = (), keep_zero: tuple = ()) -> None:
    """아이템 표. 아이템 칸을 누르면 그 아이템의 Item 360이 열린다 (표 순서가 ◀ ▶ 순서).
    pinned = 아이템 말고도 고정할 열 key, keep_zero = 0도 보일 열 key."""
    cols = [c for c in columns if c in df.columns]
    shown = df[cols].rename(columns={c: label_of(c) for c in cols})
    nonce = st.session_state.get(f"{key}_nonce", 0)
    data = blank_zero(shown, signed, tuple(label_of(c) for c in keep_zero)) if hide_zero else shown
    event = st.dataframe(data, hide_index=True, width="stretch", height=height, on_select="rerun",
                         selection_mode=CLICK_MODES, key=f"{key}_{nonce}", column_config=column_config(cols, pinned))
    row = clicked_row(event, label_of("item"))
    if row is not None and row < len(df):
        # 표 이름(key)을 바꿔 선택을 비운다. 돌아왔을 때 다시 넘어가지 않게
        st.session_state[f"{key}_nonce"] = nonce + 1
        open_item(df.iloc[row]["item"], df["item"].tolist())
