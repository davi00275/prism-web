"""Item 360 상세: 아이템 하나의 머리글 → 주의 신호·날짜 → 요약 숫자 → 탭 9개.

Item 360 화면(views/item360.py, 위쪽 검색·◀ ▶ 아래)과 '내 아이템' 나눠 보기 오른쪽(views/worklist.py)이 같이 쓴다
(2026-11-09, docs/ui-design.md 3장 ④). 2026-11-09 전까지 views/item360.py에 있던 코드를 그대로 옮겼다.
요약 숫자는 hub/metrics.py에서 summary=True인 지표 (새 데이터를 붙이면 여기 자동으로 늘어난다).
"""

import pandas as pd
import streamlit as st

import dp_panel
import ui
from hub import config, dp_engine, metrics as M, service


def detail(item: str, compact: bool = False) -> None:
    """아이템 하나의 Item 360. compact = 좁은 오른쪽 칸 (요약 숫자를 한 줄에 3개씩, 넓으면 5개씩)."""
    per_row = 3 if compact else 5
    d = service.item_detail(item)
    st.session_state.recent = [d["item"]] + [x for x in st.session_state.get("recent", []) if x != d["item"]][:7]

    # ---- 머리글 ---------------------------------------------------------------
    st.header(d["item"])
    subtitle = [d.get("item_name") if d.get("item_name") != d["item"] else None, d.get("product_group"),
                d.get("product") if d.get("product") != d.get("product_group") else None, d.get("dp_series"),
                d.get("owner") and f"담당: {d['owner']}"]
    st.write(" · ".join(x for x in subtitle if not ui.blank(x)))

    chips = []
    if d.get("plc_status"):
        chips.append(ui.badge(d["plc_status"], ui.PLC_COLOR.get(d["plc_status"], "gray")))
    met = d.get("metrics") or {}
    status, reason = met.get("dp_status"), met.get("dp_reason")
    if status:
        color = "blue" if status == M.DP_TARGET else "gray"
        chips.append(ui.badge(f"{status}" + (f": {reason}" if reason else ""), color))
    if d.get("is_local"):
        chips.append(ui.badge("Local", "violet"))
    if d.get("is_bom_header"):
        chips.append(ui.badge("BOM 세트", "orange"))
    if d.get("is_bom_component"):
        chips.append(ui.badge("BOM 구성품", "orange"))
    if d.get("dp_pl_status"):
        chips.append(ui.badge(f"PriceList {d['dp_pl_status']}", "red"))
    if d.get("dp_review"):
        chips.append(ui.badge(d["dp_review"], "red" if d.get("is_manual_input") else "orange"))
    if d.get("is_kv_switch"):
        chips.append(ui.badge("K↔V 전환 모델", "violet"))
    if not d.get("in_product_list"):
        chips.append(ui.badge("Product List에 없음", "gray"))
    # 주의 신호 (위 표시와 겹치는 수동입력·K↔V·Limited/EOL은 빼고)
    shown_above = {"수동입력", "K↔V 전환", "Limited/EOL"}
    chips += [ui.badge(a, ui.ALERT_COLOR.get(a, "gray")) for a in met.get("alerts", []) if a not in shown_above]
    st.markdown(" ".join(chips))

    eop_left = d.get("months_to_eop")
    dates = [f"SRA {ui.fmt(d.get('sra'))}", f"EOL {ui.fmt(d.get('eol'))}",
             f"EOP {ui.fmt(d.get('eop'))}" + ("" if eop_left is None else f" ({eop_left:+.1f}개월)"),
             f"현행 R/R {ui.fmt(d.get('dp_rr_current'))}",
             f"제안 RR v2 {ui.fmt(d.get('dp_rr_proposed'))}" + (f" ({d['dp_rr_rule']})" if d.get("dp_rr_rule") else ""),
             f"EOH Target {ui.fmt(d.get('dp_eoh_target'))}"]
    st.caption(" · ".join(dates))

    # 요약 줄: hub/metrics.py에서 summary=True인 지표 (새 데이터를 붙이면 여기 자동으로 늘어난다)
    summary = [m for m in M.METRICS if m.summary]
    for start in range(0, len(summary), per_row):
        cols = st.columns(per_row)
        for col, m in zip(cols, summary[start:start + per_row]):
            col.metric(m.label, ui.fmt(met.get(m.key), 1 if m.fmt == "float1" else 0), help=m.help or None)

    flags = [x for x in [d.get("dp_review_reason"), d.get("dp_rr_flag"), d.get("dp_rr_risk_reason"),
                         d.get("dp_pl_notes")] if not ui.blank(x)]
    flags = list(dict.fromkeys(flags))  # 같은 문장이 두 번 나오지 않게
    if flags:
        st.warning(" · ".join(flags), icon=":material/flag:")

    # ---- 탭 -------------------------------------------------------------------
    t_info, t_inv, t_inbound, t_dp, t_hist, t_similar, t_bom, t_sales, t_planned = st.tabs(
        ["기본 정보", "재고 · 주문 · ADI", "Inbound", "DP 계산", "DP 이력", "유사 아이템", "BOM · POS", "판매 평균 · RR", "연결 예정"])

    with t_inbound:
        ib = d.get("inbound")
        if ib is None:
            st.caption("Sync Plan이 없습니다.")
        elif not ib["weeks"]:
            st.caption("입고 예정이 없습니다.")
        else:
            im = service.inbound_meta()
            w = pd.DataFrame(ib["weeks"])
            for c in ("it_air", "it_vessel"):     # 예전 캐시에는 없다
                w[c] = w[c] if c in w.columns else 0
            g = w.set_index("week")
            table = pd.DataFrame({"전체": g["total"], "Air": g["air"] + g["it_air"], "Vessel": g["vessel"] + g["it_vessel"],
                                  "In-transit · Air": g["it_air"], "In-transit · Vessel": g["it_vessel"]}).T
            table.columns = [f"W{c[-2:]}" for c in table.columns]
            table.insert(0, "합계", table.sum(axis=1))
            st.caption(f"Sync Plan {im.get('plan_version')} − GR. Air·Vessel = In-transit 포함 전체, "
                       "In-transit · Air/Vessel = 선적 완료·운송 중.")
            st.dataframe(table.map(ui.fmt), width="stretch")
            if ib["transit"]:
                st.markdown("**In-transit 상세**")
                t = pd.DataFrame(ib["transit"])
                t["week"] = "W" + t["week"].str[-2:]
                t["overdue"] = t["overdue"].map({True: "ETA 경과 → 금주", False: ""})
                st.dataframe(t.rename(columns={"week": "도착 주차", "eta": "ETA", "overdue": "메모", "mode": "운송", "qty": "수량",
                                               "ship_date": "출발일", "status": "상태", "po_no": "PO", "po_item": "PO Item",
                                               "bl_no": "BL", "container": "컨테이너"}), hide_index=True, width="stretch")

    with t_hist:
        hist = (d.get("dp_calc") or {}).get("dp_history") or []
        if not hist:
            st.caption("확정 이력이 없습니다. '금주 DP'에서 확정 시 주차별로 기록됩니다.")
        else:
            h = pd.DataFrame(hist)
            st.caption(f"주차별 확정 최종 DP (최신 주차순, {len(h)}주). 월별 열 기준 주차 간 변동 확인 "
                       "(세로 방향 비교).")
            st.dataframe(dp_panel.history_by_week(h), width="stretch")
            with st.expander("주차별 계산 근거 (최종 DP 산출 내역)"):
                basis = pd.DataFrame({
                    "주차": h["week"].str.split("-").str[-1], "R/R": h["rr"], "EOH": h["eoh"], "HVA 재고": h["hva_inv"],
                    "SO": h["open_so"], "DO": h["open_do"], "GI": h["gi"], "ADI": h["adi_inv"], "ADI 보정": h["adi_adjust"],
                    "계산 자원점검": h["calc_resource_check"].round(0), "자원점검 ±": h["rc_adjust"],
                    "최종 자원점검": h["resource_check"].round(0), "수정 내용": h["edit_note"].fillna(""),
                    "데이터": h["data_dates"].map(lambda x: f"재고 {(x or {}).get('inventory', '–')} · "
                                                        f"주문 {(x or {}).get('orders', '–')}")})
                st.dataframe(basis, hide_index=True, width="stretch")

    with t_inv:
        st.subheader("HVA 재고")
        inv = d.get("inventory")
        if not inv:
            st.caption("재고 데이터가 없습니다. '데이터 현황'에서 HVA 재고 상태를 확인하십시오.")
        else:
            st.caption(f"{', '.join(inv['locations'])} 창고 · {inv['as_of']} 기준 ({inv['source']}: {inv['file']}). "
                       "파일 추출 시점 재고.")
            k = st.columns(4)
            k[0].metric("OH", ui.fmt(inv["unrestricted"]), help="Unrestricted 합계, CFC5 + SCA3 (SCA3 = 열상 카메라 창고). 수주 재고 포함")
            k[1].metric("S/O", ui.fmt(inv["so_qty"]), help="재고 파일의 S/O Qty")
            k[2].metric("D/O", ui.fmt(inv["do_qty"]), help="재고 파일의 D/O Qty")
            k[3].metric("가용재고", ui.fmt(inv["available"]), help="OH − S/O − D/O")
            k = st.columns(4)
            k[0].metric("Open PO", ui.fmt(inv["open_po"]), help="재고 파일의 Open PO Qty")
            k[1].metric("Allocated", ui.fmt(inv["allocated"]))
            k[2].metric("Blocked", ui.fmt(inv["blocked"]))
            k[3].metric("재고 금액 ($)", ui.fmt(inv["amount"]))
            k = st.columns(4)
            k[0].metric("재고 커버 (개월)", ui.fmt(inv.get("months_of_cover"), 1),
                        help="OH ÷ DP Table R/R")
            k[1].metric("EOH Target 대비", ui.fmt(inv.get("vs_eoh_target")),
                        help="OH − EOH Target (DP list). + = Target 초과")
            k[2].metric("단가 ($)", ui.fmt(inv.get("price"), 2))
            if inv["sales_order_stock"]:
                st.caption("수주 재고 (특정 S/O에 묶인 재고, Special Stock E)")
                st.dataframe(pd.DataFrame(inv["sales_order_stock"]).rename(
                    columns={"sales_doc": "Sales Doc.", "unrestricted": "수량"}), hide_index=True)
            dpf_row = (d.get("dp_calc") or {}).get("dp_file") or {}
            if dpf_row.get("hva_inv") is not None:
                src = d["dp_calc"]["source"]
                st.caption(f"참고: DP 파일({src['file']}, W{src['dp_week']})의 DP Table 'HVA Inv.'는 "
                           f"CFC5 + SCA3 합계 {ui.fmt(dpf_row['hva_inv'])} (파일 작성 시점 재고).")

        fl = d.get("flow")
        st.subheader("당월 출고 · 주문")
        if not fl:
            st.caption("주문 데이터가 없습니다.")
        else:
            src_o, src_r = fl["sources"]["orders"], fl["sources"]["returns"]
            st.caption(" · ".join(f"{s['source']}: {s['file']}" for s in (src_o, src_r) if s)
                       + ". 정의는 DP Table과 동일.")
            k = st.columns(4)
            k[0].metric("당월 GI", ui.fmt(fl["gi_qty"]),
                        help="주문 파일 (Invoice + Not Invoice 수량) + 반품 파일 (같은 열). DP Table F열")
            k[1].metric("GI 금액 ($)", ui.fmt(fl["gi_amt"]))
            k[2].metric("Open SO", ui.fmt(fl["open_so_qty"]),
                        help="주문 파일 Order 수량 (= Confirm + Not Confirm). DP Table H열")
            k[3].metric("Open DO", ui.fmt((inv or {}).get("do_qty")),
                        help="재고 파일 D/O Qty (CFC5 + SCA3). DP Table I열")
            k = st.columns(4)
            k[0].metric("SO Confirm", ui.fmt(fl["so_confirm_qty"]))
            k[1].metric("SO Not Confirm", ui.fmt(fl["so_not_confirm_qty"]))
            k[2].metric("SO Block", ui.fmt(fl["so_block_qty"]), help="Order 중 Block 걸린 수량")
            k[3].metric("Not GI", ui.fmt(fl["not_gi_qty"]),
                        help="주문 파일 기준 DO 발행 후 미출고(GI) 수량. 참고용")
            if fl["return_gi_qty"] or fl["return_open_qty"]:
                st.caption(f"반품: GI에서 빠진 수량 {ui.fmt(fl['return_gi_qty'])} · 열린 반품 주문 {ui.fmt(fl['return_open_qty'])}")

        st.subheader("ADI 채널 재고")
        if not fl or not fl["sources"].get("adi"):
            st.caption("ADI 데이터가 없습니다.")
        else:
            src_a, src_m = fl["sources"]["adi"], fl["sources"]["mapping"]
            parts = fl.get("adi_parts") or []
            st.caption(f"{src_a['source']}: {src_a['file']} · 매핑 {src_m['source'] if src_m else '–'} · "
                       f"ADI 아이템 {', '.join(parts) if parts else '없음'}. 미국·캐나다·푸에르토리코 합계 (DP Table K열과 같은 정의)")
            k = st.columns(3)
            k[0].metric("ADI Available", ui.fmt(fl["adi_available_qty"]), help="DP Table 'ADI Inventory'와 같은 값")
            k[1].metric("ADI 전체 재고", ui.fmt(fl["adi_total_qty"]))
            k[2].metric("Allocated", ui.fmt(fl["adi_allocated_qty"]))
            k = st.columns(3)
            k[0].metric("Backorder", ui.fmt(fl["adi_backorder_qty"]))
            k[1].metric("ADI Open PO", ui.fmt(fl["adi_open_po_qty"]), help="ADI가 HVA에 낸 열린 PO 수량")
            k[2].metric("Past Due PO", ui.fmt(fl["adi_past_due_po_qty"]))
            if fl.get("adi_by_country"):
                st.dataframe(pd.DataFrame(fl["adi_by_country"]).rename(columns={
                    "country": "나라", "available_qty": "Available", "total_qty": "전체", "allocated_qty": "Allocated",
                    "backorder_qty": "Backorder", "open_po_qty": "Open PO"}), hide_index=True)

    with t_dp:
        calc = d.get("dp_calc")
        if not calc:
            st.caption("DP Table에 없는 Item입니다 (DP 비대상 또는 BOM 세트 헤더).")
        else:
            src = calc["source"]
            st.caption(f"계산 엔진 (DP 파일 수식 동일) · {src['file']} W{src['dp_week']} · 재고·주문·ADI는 최신 파일, "
                       "입고는 Sync Plan − GR. 다건 검토는 '금주 DP' 화면.")
            # 'DP 계산' 화면 오른쪽 패널과 같은 것 (dp_panel.py): 결론 → 근거 → 고치기 → 기록
            st.session_state.i360_dp_item = d["item"]
            dp_panel.panel(dp_engine.LATEST, None, "i360_dp_item", "e360", header=False)

            kv = d.get("kv_switch")
            if kv:
                st.subheader("K↔V 생산 전환 모델")
                st.caption("한국(K)·베트남(V) 생산 전환 모델은 두 코드 판매 합산으로 RR 계산 후 "
                           "최근 3개월 Sell-in 비율로 배분 (v07, K-V 전환 시트).")
                share = kv.get("share_of_this_sku")
                rows = [("기준 모델", kv.get("model")), ("K / V 아이템", f"{kv.get('k_sku')} / {kv.get('v_sku')}"),
                        ("패턴 (처음→최근)", kv.get("pattern")), ("겹친 개월", ui.fmt(kv.get("overlap_months"))),
                        ("최근 3개월 우세", kv.get("recent_lead")), ("합산 RR", ui.fmt(kv.get("rr_combined"))),
                        ("K / V 개별 RR", f"{ui.fmt(kv.get('rr_k_alone'))} / {ui.fmt(kv.get('rr_v_alone'))}"),
                        ("현행 R/R K / V", f"{ui.fmt(kv.get('rr_current_k'))} / {ui.fmt(kv.get('rr_current_v'))}"),
                        ("이 아이템 배분비율", "–" if share is None else f"{share:.1%}")]
                st.dataframe(pd.DataFrame(rows, columns=["항목", "값"]), hide_index=True, width="stretch")

    with t_info:
        left, right = st.columns(2)
        basic = ["item", "item_name", "base", "suffix", "site", "dest", "model_group", "model_name", "dp_series",
                 "product_group", "product", "type", "sub_type", "resolution", "feature", "ai_target"]
        supply = ["plc_status", "bom_status", "scm_type", "from_site", "product_type", "sra", "eol", "eop",
                  "eop_start", "eop_qty", "moq_lt", "dp_to_site", "dp_asp", "group_constraints", "site_constraints"]
        for col, keys in ((left, basic), (right, supply)):
            rows = [(ui.LABELS.get(k, k), ui.fmt(d.get(k), 2 if k == "dp_asp" else 0)) for k in keys]
            col.dataframe(pd.DataFrame(rows, columns=["항목", "값"]), hide_index=True, width="stretch")

    with t_similar:
        sim = d["similar"]
        groups = [("이 아이템", [{"item": d["item"]}]),
                  ("같은 모델·다른 향지", sim["same_model_other_suffix"]),
                  ("다른 버전 (후보)", sim["other_versions_candidates"]),
                  ("같은 Model Group", sim["same_model_group"])]
        rows = [{"relation": rel, "item": r["item"]} for rel, items in groups for r in items]
        st.caption(f"같은 모델 {len(sim['same_model_other_suffix'])} · 다른 버전 후보 {len(sim['other_versions_candidates'])} · "
                   f"같은 Model Group {len(sim['same_model_group'])}. 다른 버전 = 숫자 마지막 자리만 다른 Item"
                   f" (묶음 키 {d.get('family_key') or '–'}). 사양 차이 가능성 있어 수동 확정 필요. "
                   "아이템 칸 선택 시 해당 Item으로 이동.")
        if len(rows) > 1:
            compare = pd.DataFrame(rows).merge(service.metrics(), on="item", how="left")
            compare = compare.merge(service.master()[["item", "site", "dest", "sra"]], on="item", how="left")
            ui.item_table(compare, ["relation", "item", "site", "dest", "plc_status", "sra", "eop", "inv_unrestricted",
                                    "inv_available", "gi_qty", "open_so_qty", "adi_available_qty", "rr", "alerts"],
                          key="similar", height=min(38 + 35 * len(compare), 420))
            totals = compare[["inv_unrestricted", "gi_qty", "open_so_qty", "adi_available_qty", "rr"]].sum()
            st.caption("합계 — " + " · ".join(f"{ui.label_of(k)} {ui.fmt(v)}" for k, v in totals.items()))
        else:
            st.caption("유사 Item이 없습니다.")

    with t_bom:
        st.subheader("BOM 구성품")
        if d["bom_components"]:
            b = pd.DataFrame(d["bom_components"])
            st.dataframe(b.rename(columns={"alt": "Alt", "component": "구성품", "qty": "수량", "selected": "선택 Alt",
                                           "dp_component": "DP 구성품", "component_local": "Local 구성품",
                                           "bom_status": "BOM Status"})
                         .drop(columns=["header"], errors="ignore"), hide_index=True, width="stretch")
        else:
            st.caption("BOM 세트 아님.")
        st.subheader("이 아이템이 들어가는 BOM 세트")
        if d["used_in_boms"]:
            st.dataframe(pd.DataFrame(d["used_in_boms"])[["header", "alt", "qty", "selected"]]
                         .rename(columns={"header": "BOM 세트", "alt": "Alt", "qty": "수량", "selected": "선택 Alt"}),
                         hide_index=True, width="stretch")
        else:
            st.caption("없습니다.")
        st.subheader("POS SKU (Sell-out 이름)")
        if d["pos_skus"]:
            st.dataframe(pd.DataFrame(d["pos_skus"]).rename(columns={
                "alias": "POS SKU", "po_sku": "확정 PO SKU", "qty": "POS 1개당 수량", "stage": "확정 단계"})
                .drop(columns=["item", "kind"], errors="ignore"), hide_index=True, width="stretch")
        else:
            st.caption("POS 매핑이 없습니다.")

    with t_sales:
        if not d.get("in_dp_list"):
            st.caption("DP list 미등록 Item입니다.")
        else:
            dp_meta = service.meta().get("inputs", {}).get("dp_file", {})
            st.caption(f"출처: {dp_meta.get('file')} DP list (W{dp_meta.get('dp_week')}, RR 기준월 {dp_meta.get('rr_base_month')})")
            keys = ["dp_sales_prev_year", "dp_sales_recent6", "dp_sales_recent3", "dp_rr_current", "dp_rr_proposed",
                    "dp_rr_rule", "dp_rr_flag", "dp_eoh_target", "dp_pl_status", "dp_pl_notes", "dp_rr_risk_flag",
                    "dp_rr_risk_reason", "dp_prev_model"]
            rows = [(ui.LABELS[k], ui.fmt(d.get(k))) for k in keys]
            st.dataframe(pd.DataFrame(rows, columns=["항목", "값"]), hide_index=True, width="stretch")
            st.caption("월별 Sell-in · Sell-out 수량은 추후 연결 예정.")

    with t_planned:
        st.caption("PRD 7장 Item 360 항목 중 데이터 미연결 항목. 개발 순서대로 연결 예정.")
        names = {s["id"]: s["name"] for s in config.sources()}
        rows = [(s["name"], names.get(s["source"], "–") if s["source"] else "–", s.get("note", ""))
                for s in service.PLANNED_SECTIONS]
        st.dataframe(pd.DataFrame(rows, columns=["항목", "데이터", "메모"]), hide_index=True, width="stretch")
