"""HVA SCM Hub. 실행: run_hub.bat"""

from datetime import date

import streamlit as st

import ui
from hub import dp_engine as E, ingest, service, web

st.set_page_config(page_title="HVA SCM Hub", page_icon="📦", layout="wide")
# 겉모습: 색·글꼴은 .streamlit/config.toml 테마, 그 밖은 ui.STYLE (docs/ui-design.md 4장).
# 숫자 카드 글자 크기(날짜 10글자가 잘리지 않게 1.5rem)는 테마 metricValueFontSize로 옮겼다
ui.apply_style()
ui.login_gate()   # 시작 비밀번호 (settings.yaml login). 맞히기 전에는 데이터를 읽지 않는다

# 앱을 열 때 한 번 새 파일을 확인한다 (바뀐 파일만 읽어서 보통 몇 초)
if "scan_results" not in st.session_state:
    with st.spinner("새 파일 확인 중…"):
        st.session_state.scan_results = service.refresh()
elif service.inbound_stale():
    # 다른 사람이 올린 Inbound가 동기화됐다. 옛 입고로 DP를 확정하지 않도록 어느 화면에서든 바로 반영한다
    with st.spinner("Inbound 갱신 중…"):
        st.session_state.scan_results = service.refresh()

# ---- 메뉴 5개 (2026-11-09, docs/ui-design.md 2장) -------------------------------
# 화면 파일 10개는 그대로 두고 메뉴만 묶는다. 묶인 화면은 맨 위 단계·탭으로 오간다.
# Streamlit 기본 메뉴는 숨기고(position="hidden") 사이드바에 직접 그린다. 화면 경로(views/...)는 그대로라
# st.switch_page·page_link·테스트가 전과 같이 움직인다.
def page(path: str, title: str, icon: str, **kw) -> st.Page:
    return st.Page(path, title=title, icon=icon, **kw)


MENU = [   # (메뉴 이름, 아이콘, [(화면, 단계·탭 이름)]) — 첫 화면이 메뉴를 눌렀을 때 여는 화면
    ("홈", ":material/home:", [(page("views/today.py", "오늘", ":material/today:", default=True), "오늘")]),
    ("주간 DP", ":material/event_available:", [
        (page("views/dp_plan.py", "금주 DP", ":material/calculate:"), "금주 DP · 목·금"),
        (page("views/resource_check.py", "자원점검 업로드", ":material/flight_takeoff:"), "자원점검 업로드 · 월"),
        (page("views/dp_history.py", "DP 이력", ":material/history:"), "DP 이력"),
        (page("views/run_rate.py", "RR 리뷰", ":material/trending_up:"), "RR 리뷰 · 월")]),
    ("Inbound", ":material/local_shipping:", [(page("views/inbound.py", "Inbound", ":material/local_shipping:"), "Inbound")]),
    ("아이템", ":material/inventory_2:", [
        (page("views/worklist.py", "담당 아이템", ":material/checklist:"), "담당 아이템"),
        (page("views/item360.py", "Item 360", ":material/search:"), "Item 360")]),
    ("프로젝트", ":material/work:", [(page("views/projects.py", "프로젝트", ":material/work:"), "프로젝트")]),
    ("데이터", ":material/database:", [
        # 웹 버전(GitHub Pages)은 PC 폴더를 못 봐서 데이터를 넣는 화면이 먼저 (hub/web.py). PC는 맨 뒤 (웹과 주고받기)
        *([(page(web.PAGE, "웹 데이터", ":material/sync_alt:"), "웹 데이터")] if web.is_web() else []),
        (page("views/status.py", "데이터 현황", ":material/database:"), "데이터 현황"),
        (page("views/base_items.py", "Base Item", ":material/inventory_2:"), "Base Item"),
        (page("views/item_master.py", "Item Master", ":material/table_view:"), "Item Master"),
        *([] if web.is_web() else [(page(web.PAGE, "웹 데이터", ":material/sync_alt:"), "웹 데이터")])]),
]
nav = st.navigation([p for _, _, tabs in MENU for p, _ in tabs], position="hidden")
group = next(m for m in MENU if any(p.url_path == nav.url_path for p, _ in m[2]))

DERIVED_IDS = {module.CACHE for module, _, _ in ingest.DERIVED}
WEEKDAY = "월화수목금토일"

with st.sidebar:
    # 아이템 찾기: 입력하면 Item 360에서 그 검색어로 찾는다. 다음 검색을 위해 칸을 비운다(key를 바꿈)
    n = st.session_state.get("side_q_n", 0)
    q = st.text_input("Item 검색", key=f"side_q_{n}", placeholder="Item 검색", icon=":material/search:",
                      label_visibility="collapsed", help="Item·모델명·품명·POS SKU")
    if q.strip():
        st.session_state.side_q_n = n + 1
        ui.open_item(q.strip())
    with st.container(gap=None, key="side_menu"):
        for i, (label, icon, tabs) in enumerate(MENU):
            # 지금 화면이 속한 메뉴는 key가 side_nav_on → ui.STYLE이 주황으로 칠한다
            with st.container(key="side_nav_on" if label == group[0] else f"side_nav_{i}"):
                st.page_link(tabs[0][0], label=label, icon=icon, width="stretch")
    # 이번 주 카드: 날짜 · 이번 DP 주차 · DP 날짜·기간
    today = date.today()
    cal = service.dp_calendar() if service.dp_plan_meta() else None
    with st.container(border=True, key="side_week"):
        st.caption(f"{today:%m/%d} ({WEEKDAY[today.weekday()]})")
        if cal:
            thu, fri = (date.fromisoformat(d) for d in cal["dp_days"])
            st.markdown(f"금주 DP **W{cal['dp_week']}**")
            st.caption(f"DP {thu:%m/%d}(목)·{fri:%m/%d}(금) · "
                       + ", ".join(E.month_label(k) for k in cal["month_keys"][:cal["months"]]))
    recent_box = st.container()   # 최근 본 아이템: 화면을 그린 뒤에 채운다 (맨 아래)
    st.divider()
    results = st.session_state.scan_results
    loaded = [r for r in results if r["status"] == ingest.LOADED and r["id"] not in DERIVED_IDS]
    problems = [r for r in results if r["status"] in (ingest.LOCKED, ingest.ERROR, ingest.MISSING)]
    if loaded:
        st.success("신규 반영: " + ", ".join(r["name"] for r in loaded), icon=":material/download_done:")
    for r in problems:
        st.warning(f"{r['name']}: {ingest.STATUS_LABEL[r['status']]}", icon=":material/warning:")
    if not loaded and not problems:
        st.caption("데이터가 최신입니다.")
    inv = service.inventory_meta()
    fm = service.flow_meta()
    dates = [f"재고 {inv['key_date'][5:]}" if inv.get("key_date") else None]
    dates += [f"{label} {fm[k]['file_date'][5:]}" for k, label in (("orders", "주문"), ("returns", "반품"), ("adi", "ADI"))
              if fm.get(k) and fm[k].get("file_date")]
    st.caption("데이터: " + " · ".join(d for d in dates if d) + " (상세: 홈)")
    if st.button("새 파일 확인", icon=":material/refresh:", width="stretch"):
        with st.spinner("새 파일 확인 중…"):
            st.session_state.scan_results = service.refresh()
        st.rerun()

# 묶인 화면(주간 DP·아이템·데이터)은 맨 위에 단계·탭. 고르면 그 화면으로 간다.
# 고른 값은 바로 지금 화면으로 되돌려 둔다. 남겨 두면 나중에 이 화면으로 돌아왔을 때 다시 넘어가 버린다
def _subnav(key: str, here: str) -> None:
    st.session_state.subnav_go = st.session_state[key]
    st.session_state[key] = here


if len(group[2]) > 1:
    names = [name for _, name in group[2]]
    here = next(name for p, name in group[2] if p.url_path == nav.url_path)
    key = f"subnav_{nav.url_path}"
    if st.session_state.get(key) != here:    # 누른 것은 _subnav가 먼저 subnav_go에 받아 둔다
        st.session_state[key] = here
    st.segmented_control(group[0], names, key=key, required=True, label_visibility="collapsed",
                         on_change=_subnav, args=(key, here))
    go = st.session_state.pop("subnav_go", None)
    if go and go != here:
        st.switch_page(next(p for p, name in group[2] if name == go))

nav.run()

# 최근 본 아이템: 페이지가 그려진 뒤에 넣어야 방금 연 아이템까지 보인다. 누르면 바로 Item 360.
# 자리는 '이번 주' 카드 아래(recent_box), 데이터 상태·새 파일 확인은 그 아래 맨 끝
recent = st.session_state.get("recent", [])
if recent:
    with recent_box:
        st.caption("최근 조회 Item")
        for item in recent:
            if st.button(item, key=f"recent_{item}", width="stretch", type="tertiary"):
                ui.open_item(item)
