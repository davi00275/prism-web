"""DP 아이템 패널: 아이템 하나의 DP 계산을 보고 사람이 고친다 ('이번 주 DP' 화면 오른쪽, Item 360 'DP 계산' 탭).

금요일 DP는 M1~M3 수량을 정하는 일이다 (사용자 2026-11-06). 자원점검 수량·AIR는 월요일 '자원점검 업로드' 화면에서 한다.
사람이 DP를 검토하는 순서대로 위에서 아래로:
  1. 결론   M1~M4 DP 값 (계산 → 지금 값), 자원점검 예상, 지난 주 확정값
  2. 근거   R/R·EOH·재고·주문·ADI, 월별 입고·DP 값·이월
  3. 고치기 입력값(R/R·EOH), 결과값(월 DP 값). 바꾸면 1이 바로 다시 계산된다 → 이유·메모 → 저장
  4. 기록   지금 적용 중인 수정(하나씩 되돌리기), 지난 주 수정 다시 쓰기, 누가 언제 무엇을 전 → 후로 고쳤는지

패널은 st.fragment라서 숫자를 바꾸거나 ◀ ▶로 넘길 때 패널만 다시 그린다 (왼쪽 목록은 그대로). 저장하면 화면 전체를 다시 그린다.
보는 아이템은 st.session_state[state_key]에 둔다 (◀ ▶가 바꾼다).
'DP 파일 데이터 그대로'(대조) 보기에서는 읽기만 한다 (고친 값은 이번 주차에 붙으므로).
"""

import pandas as pd
import streamlit as st

import ui
from hub import dp_engine as E, metrics as M, service


def _go(state_key: str, item: str) -> None:
    st.session_state[state_key] = item


def _clear(keys: list[str], gen_key: str) -> None:
    """고치기 칸을 지금 값으로 되돌린다 ([저장]·[취소]·[되돌리기]·[이번 주에도 적용] 뒤).
    저장값(session_state)만 지우면 브라우저 칸에는 고친 숫자가 남아 있다가 다음 동작 때 다시 보내진다
    (2026-11-09 미리보기에서 확인: [취소] 뒤 다시 그리면 고친 값이 되살아남). 그래서 번호(gen_key)를 올려
    칸 key 자체를 바꾼다. 새 칸은 지금 값으로 그려진다."""
    for k in keys:
        st.session_state.pop(k, None)
    st.session_state[gen_key] = st.session_state.get(gen_key, 0) + 1


def _changed(new, cur) -> bool:
    if new is None or cur is None:
        return (new is None) != (cur is None)
    return abs(float(new) - float(cur)) > 1e-9


def _same(a, b) -> bool:
    return a is not None and b is not None and abs(float(a) - float(b)) < 1e-6


def _when(at) -> str:
    return str(at or "")[5:16].replace("T", " ")


def _delta(new, base, digits=0) -> str | None:
    if new is None or base is None or abs(new - base) < 0.5 * 10 ** -digits:
        return None
    return f"{new - base:+,.{digits}f}"


def _show(field: str, v) -> str:
    """고친 값 한 칸을 화면 글자로 (자원점검 조정은 +/−, Remarks는 글자)."""
    if field == "remarks":
        return f"'{v}'" if v else "없음"
    if field == "base_item":
        return "추가" if v else "제외"
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return "없음"
    return f"{v:+,.0f}" if field == "rc_adjust" else ui.fmt(v)


def confirmed_line(h: pd.DataFrame, week: str) -> str | None:
    """'W44 확정 (Jessica Cho, 10-30 15:20): 자원점검 1,240 · Nov 900 · Dec 950 · AIR 0 / VSL 1,240' 한 줄."""
    if h is None or h.empty:
        return None
    r = h.iloc[0]
    months = [f"{E.month_label(r[f'month_m{i}'])} {ui.fmt(r[f'demand_m{i}'])}"
              for i in range(1, E.MAX_MONTHS + 1) if isinstance(r.get(f"month_m{i}"), str)]
    tag = "금주" if r["week"] == week else r["week"].split("-")[-1]
    return (f"{tag} 확정 ({r['confirmed_by']}, {_when(r['confirmed_at'])}): 자원점검 {ui.fmt(r['resource_check'])} · "
            + " · ".join(months) + f" · AIR {ui.fmt(r['air'])} / VSL {ui.fmt(r['vsl'])}"
            + (f" · Remarks '{r['remarks']}'" if r.get("remarks") else ""))


@st.fragment
def panel(mode: str, nav: list[str] | None, state_key: str, key: str, header: bool = True) -> None:
    """state_key = 보는 아이템이 든 session_state 이름, key = 위젯 이름 앞머리 (화면마다 다르게)."""
    item = st.session_state.get(state_key)
    plan = service.dp_plan(mode)
    meta = service.dp_plan_meta()
    if not item or plan is None:
        st.info("좌측 목록에서 Item 선택 시 상세 표시.", icon=":material/left_click:")
        return
    rows = plan[plan["item"] == item]
    if rows.empty:
        st.caption("DP Table에 없는 Item입니다 (DP 비대상 또는 BOM 세트 헤더).")
        return
    cur = {k: service._plain(v) for k, v in rows.iloc[0].items()}
    cal = plan.attrs["calendar"]
    months = cal["months"]
    keys = cal["month_keys"][:months]
    labels = [E.month_label(k) for k in keys]
    week_name = f"W{cal['dp_week']}"
    rr_month = meta.get("rr_base_month")
    editable = mode == E.LATEST

    # ---- 머리글: ◀ ▶, 아이템, 표시 ----
    if header:
        nav = nav or [item]
        i = nav.index(item) if item in nav else 0
        c = st.columns([1, 1.1, 1, 2.2], vertical_alignment="center")
        c[0].button("◀", key=f"{key}_prev", disabled=i == 0, width="stretch", help="이전 Item",
                    on_click=_go, args=(state_key, nav[max(i - 1, 0)]))
        c[1].markdown(f"<div style='text-align:center'>{i + 1} / {len(nav)}</div>", unsafe_allow_html=True)
        c[2].button("▶", key=f"{key}_next", disabled=i >= len(nav) - 1, width="stretch", help="다음 Item",
                    on_click=_go, args=(state_key, nav[min(i + 1, len(nav) - 1)]))
        if c[3].button("Item 360 상세", key=f"{key}_open", icon=":material/open_in_new:", width="stretch"):
            ui.open_item(item, nav)
        info = service.item_metrics(item) or {}
        st.subheader(item, anchor=False)
        sub = [info.get("item_name") if info.get("item_name") != item else None, info.get("product_group"),
               info.get("owner") and f"담당 {info['owner']}"]
        chips = []
        if cur.get("rr_review"):
            chips.append(ui.badge(cur["rr_review"], "red" if "수동입력" in cur["rr_review"] else "orange"))
        if info.get("dp_status"):
            chips.append(ui.badge(info["dp_status"], "blue" if info["dp_status"] == M.DP_TARGET else "gray"))
        if cur.get("edited"):
            chips.append(ui.badge("수정", "blue"))
        if cur.get("rr_stale") or cur.get("eoh_stale"):
            chips.append(ui.badge("원본 값 변경", "red"))
        st.markdown(" · ".join(x for x in sub if not ui.blank(x)) + ("  \n" + " ".join(chips) if chips else ""))
        if cur.get("review_reason"):
            st.caption(f"Review 사유: {cur['review_reason']}")
    elif cur.get("rr_review"):
        st.error(f"{cur['rr_review']} — {cur.get('review_reason') or ''}", icon=":material/edit_note:")

    summary = st.container()  # 결론: 아래 고치기 칸을 읽은 뒤에 채운다 (미리보기)
    basis = st.container()

    # ---- 고치기 ----
    # 칸 key = <화면>_<칸>_<아이템>, 되돌린 뒤에는 끝에 _<번호> (_clear 참고)
    gen_key = f"{key}_gen_{item}"
    sfx = f"_{st.session_state[gen_key]}" if st.session_state.get(gen_key) else ""
    wkeys = {f: f"{key}_{f}_{item}{sfx}" for f in ["rr", "eoh"] + [f"m{i}" for i in range(1, months + 1)]}
    wkeys |= {"reason": f"{key}_reason_{item}{sfx}", "memo": f"{key}_memo_{item}{sfx}"}
    reset = (list(wkeys.values()), gen_key)
    changes = []
    if not editable:
        st.caption(f"대조 보기 (DP 파일 {meta.get('dp_file')} W{meta.get('dp_week')}의 데이터·기간). "
                   "수정은 '최신 파일' 기준에서만 가능.")
    else:
        box = st.container(border=True)
        box.markdown("**수정**")

        def field_row(label: str, note: str, edited: bool):
            """한 줄에 하나: 왼쪽 이름·기준값, 오른쪽 입력칸 (docs/ui-design.md 3장 ②). 입력칸 자리를 돌려준다."""
            c = box.columns([1.4, 1], vertical_alignment="center")
            c[0].markdown(f"{label}  \n:gray[{note}]" + ("  \n" + ui.badge("수정값", "blue") if edited else ""))
            return c[1]

        # '고친 값' 표시는 목록의 색칠된 칸과 같은 기준 (DP 계산 표의 rr_edit·eoh_edit·manual_by_m*)
        rr_new = field_row("R/R (월)", f"DP 파일 {ui.fmt(cur['rr_file'])} · RR 기준월 내 적용", bool(cur.get("rr_edit"))
                           ).number_input("R/R (월)", min_value=0.0, value=float(cur["rr"]), step=1.0, format="%.0f",
                                          key=wkeys["rr"], label_visibility="collapsed",
                                          help=f"입력값. DP 파일 값 {ui.fmt(cur['rr_file'])}. "
                                               f"RR 기준월({rr_month}) 내 적용. 변경 시 전 월 재계산")
        eoh_new = field_row("EOH", f"DP 파일 {ui.fmt(cur['eoh_file'])}", bool(cur.get("eoh_edit"))
                            ).number_input("EOH", min_value=0.0, value=float(cur["eoh"]), step=1.0, format="%.0f",
                                           key=wkeys["eoh"], label_visibility="collapsed",
                                           help=f"입력값. DP 파일 값 {ui.fmt(cur['eoh_file'])}. RR 기준월 내 적용")
        dp_new = []
        for i, lab in enumerate(labels, start=1):
            calc = cur.get(f"calc_demand_m{i}")
            now = cur.get(f"demand_m{i}") or 0
            dp_new.append(field_row(f"M{i} {lab} DP", f"계산값 {ui.fmt(calc)} · {week_name}만",
                                    not ui.blank(cur.get(f"manual_by_m{i}"))
                                    ).number_input(
                f"M{i} {lab} DP", min_value=0.0, value=float(now), step=1.0, format="%.0f",
                key=wkeys[f"m{i}"], label_visibility="collapsed",
                help=f"결과값. 계산값 {ui.fmt(calc)}. 해당 월 DP 값을 이 수량으로 대체 "
                     f"(DP 파일 수동입력 열과 동일). 계산값 재입력 시 복원. {week_name}에만 적용"))

        for f, new in (("rr", rr_new), ("eoh", eoh_new)):
            if _changed(new, cur[f]):
                orig = cur[f"{f}_file"]
                changes.append({"item": item, "field": f, "period": rr_month, "original": orig,
                                "value": None if _same(new, orig) else new})
        for i, (k, new) in enumerate(zip(keys, dp_new), start=1):
            if _changed(new, cur.get(f"demand_m{i}") or 0):
                calc = cur.get(f"calc_demand_m{i}")
                changes.append({"item": item, "field": "manual", "period": k, "original": calc,
                                "value": None if _same(new, calc) else new})

    after = cur
    if changes:
        prev = service.dp_plan(mode, service.edit_records(changes))
        after = {k: service._plain(v) for k, v in prev[prev["item"] == item].iloc[0].items()}
        reason = box.pills("사유", service.edit_reasons(), key=wkeys["reason"])
        memo = box.text_input("메모 (선택)", key=wkeys["memo"], placeholder="예: TJMAXX 11월 납품 200대 추가")
        lines = []
        for ch in changes:
            label = service.edit_label(ch["field"], ch["period"], keys)
            old = cur[ch["field"]] if ch["field"] in ("rr", "eoh") else cur.get(f"demand_m{keys.index(ch['period']) + 1}")
            lines.append(f"{label} {ui.fmt(old)} → "
                         + (f"계산값 {ui.fmt(ch['original'])}로 복원" if ch["value"] is None else ui.fmt(ch["value"])))
        lines.append(f"자원점검(예상) {ui.fmt(cur['resource_check'])} → {ui.fmt(after['resource_check'])}")
        box.markdown("저장 시 변경 내용  \n" + "  \n".join(f"- {x}" for x in lines))
        b = box.columns(2)
        if b[0].button("저장", type="primary", icon=":material/save:", width="stretch", key=f"{key}_save_{item}"):
            path = service.save_edits(changes, memo, reason or "")
            _clear(*reset)
            st.session_state[f"{key}_saved"] = f"{item} {len(changes)}칸 저장 → {path.name}"
            st.rerun()
        b[1].button("취소", width="stretch", key=f"{key}_cancel_{item}", on_click=_clear, args=reset)
    elif editable:
        box.caption(f"수량 변경 시 상단 결과가 저장 전 미리보기로 표시. R/R·EOH = 입력값 (RR 기준월 {rr_month}), "
                    f"월 DP 값 = 금주({week_name})만 적용. 0 = 수요 없음. "
                    "자원점검 수량·AIR는 월요일 '자원점검 업로드'에서 결정.")
    saved = st.session_state.pop(f"{key}_saved", None)
    if saved:
        st.toast(saved, icon=":material/check_circle:")

    # ---- 결론 (미리보기면 미리보기 값) ----
    hist = service.item_dp_history(item)
    with summary:
        if changes:
            st.caption(":blue-badge[:material/preview: 저장 전 미리보기] 하단 수정값 기준 계산")
        # 2열 회색 칸 (key dpsum_ → ui.STYLE). 좁은 패널에서 4칸을 한 줄에 두면 라벨이 잘려서.
        # 읽는 순서: (자원점검, M1) (M2, M3) …
        c = st.container(key=f"dpsum_{key}").columns(2)
        rc_help = (f"자원점검 = MAX(마지막 달 이월 + EOH, 0) + 수동 조정. 작은 글자 = 수정 전 계산값 "
                   f"{ui.fmt(after['calc_resource_check'])} 대비. DP 파일 값 {ui.fmt(after.get('dpf_resource_check'))}")
        c[0].metric("자원점검 (예상)", ui.fmt(after["resource_check"]),
                    delta=_delta(after["resource_check"], after["calc_resource_check"]), delta_color="off", help=rc_help)
        for i, lab in enumerate(labels, start=1):
            c[i % 2].metric(f"M{i} {lab} DP", ui.fmt(after.get(f"demand_m{i}")),
                            delta=_delta(after.get(f"demand_m{i}"), after.get(f"calc_demand_m{i}")), delta_color="off",
                            help=f"계산값 {ui.fmt(after.get(f'calc_demand_m{i}'))}")
        line = confirmed_line(hist, cal["week"])
        if line:
            st.caption(line)

    # ---- 근거 ----
    with basis:
        cols = [f"M{i} {lab}" for i, lab in enumerate(labels, start=1)]
        table = {"입고": [after.get(f"inbound_m{i}") for i in range(1, months + 1)],
                 "DP 값 (계산)": [after.get(f"calc_demand_m{i}") for i in range(1, months + 1)],
                 "DP 값": [after.get(f"demand_m{i}") for i in range(1, months + 1)],
                 "이월 (+부족 / −남음)": [after.get(f"carry_m{i}") for i in range(1, months + 1)]}
        if all(_same(a, b) for a, b in zip(table["DP 값"], table["DP 값 (계산)"])):
            table.pop("DP 값 (계산)")
        df = pd.DataFrame(table, index=cols).T.map(lambda v: "" if v is None or pd.isna(v) else ui.fmt(v, 0))
        st.dataframe(df, width="stretch")
        rr_parts = ""
        if cur.get("bom_rr"):
            rr_parts = f" (단품 {ui.fmt(cur.get('own_rr'))} + BOM {ui.fmt(cur.get('bom_rr'))})"
        st.caption(
            f"**R/R** {ui.fmt(after['rr'])}{rr_parts} · **ADI 보정** {ui.fmt(after.get('adi_adjust'))} · "
            f"**EOH** {ui.fmt(after['eoh'])} · **HVA 재고** {ui.fmt(after.get('hva_inv'))} · **SO** {ui.fmt(after.get('open_so'))} · "
            f"**DO** {ui.fmt(after.get('open_do'))} · **GI** {ui.fmt(after.get('gi'))} · **ADI 재고** {ui.fmt(after.get('adi_inv'))} · "
            f"M1 잔여 근무일 비율 {cal['workday_ratio']:.2f}"
            + (" · DP 파일 미등록 Item · R/R·EOH 0에서 시작" if not cur.get("in_dp_table")
               else "" if cur.get("in_rr_list") else " · Setting S열 R/R 목록 미등록 · DP 파일 R/R 0"))

    # ---- 기록 ----
    active = service.active_edits(item)
    if active:
        st.markdown("**적용 중인 수정**")
        for n, e in enumerate(active):
            c = st.columns([4, 1.3], vertical_alignment="center")
            value = _show(e["field"], e["value"])
            base = f"{ui.fmt(e['original'])} → " if e.get("original") is not None else ""
            why = " · ".join(x for x in (e.get("reason"), e.get("memo")) if x)
            c[0].markdown(f"{e['label']} {base}**{value}** — {e['by']}, {_when(e['at'])}" + (f" · _{why}_" if why else ""))
            if editable and c[1].button("복원", key=f"{key}_undo_{item}_{n}", width="stretch",
                                        help="수정 삭제 후 계산값(R/R·EOH는 DP 파일 값)으로 복원"):
                service.save_edits([{"item": item, "field": e["field"], "period": e["period"], "value": None,
                                     "original": e["original"]}], "되돌림")
                _clear(*reset)
                st.rerun()
    if cur.get("rr_stale") or cur.get("eoh_stale"):
        st.warning("R/R·EOH 수정 후 DP 파일 값이 변경되었습니다. 수정값 유지 여부를 확인하십시오 "
                   "('금주 DP' 화면 상단에서 일괄 처리 가능).", icon=":material/sync_problem:")

    carry = service.previous_week_edits(item) if editable else []
    if carry:
        text = ", ".join(f"{e['label']} {_show(e['field'], e['value'])}" for e in carry)
        c = st.columns([5, 2], vertical_alignment="center")
        c[0].caption(f"직전 DP 주차({carry[0]['week']}) 수정값: {text}. 금주({week_name}) 미적용")
        if c[1].button("금주에도 적용", key=f"{key}_carry_{item}", width="stretch"):
            service.save_edits([{"item": item, "field": e["field"], "period": e["period"], "value": e["value"],
                                 "original": cur.get(f"calc_demand_m{keys.index(e['period']) + 1}"),
                                 "reason": e.get("reason") or "", "memo": e.get("memo") or ""} for e in carry],
                               f"전주({carry[0]['week']}) 수정 재적용")
            _clear(*reset)
            st.rerun()

    log = service.change_log(item)
    if len(log):
        with st.expander(f"수정 이력 {len(log)}건 (전체 담당, 최신순)", expanded=False):
            st.dataframe(history_table(log), hide_index=True, width="stretch")
    if len(hist):
        with st.expander(f"주차별 확정 이력 {len(hist)}주", expanded=False):
            st.dataframe(history_by_week(hist), width="stretch")


def history_table(log: pd.DataFrame, with_item: bool = False) -> pd.DataFrame:
    """고친 기록 → 화면 표: 언제, 누가, (아이템), 항목, 전, 후, 이유, 메모, DP 주차."""
    def side(field, v, text):
        if field == "remarks":
            return _show(field, text or "")
        if v is None or pd.isna(v):
            return "복원"
        return _show(field, v)

    text = log["text"] if "text" in log else pd.Series("", index=log.index)
    before_text = log["before_text"] if "before_text" in log else pd.Series("", index=log.index)
    out = pd.DataFrame({
        "일시": log["at"].map(_when), "작성자": log["by"], "아이템": log["item"], "항목": log["label"],
        "전": [_show("remarks", bt) if f == "remarks" else _show(f, b)
              for f, b, bt in zip(log["field"], log["before"], before_text)],
        "후": [side(f, v, t) for f, v, t in zip(log["field"], log["value"], text)],
        "사유": log["reason"].fillna(""), "메모": log["memo"].fillna(""),
        "DP 주차": log["week"].fillna("").str.replace(r"^\d{4}-", "", regex=True),
    })
    return out if with_item else out.drop(columns=["아이템"])


def history_by_week(hist: pd.DataFrame) -> pd.DataFrame:
    """주차별 확정값 → 주차(행) × 달(열) 표. 같은 달이 주마다 어떻게 바뀌었는지 보인다 (예: 11월 W44 900 → W45 1,100)."""
    rows = []
    for r in hist.itertuples(index=False):
        row = {"주차": r.week.split("-")[-1]}
        for i in range(1, E.MAX_MONTHS + 1):
            m = getattr(r, f"month_m{i}", None)
            if isinstance(m, str):
                row[m] = getattr(r, f"demand_m{i}")
        row |= {"자원점검": r.resource_check, "AIR": r.air, "VSL / TRK": r.vsl, "R/R": r.rr,
                "Remarks": r.remarks or "", "수정 내용": r.edit_note or "", "확정": f"{r.confirmed_by} {_when(r.confirmed_at)}"}
        rows.append(row)
    df = pd.DataFrame(rows).set_index("주차")
    months = sorted(c for c in df.columns if len(c) == 7 and c[4] == "-")
    df = df[months + [c for c in df.columns if c not in months]]
    for c in df.columns:
        if c not in ("Remarks", "수정 내용", "확정"):
            df[c] = df[c].map(ui.fmt)
    return df.rename(columns={m: f"{E.month_label(m)} {m[2:4]}" for m in months})
